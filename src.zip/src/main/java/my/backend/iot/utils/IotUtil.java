package my.backend.iot.utils;


import lombok.extern.slf4j.Slf4j;
import my.backend.iot.telemetry.dto.EventLogDto;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.TimeZone;
import java.util.UUID;

@Slf4j
public class IotUtil {

    private final ExpressionParser parser = new SpelExpressionParser();

    public LocalDateTime calMeasureTime(String dateString) {

        LocalDateTime localDateTime = null;

        if (dateString.contains("-")) {
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            localDateTime = LocalDateTime.parse(dateString, formatter);

        } else {
            String[] parts = dateString.split("\\+");
            String isoDateTimeString = parts[0];

            SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd'T'HHmmss");
            if (parts.length > 1 && parts[1] != null) {
                sdf.setTimeZone(TimeZone.getTimeZone("GMT+" + parts[1]));
            }

            try {
                Date parsedDate = sdf.parse(isoDateTimeString);
                Instant instant = parsedDate.toInstant();
                ZoneId zoneId = ZoneId.systemDefault();
                localDateTime = instant.atZone(zoneId).toLocalDateTime();
            } catch (Exception e) {
                log.error(e.getMessage());
            }
        }
        return localDateTime;
    }

    public boolean evaluateCondition(EvaluationContext context, String conditionDescription, EventLogDto eventLogDto) {
        try {
            Double alertValueInt = (Double) context.lookupVariable("alertValue");
            Expression expression = parser.parseExpression(conditionDescription);
            Boolean result = expression.getValue(context, Boolean.class);
            log.info("evaluateCondition : {}, {}, {} Evaluation result: {}",
                    eventLogDto.getProjectId(),
                    eventLogDto.getDeviceId(),
                    eventLogDto.getUuid(),
                    result + ": " + expression.getExpressionString() +":" +alertValueInt);
            return Boolean.TRUE.equals(result);
        } catch (Exception e) {
            // Log the exception instead of printing the stack trace
            log.error("Error evaluating condition: {}", conditionDescription, e);
            return false;
        }
    }

    public boolean exceedsThreshold(double value1, double value2, double threshold, String comparisonType , EventLogDto eventLogDto) {
        log.debug("==>{},{},{},{}", value1, value2, threshold, comparisonType);
        if ("percentage".equals(comparisonType)) {
            boolean result = Math.abs(value1 - value2) / value1 > threshold;
            log.info("exceedsThreshold : {}, {}, {}, {} Evaluation result: {}",
                    eventLogDto.getProjectId(),
                    eventLogDto.getDeviceId(),
                    eventLogDto.getUuid(),
                    result,
                    value1 + ", " + value2 + ", " + Math.abs(value1 - value2) + ", " + threshold + ", " + comparisonType);

            return result;
        } else if ("absolute".equals(comparisonType)) {
            return Math.abs(value1 - value2) >= threshold;
        }
        return false;
    }

    public Double calRoundingMode(Double value, int decimal) {
        BigDecimal bd = new BigDecimal(value);
        bd = bd.setScale(decimal, RoundingMode.HALF_UP);
        return bd.doubleValue();
    }


}
