package my.backend.iot.client.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.ToString;

@Schema
@Data
@ToString
public class ResetStRequest {

    @Schema(description = "客戶端ID")
    @NotEmpty
    @Size(max = 50)
    private String clientId;
}
