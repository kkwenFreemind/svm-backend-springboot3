package my.backend.iot.client.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import lombok.ToString;

@Schema
@Data
@ToString
public class ClientAccessTokenRequest {

    @Schema(description = "客戶端ID")
    @NotEmpty(message = "客戶端ID不可為空")
    private String clientId;

    @Schema(description = "客戶端Secret")
    @NotEmpty(message = "客戶端Secret不可為空")
    private String clientSecret;

}
