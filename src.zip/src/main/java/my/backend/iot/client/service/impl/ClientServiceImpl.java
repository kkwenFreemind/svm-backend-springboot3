package my.backend.iot.client.service.impl;

import jakarta.annotation.Resource;
import my.backend.iot.client.service.ClientService;
import my.backend.admin.service.dto.ClientDto;
import my.backend.admin.service.utils.UserProjectUtils;
import my.backend.common.cache.BmsCacheManager;
import my.backend.common.error.ErrorCode;
import my.backend.common.exception.ActionRuntimeException;
import my.backend.common.utils.BmsUtils;
import my.backend.admin.service.dto.KeycloakUserDto;
import my.backend.admin.service.dto.ResetPasswordDto;
import my.backend.admin.service.KeycloakAdapterService;
import my.backend.persistence.model.ClientInfoEntity;
import my.backend.persistence.repository.ClientInfoLogRepo;
import my.backend.persistence.repository.ClientInfoRepo;
import org.springframework.beans.BeanUtils;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import my.backend.persistence.model.ClientInfoLogEntity;
import my.backend.common.code.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

@Service
public class ClientServiceImpl implements ClientService {
        @Resource
        private BmsCacheManager bmsCacheManager;
        @Resource
        private ClientInfoLogRepo clientInfoLogRepo;
        @Resource
        private ClientInfoRepo clientInfoRepo;
        @Resource
        private KeycloakAdapterService keycloakAdapterService;
        @Resource
        private UserProjectUtils userProjectUtils;

        @Override
        @Transactional
        @Modifying
        public ClientDto createClient(String authToken, String actionUserId, ClientDto clientDto) {
            String clientName = UUID.randomUUID().toString();
            KeycloakUserDto keycloakUserDto = new KeycloakUserDto();
            keycloakUserDto.setUsername(clientName);
            keycloakUserDto.setEnabled(true);
            keycloakUserDto.setEmailVerified(false);
            ////
            String roleGroupName = clientDto.getClientRoleGroupName();
            keycloakUserDto.setGroups(new String[]{roleGroupName});
            ////
            String clientId = keycloakAdapterService.createUser(authToken, keycloakUserDto);
            ////
            ClientInfoEntity clientInfoEntity = new ClientInfoEntity();
            clientInfoEntity.setClientId(clientId);
            clientInfoEntity.setClientName(clientName);
            clientInfoEntity.setClientLabel(clientDto.getClientLabel());
            clientInfoEntity.setClientRoleGroupName(roleGroupName);
            clientInfoEntity.setProjectId(clientDto.getProjectId());
            clientInfoEntity = clientInfoRepo.save(clientInfoEntity);
            clientInfoLogRepo.saveAndFlush(genClientInfoLogEntity(actionUserId, clientInfoEntity, LogEntityStatusEnum.INSERT.getStatus()));
            ////
            //userProjectUtils.insertUserProject(actionUserId, UserProjectUtils.PROJECT, clientId, clientDto.getProjectId());
            ////
            //bmsCacheManager.refresh();
            ////
            clientDto.setClientId(clientId);
            clientDto.setCreateTime(BmsUtils.toEpochMilli(clientInfoEntity.getCreateTime()));
            clientDto.setUpdateTime(BmsUtils.toEpochMilli(clientInfoEntity.getUpdateTime()));
            return clientDto;
        }

        @Override
        @Transactional
        @Modifying
        public String deleteClient(String authToken, String actionUserId, String clientId) {
            keycloakAdapterService.deleteUser(authToken, clientId);
            ////
            ClientInfoEntity clientInfoEntity = clientInfoRepo.findByClientId(clientId);
            if (clientInfoEntity == null) {
                throw new ActionRuntimeException(ErrorCode.CLIENT_NOT_FOUND);
            }
            clientInfoRepo.delete(clientInfoEntity);
            clientInfoLogRepo.save(genClientInfoLogEntity(actionUserId, clientInfoEntity, LogEntityStatusEnum.DELETE.getStatus()));
            //userProjectUtils.deleteUserProjectByUserId(actionUserId, clientId);
            ////
            bmsCacheManager.refresh();
            return "Delete client, clientId = " + clientInfoEntity.getClientId();
        }

        private ClientInfoLogEntity genClientInfoLogEntity(String actionUserId, ClientInfoEntity clientInfoEntity, String status) {
            ClientInfoLogEntity clientInfoLogEntity = new ClientInfoLogEntity();
            BeanUtils.copyProperties(clientInfoEntity, clientInfoLogEntity);
            clientInfoLogEntity.setStatus(status);
            clientInfoLogEntity.setActionUserId(actionUserId);
            return clientInfoLogEntity;
        }

        @Override
        public List<ClientDto> getClientList() {
            List<ClientInfoEntity> clientInfoEntityList = clientInfoRepo.findAllByOrderByCreateTime();
            List<ClientDto> clientDtoList = new ArrayList<>();
            for (ClientInfoEntity entity : clientInfoEntityList) {
                ClientDto clientDto = new ClientDto();
                BeanUtils.copyProperties(entity, clientDto);
                clientDto.setCreateTime(BmsUtils.toEpochMilli(entity.getCreateTime()));
                clientDto.setUpdateTime(BmsUtils.toEpochMilli(entity.getUpdateTime()));
                clientDtoList.add(clientDto);
            }
            return clientDtoList;
        }

        @Override
        @Transactional
        @Modifying
        public String resetSecret(String authToken, String actionUserId, String clientId) {
            String st = UUID.randomUUID().toString();
            st = st.replaceAll("-", String.valueOf(((char) (((Math.random() * 26) + 65)))));
            ResetPasswordDto resetPasswordDto = new ResetPasswordDto(clientId, st);
            keycloakAdapterService.resetPassword(authToken, resetPasswordDto);
            ////
            userProjectUtils.saveChangeSecretLog(actionUserId, clientId, "client");
            ////
            ClientInfoEntity clientInfoEntity = clientInfoRepo.findByClientId(clientId);
            clientInfoEntity.setSecretUpdateTime(LocalDateTime.now());
            clientInfoRepo.save(clientInfoEntity);
            clientInfoLogRepo.save(genClientInfoLogEntity(actionUserId, clientInfoEntity, LogEntityStatusEnum.UPDATE.getStatus()));
            ////
            return st;
        }

        @Override
        @Transactional
        @Modifying
        public ClientDto updateClient(String authToken, String actionUserId, ClientDto clientDto) {
            ClientInfoEntity clientInfoEntity = clientInfoRepo.findByClientId(clientDto.getClientId());
            if (clientInfoEntity == null) {
                throw new ActionRuntimeException(ErrorCode.CLIENT_NOT_FOUND);
            }
            ////
            String oldClientRoleGroupName = clientInfoEntity.getClientRoleGroupName();
            String newClientRoleGroupName = clientDto.getClientRoleGroupName();
            //// old有值且不為new，解綁old
            if (oldClientRoleGroupName != null && !oldClientRoleGroupName.isEmpty() && !oldClientRoleGroupName.equals(newClientRoleGroupName)) {
                keycloakAdapterService.deleteGroupFromUser(authToken, clientDto.getClientId(), bmsCacheManager.getRoleGroupMap(authToken).get(oldClientRoleGroupName));
            }
            //// new有值且不為old，綁定new
            if (newClientRoleGroupName != null && !newClientRoleGroupName.isEmpty() && !newClientRoleGroupName.equals(oldClientRoleGroupName)) {
                keycloakAdapterService.addGroupFromUser(authToken, clientDto.getClientId(), bmsCacheManager.getRoleGroupMap(authToken).get(newClientRoleGroupName));
            }
            ////
            clientInfoEntity.setClientLabel(clientDto.getClientLabel());
            clientInfoEntity.setClientRoleGroupName(newClientRoleGroupName);
            clientInfoEntity = clientInfoRepo.save(clientInfoEntity);
            clientInfoLogRepo.saveAndFlush(genClientInfoLogEntity(actionUserId, clientInfoEntity, LogEntityStatusEnum.UPDATE.getStatus()));
            ////
            bmsCacheManager.refresh();
            clientDto.setUpdateTime(BmsUtils.toEpochMilli(clientInfoEntity.getUpdateTime()));
            return clientDto;
        }
}
