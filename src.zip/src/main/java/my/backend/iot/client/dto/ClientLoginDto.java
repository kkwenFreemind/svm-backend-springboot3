package my.backend.iot.client.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Schema
@Data
public class ClientLoginDto {

    @Schema(description = "clientId")
    @NotEmpty
    private String clientId;

    @Schema(description = "clientIp")
    private String clientIp;

    @Schema(description = "clientSecret")
    @NotEmpty
    private String clientSecret;

    public ClientLoginDto(String clientId, String clientSecret, String clientIp) {
        this.clientId = clientId;
        this.clientSecret = clientSecret;
        this.clientIp = clientIp;
    }

    @Override
    public String toString() {
        return "LoginDto(" +
                "clientIp=" + clientIp +
                ", clientId=" + clientId +
                ", clientSecret=*****" +
                ")";
    }
}
