package my.backend.iot.client.controller;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.annotation.Resource;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import my.backend.admin.controller.BaseController;
import my.backend.iot.client.dto.CreateClientRequest;
import my.backend.iot.client.dto.ResetStRequest;
import my.backend.iot.client.dto.UpdateClientRequest;
import my.backend.iot.client.service.ClientService;
import my.backend.admin.service.dto.ClientDto;
import org.springframework.beans.BeanUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("${server.api-base-path}")
@RequiredArgsConstructor
@Slf4j
public class ClientController extends BaseController {


    @Resource
    private ClientService clientService;

    @Operation(summary = "創建Client", description = "創建Client (Create Client)")
    @PostMapping(value = "/v1/auth/client")
    public ClientDto createClient(@Validated @RequestBody CreateClientRequest createClientRequest) {
        validClientRoleGroupName(createClientRequest.getClientRoleGroupName());
        ClientDto clientDto = new ClientDto();
        BeanUtils.copyProperties(createClientRequest, clientDto);
        return clientService.createClient(getAuthToken(), getActionUserId(), clientDto);
    }

    @Operation(summary = "刪除Client", description = "刪除Client by Client UUID")
    @DeleteMapping(value = "/v1/auth/client")
    public String deleteClient(@RequestParam String clientId) {
        return clientService.deleteClient(getAuthToken(), getActionUserId(), clientId);
    }

    @Operation(summary = "獲得Client清單資料", description = "獲得Client清單資料")
    @GetMapping(value = "/v1/auth/client/list")
    public List<ClientDto> getClientList() {
        return clientService.getClientList();
    }

    @Operation(summary = "設定Client Secret", description = "設定Client Secret")
    @PostMapping(value = "/v1/auth/client/reset-secret")
    public String resetSecret(@Validated @RequestBody ResetStRequest resetStRequest) {
        return clientService.resetSecret(getAuthToken(), getActionUserId(), resetStRequest.getClientId());
    }

    @Operation(summary = "更新Client", description = "更新Client")
    @PutMapping(value = "/v1/auth/client")
    public ClientDto updateClient(@Validated @RequestBody UpdateClientRequest updateClientRequest) {
        validClientRoleGroupName(updateClientRequest.getClientRoleGroupName());
        ClientDto clientDto = new ClientDto();
        BeanUtils.copyProperties(updateClientRequest, clientDto);
        return clientService.updateClient(getAuthToken(), getActionUserId(), clientDto);
    }
}
