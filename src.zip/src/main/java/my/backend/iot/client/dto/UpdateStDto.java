package my.backend.iot.client.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Schema
@Data
public class UpdateStDto {

    @Schema(description = "更新權限token")
    @NotEmpty
    @Size(max = 50)
    private String account;

    @Schema(description = "使用者Secret")
    @NotEmpty
    @Size(max = 50)
    private String value;

    public UpdateStDto(String account, String value) {
        this.account = account;
        this.value = value;
    }

    @Override
    public String toString() {
        return "UpdateStDto(" +
                "account=" + account +
                ", value=*****" +
                ")";
    }
}
