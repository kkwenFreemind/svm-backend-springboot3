package my.backend.iot.client.service;

import my.backend.admin.service.dto.ClientDto;

import java.util.List;

public interface ClientService {

    ClientDto createClient(String authToken, String actionUserId, ClientDto clientDto);

    String deleteClient(String authToken, String actionUserId, String clientId);

    List<ClientDto> getClientList();

    String resetSecret(String authToken, String actionUserId, String clientId);

    ClientDto updateClient(String authToken, String actionUserId, ClientDto clientDto);

}
