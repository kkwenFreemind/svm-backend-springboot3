package my.backend.iot.client.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.ToString;


@Schema
@Data
@ToString
public class CreateClientRequest {

    @Schema(description = "客戶端名稱")
    @NotEmpty(message = "客戶端名稱不可為空")
    @Size(max = 30, message = "客戶端名稱長度不可超過30")
    private String clientLabel;

    @Schema(description = "客戶端角色群組名稱")
    @NotEmpty(message = "客戶端角色群組名稱不可為空")
    @Size(max = 50, message = "客戶端角色群組名稱長度不可超過50")
    private String clientRoleGroupName;

    @Schema(description = "專案ID")
    @NotEmpty(message = "專案ID不可為空")
    @Size(max = 50, message = "專案ID長度不可超過50")
    private String projectId;
}
