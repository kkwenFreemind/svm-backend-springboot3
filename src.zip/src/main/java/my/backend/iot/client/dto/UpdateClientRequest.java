package my.backend.iot.client.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.ToString;


@Schema
@Data
@ToString
public class UpdateClientRequest {


    @Schema(description = "客戶端ID")
    @NotEmpty(message = "客戶端ID不可為空")
    @Size(max = 50, message = "客戶端ID長度不可超過50")
    private String clientId;
    @Schema(description = "客戶端名稱")
    @NotEmpty(message = "客戶端名稱不可為空")
    @Size(max = 30, message = "客戶端名稱長度不可超過30")
    private String clientLabel;
    @Schema(description = "客戶端角色群組名稱")
    @NotEmpty(message = "客戶端角色群組名稱不可為空")
    @Size(max = 50, message = "客戶端角色群組名稱長度不可超過50")
    private String clientRoleGroupName;
    @Schema(description = "是否啟用")
    @NotNull(message = "是否啟用不可為空")
    private Boolean enabled;
}
