package my.backend.iot.telemetry.cron;

import jakarta.annotation.Resource;
import my.backend.iot.telemetry.service.EventService;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

@Component
public class EventSchedule {

    @Resource
    private EventService eventService;

    //每5分鐘判斷是否有監測站超過兩小時沒有 Telemetry 資料 :offline_station
    @Scheduled(cron = "0 */2 * * * *")
    public void telemetryCheck10Min() {
        try {
            //eventService.checkOfflineStation();
        } finally {
            System.out.println("[telemetryCheck10Min]Release Lock");
        }
    }


    // 每天的0点执行 計算各個專案前日妥善率
//    @Scheduled(cron = "0 * * * * *")
    @Scheduled(cron = "0 */2 * * * *")
    public void scheduleDayAvailability() {
        try {
            //eventService.checkAvailability();
        } finally {
            System.out.println("[scheduleDayAvailability]Release Lock");
        }
    }
}
