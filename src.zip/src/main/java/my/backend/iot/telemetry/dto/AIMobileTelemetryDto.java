package my.backend.iot.telemetry.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

@Schema
@Data
public class AIMobileTelemetryDto {

    private String deviId;
    private String eventId;
    private String cameraId;
    private String regionId;
    private String regionName;
    private String objectId;
    private String dataTime;
    private String eventType;
    private String eventSubType;
    private String vehicleType;

    private String plateNo;
    private String eventTime;
    private String eventStartDt;
    private String eventEndDttm;
    private String startPhoto;
    private String startPhotoId;
    private String endPhoto;
    private String endPhotoId;

    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        for (Field field : this.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            try {
                map.put(field.getName(), field.get(this));
            } catch (IllegalAccessException e) {
                // 處理異常，可以選擇忽略或者記錄日誌
                e.printStackTrace();
            }
        }
        return map;
    }
}
