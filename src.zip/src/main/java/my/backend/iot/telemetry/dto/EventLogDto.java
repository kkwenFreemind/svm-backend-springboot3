package my.backend.iot.telemetry.dto;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;

@Data
@Setter
@Getter
public class EventLogDto {

    private String uuid;
    private String projectId;
    private String deviceId;
    private String rssi;
    private String battery;
    private String val;
    private LocalDateTime measureTime;
}
