package my.backend.iot.telemetry.code;

import lombok.Getter;

@Getter
public enum EventTypeEnum {
    INPUT_ERROR(1, "input_error", "市電異常", "收到市電斷電訊號時", null, "【{0}】《警告》市電輸入異常", ""),
    BATTERY_LEVEL_50_PERCENT(2, "battery_level_50_percent", "剩餘電量50%", "電量低於50%", null, "【{0}】《警告》電量告警", "電池電量低於50%\\r\\n電池ID：{1}\\r\\n電池槽位：{2}"),
    BATTERY_LEVEL_40_PERCENT(3, "battery_level_40_percent", "剩餘電量40%", "電量低於40%", null, "【{0}】《警告》電量告警", "電池電量低於40%\\r\\n電池ID：{1}\\r\\n電池槽位：{2}"),
    BATTERY_LEVEL_35_PERCENT(4, "battery_level_35_percent", "剩餘電量35%", "電量低於35%", null, "【{0}】《警告》電量告警", "電池電量低於35%\\r\\n電池ID：{1}\\r\\n電池槽位：{2}"),
    BATTERY_LEVEL_30_PERCENT(5, "battery_level_30_percent", "剩餘電量30%", "電量低於30%", null, "【{0}】《警告》電量告警", "電池電量低於30%\\r\\n電池ID：{1}\\r\\n電池槽位：{2}"),
    BATTERY_LEVEL_25_PERCENT(6, "battery_level_25_percent", "剩餘電量25%", "電量低於25%", null, "【{0}】《警告》電量告警", "電池電量低於25%\\r\\n電池ID：{1}\\r\\n電池槽位：{2}"),
    BATTERY_LEVEL_20_PERCENT(7, "battery_level_20_percent", "剩餘電量20%", "電量低於20%", null, "【{0}】《警告》電量告警", "電池電量低於20%\\r\\n電池ID：{1}\\r\\n電池槽位：{2}"),
    BATTERY_LEVEL_15_PERCENT(8, "battery_level_15_percent", "剩餘電量15%", "電量低於15%", null, "【{0}】《警告》電量告警", "電池電量低於15%\\r\\n電池ID：{1}\\r\\n電池槽位：{2}"),
    BATTERY_LEVEL_0_PERCENT(9, "battery_level_0_percent", "剩餘電量0%", "電量等於0%", null, "【{0}】《警告》電量告警", "電池電量耗盡\\r\\n電池ID：{1}\\r\\n電池槽位：{2}"),
    BATTERY_CHANGE_START(10, "battery_change_start", "市電異常透過面板開始換電池", "市電異常透過面板收到開始換電訊號時", null, "【{0}】《通知》開始換電！", ""),
    BATTERY_CHANGE_END(11, "battery_change_end", "市電異常透過面板結束換電池", "市電異常透過面板收到結束換電訊號時", null, "【{0}】《通知》結束換電！", ""),
    BATTERY_DISCONNECT(12, "battery_disconnect", "電池連線異常", "收到電池離線訊號時", null, "【{0}】《警告》電池異常", "〔{1}〕電池連線異常!"),
    BATTERY_TEMPERATURE_ERROR(13, "battery_temperature_error", "電池異常", "電池溫度超出正常值域", 10, "【{0}】《警告》電池異常", "電池溫度異常！！\\r\\n電池ID：{1}\\r\\n電池槽位：{2}"),
    BATTERY_HIGH_TEMPERATURE_ERROR(14, "battery_high_temperature_error", "電池異常", "電池溫度超出正常值域(高溫)", 10, "【{0}】《警告》電池異常", "電池溫度異常(高溫)！！\\r\\n電池ID：{1}\\r\\n電池槽位：{2}"),
    OVER_N_MINUTES_NO_RESPONSE(15, "over_n_minutes_no_response", "超過10分鐘未收到資料", "資料超過10分鐘未回傳", null, "【{0}】《警告》斷線告警", "超過{1}分鐘未收到資料!"),
    OVER_30_MINUTES_NO_RESPONSE(16, "over_30_minutes_no_response", "超過30分鐘未收到資料", "資料超過30分鐘未回傳", null, "【{0}】《警告》斷線告警", "超過{1}分鐘未收到資料!"),
    UPS_DISCONNECT(17, "ups_disconnect", "UPS RS232斷線", "收到UPS離線訊號時", null, "【{0}】《警告》UPS異常", "UPS連線異常！！"),
    UPS_OVERLOAD(18, "ups_overload", "UPS負載過高", "收到UPS負載過高訊號時", null, "【{0}】《警告》UPS異常", "UPS負載過高！！"),
    UPS_TEMPERATURE_ERROR(19, "ups_temperature_error", "UPS溫度異常", "UPS溫度超出正常值域", 10, "【{0}】《警告》UPS異常", "UPS溫度異常！！"),
    INPUT_RESET(20, "input_reset", "市電恢復正常", "收到市電復電訊號時", null, "【{0}】《通知》市電輸入恢復正常", ""),
    BATTERY_CONNECT_RESET(21, "battery_connect_reset", "電池恢復正常", "收到電池連線訊號時", null, "【{0}】《通知》〔{1}〕電池連線恢復正常", ""),
    ////
    UPS_ENABLE(22, "ups_enable", "UPS切換為電池模式", "收到UPS電池模式切換訊號時", null, "【{0}】《通知》UPS切換為電池模式", ""),
    UPS_DISABLE(23, "ups_disable", "UPS切換為市電模式", "收到UPS市電模式切換訊號時", null, "【{0}】《通知》UPS切換為市電模式", ""),
    UPS_WAIT(24, "ups_wait", "UPS進入待機模式", "收到UPS進入待機模式訊號時", null, "【{0}】《警告》UPS進入待機模式", ""),
    UPS_SHUTDOWN(25, "ups_shutdown", "UPS進入待機模式", "收到UPS進入待機模式訊號且電池電量不足時", null, "【{0}】《警告》UPS進入待機模式", "電池電量不足"),
    BATTERY_REMOVE(26, "battery_remove", "電池已被移除", "電池於市電正常狀態下移除", null, "【{0}】《通知》電池已被移除!", "目前路口電池已被移除!"),
    BATTERY_INSTALL(27, "battery_install", "電池已被安裝", "電池於市電正常狀態下安裝", null, "【{0}】《通知》電池已被安裝!", "目前路口電池已被安裝!"),
    BATTERY_CHANGE_ERROR(28, "battery_change_error", "電池已被移除", "電池未依正常程序更換", null, "【{0}】《警告》電池已被移除!", "請依正常程序執行換電"),
    BATTERY_CHANGE_INFO_ERROR(29, "battery_change_info_error", "電池資訊異常", "電池換電資訊異常", null, "【{0}】《警告》電池資訊異常!", "請執行復原程序"),
    ;

    private final Integer eventNumber;
    private final String eventType;
    private final String description;
    private final String condition;
    private final Integer continuousInterval;
    private final String title;
    private final String message;

    EventTypeEnum(Integer eventNumber, String eventType, String description, String condition, Integer continuousInterval, String title, String message) {
        this.eventNumber = eventNumber;
        this.eventType = eventType;
        this.description = description;
        this.condition = condition;
        this.continuousInterval = continuousInterval;
        this.title = title;
        this.message = message;
    }

    public static EventTypeEnum getByEventType(String eventType) {

        for (EventTypeEnum tmp : values()) {
            if (tmp.getEventType().equals(eventType)) {
                return tmp;
            }
        }
        return null;
    }

}
