package my.backend.iot.telemetry.dto;

import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.Data;

import java.util.HashMap;
import java.util.Map;

@Data
public class ResponseWrapper {

    private String typeName;
    private Object entity;

    public ResponseWrapper(String typeName, Object entity) {
        this.typeName = typeName;
        this.entity = entity;
    }

    public Map<String, Object> entityToMap() throws Exception {
        ObjectMapper objectMapper = new ObjectMapper();
        return objectMapper.convertValue(this.entity, Map.class);
    }

}
