package my.backend.iot.telemetry.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import my.backend.persistence.model.*;
import my.backend.persistence.repository.*;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.expression.EvaluationContext;
import org.springframework.expression.Expression;
import org.springframework.expression.ExpressionParser;
import org.springframework.expression.spel.standard.SpelExpressionParser;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.*;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@Service
public class JsonComparisonService {

    @Resource
    private EventRecordRepo eventRecordRepository;
    @Resource
    private ConditionRepo conditionRepository;

    @Resource
    private EventCountRepo eventCountRepository;

    @Resource
    private ConditionNextRepo conditionNextRepo;

    @Resource
    private DeviceTelemetryRepo deviceTelemetryRepository;

    private final ObjectMapper objectMapper = new ObjectMapper();

    private final ExpressionParser parser = new SpelExpressionParser();

    @Value("${wdms.full_value}")
    private double fullValue;

    public List<String> compareWithRecords(Map<String, Object> input) throws JsonProcessingException {
        List<String> results = new ArrayList<>();

        JsonNode jsonNode = objectMapper.valueToTree(input);
        String projectId = (String) input.get("projectId");
        String stationId = (String) input.get("stationId");

        // 比較與上一條記錄
        DeviceTelemetryEntity lastRecord = deviceTelemetryRepository.findTopByProjectIdAndOrderByCreatedAtDesc(projectId);
        if (Objects.nonNull(lastRecord)) {
            JsonNode lastNode = objectMapper.readTree(lastRecord.getJsonData());
            List<ConditionNextEntity> conditions = conditionNextRepo.findAll();

            for (ConditionNextEntity condition : conditions) {
                String field = condition.getFieldName();
                double threshold = condition.getThreshold();
                String comparisonType = condition.getComparisonType();
                String eventName = condition.getEventName();

                double value1 = jsonNode.get(field).asDouble();
                double value2 = lastNode.path(field).asDouble(0);

                EventRecordEntity eventRecord = eventRecordRepository.findTopByEventNameOrderByStartTimeDesc(projectId, stationId, eventName);
                if (projectId.equals(condition.getProjectId())) {
                    if (exceedsThreshold(value1, value2, threshold, comparisonType)) {
                        handleEventStart(eventRecord, eventName, projectId, stationId);
                        EventCountEntity eventCount = incrementEventCount(projectId, stationId, eventName);
                        if (eventCount.getEventCount().equals(condition.getSuccessThreshold())) {
                            results.add(eventName);
                        }
                    } else {
                        resetEventCount(projectId, stationId, eventName);
                        handleEventEnd(eventRecord);
                    }
                }
            }
        }

        // 比較與警報條件
        List<ConditionEntity> conditions = conditionRepository.findAll();
        List<Map<String, Object>> dataList = deviceTelemetryRepository.findAll().stream()
                .map(record -> {
                    try {
                        return objectMapper.readValue(record.getJsonData(), new TypeReference<Map<String, Object>>() {});
                    } catch (JsonProcessingException e) {
                        log.error("Error processing JSON record: {}", record.getJsonData(), e);
                        return null;
                    }
                })
                .filter(Objects::nonNull)
                .collect(Collectors.toList());

        StandardEvaluationContext context = new StandardEvaluationContext(input);

        for (ConditionEntity condition : conditions) {
            String eventName = condition.getEventName();
            EventRecordEntity eventRecord = eventRecordRepository.findTopByEventNameOrderByStartTimeDesc(projectId, stationId, eventName);

            context.setVariable("fullValue", fullValue);
            if (projectId.equals(condition.getProjectId())) {
                if (evaluateCondition(context, condition.getConditionDescription())) {
                    handleEventStart(eventRecord, eventName, projectId, stationId);
                    EventCountEntity eventCount = incrementEventCount(projectId, stationId, eventName);
                    if (eventCount.getEventCount() == condition.getSuccessThreshold()) {
                        results.add(eventName);
                    }
                } else {
                    resetEventCount(projectId, stationId, eventName);
                    handleEventEnd(eventRecord);
                }
            }
        }

        try {
            String jsonString = objectMapper.writeValueAsString(input);
            saveJsonRecord(jsonString, projectId);
        } catch (JsonProcessingException e) {
            log.error("Error converting input to JSON: {}", input, e);
        }

        if(results.isEmpty()){
            results.add("沒有觸發事件");
        }
        return results;
    }

    private void handleEventStart(EventRecordEntity eventRecord, String eventType, String projectId, String deviceId) {
        if (eventRecord == null || eventRecord.getEndTime() != null) {

            ProjectInfoEntity projectInfoEntity = new ProjectInfoEntity();
            projectInfoEntity.setProjectId(projectId);

            DeviceInfoEntity deviceInfoEntity = new DeviceInfoEntity();
            deviceInfoEntity.setDeviceId(deviceId);

            EventRecordEntity newRecord = new EventRecordEntity();
            newRecord.setId(UUID.randomUUID().toString());
            newRecord.setEventType(eventType);
            newRecord.setStartTime(LocalDateTime.now());
            newRecord.setProjectInfo(projectInfoEntity);
            newRecord.setDeviceInfo(deviceInfoEntity);
            eventRecordRepository.save(newRecord);
        }
    }

    private void handleEventEnd(EventRecordEntity eventRecord) {
        if (eventRecord != null && eventRecord.getEndTime() == null) {
            eventRecord.setEndTime(LocalDateTime.now());
            eventRecordRepository.save(eventRecord);
        }
    }

    private void saveJsonRecord(String jsonData,String projectId) {

        ProjectInfoEntity projectInfoEntity = new ProjectInfoEntity();
        projectInfoEntity.setProjectId(projectId);
        DeviceTelemetryEntity record = new DeviceTelemetryEntity();
        record.setJsonData(jsonData);
        record.setCreatedAt(LocalDateTime.now());
        record.setProjectInfo(projectInfoEntity);
        deviceTelemetryRepository.save(record);
    }

    private boolean exceedsThreshold(double value1, double value2, double threshold, String comparisonType) {
        if ("percentage".equals(comparisonType)) {
            return Math.abs(value1 - value2) / value1 > threshold;
        } else if ("absolute".equals(comparisonType)) {
            return Math.abs(value1 - value2) >= threshold;
        }
        return false;
    }

    private EventCountEntity incrementEventCount(String projectId, String deviceId, String eventName) {


        EventCountEntity eventCount = eventCountRepository.findByProjectIdAndStationIdAndEventType(projectId, deviceId, eventName)
                .orElseGet(() -> {

                    ProjectInfoEntity projectInfoEntity = new ProjectInfoEntity();
                    projectInfoEntity.setProjectId(projectId);

                    DeviceInfoEntity deviceInfoEntity = new DeviceInfoEntity();
                    deviceInfoEntity.setDeviceId(deviceId);

                    EventCountEntity newEventCount = new EventCountEntity();
                    newEventCount.setId(UUID.randomUUID().toString());
                    newEventCount.setProjectInfo(projectInfoEntity);
                    newEventCount.setDeviceInfo(deviceInfoEntity);
                    newEventCount.setEventType(eventName);
                    newEventCount.setEventCount(0);
                    return newEventCount;
                });

        eventCount.setEventCount(eventCount.getEventCount() + 1);
        return eventCountRepository.save(eventCount);
    }

    private void resetEventCount(String projectId, String deviceId, String eventName) {
        EventCountEntity eventCount = eventCountRepository.findByProjectIdAndStationIdAndEventType(projectId, deviceId, eventName)
                .orElseGet(() -> {

                    ProjectInfoEntity projectInfoEntity = new ProjectInfoEntity();
                    projectInfoEntity.setProjectId(projectId);

                    DeviceInfoEntity deviceInfoEntity = new DeviceInfoEntity();
                    deviceInfoEntity.setDeviceId(deviceId);

                    EventCountEntity newEventCount = new EventCountEntity();
                    newEventCount.setId(UUID.randomUUID().toString());
                    newEventCount.setProjectInfo(projectInfoEntity);
                    newEventCount.setDeviceInfo(deviceInfoEntity);
                    newEventCount.setEventType(eventName);
                    newEventCount.setEventCount(0);
                    return newEventCount;
                });

        eventCount.setEventCount(0);
        eventCountRepository.save(eventCount);
    }

    private boolean evaluateCondition(EvaluationContext context, String conditionDescription) {

        try {
            Expression expression = parser.parseExpression(conditionDescription);
            return Boolean.TRUE.equals(expression.getValue(context, Boolean.class));
        } catch (Exception e) {
            // Log the exception instead of printing the stack trace
            log.error("Error evaluating condition: {}", conditionDescription, e);
            return false;
        }
    }

    private double calculateAverageValue(List<Map<String, Object>> dataList, String field) {
        return dataList.stream()
                .filter(data -> data.containsKey(field))
                .mapToDouble(data -> ((Number) data.get(field)).doubleValue())
                .average()
                .orElse(0);
    }

    private Set<String> extractFieldsFromCondition(String conditionDescription) {

        return Pattern.compile("\\['(\\w+)'\\]")
                .matcher(conditionDescription)
                .results()
                .map(matchResult -> matchResult.group(1))
                .collect(Collectors.toSet());
    }

    private double calculateStandardDeviation(List<Map<String, Object>> dataList, String field) {
        double mean = 0;
        double sumOfSquares = 0;
        int count = 0;

        for (Map<String, Object> data : dataList) {
            if (data.containsKey(field)) {
                double value = ((Number) data.get(field)).doubleValue();
                count++;
                double delta = value - mean;
                mean += delta / count;
                sumOfSquares += delta * (value - mean);
            }
        }
        return count > 1 ? Math.sqrt(sumOfSquares / (count - 1)) : 0;
    }
}
