package my.backend.iot.telemetry.service;

import org.springframework.integration.annotation.MessagingGateway;

@MessagingGateway(defaultRequestChannel = "mqttOutbound")
public class MqttMessageSender {

    void sendToMqtt(String data) {

    }
}
