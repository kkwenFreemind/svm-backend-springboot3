package my.backend.iot.telemetry.service;

import org.springframework.integration.annotation.ServiceActivator;
import org.springframework.stereotype.Component;
import org.springframework.messaging.Message;

@Component
public class MqttMessageReceiver {

    @ServiceActivator(inputChannel = "mqttInputChannel")
    public void handleMessage(Message<?> message) {
        System.out.println("Received message: " + message.getPayload());
    }
}
