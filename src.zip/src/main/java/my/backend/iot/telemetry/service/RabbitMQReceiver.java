package my.backend.iot.telemetry.service;

import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import my.backend.persistence.model.EventNotifySettingEntity;
import my.backend.persistence.model.EventRecordEntity;
import my.backend.persistence.repository.EventNotifySettingRepo;
import my.backend.persistence.repository.EventRecordRepo;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class RabbitMQReceiver {

    @Resource
    private EventRecordRepo eventRecordRepo;

    @Resource
    private EventNotifySettingRepo eventNotifySettingRepo;

    @RabbitListener(queues = "myQueue")
    public void receive(String message) {
        log.info("Received message: {}", message);

        EventRecordEntity eventRecordEntity = eventRecordRepo.findById(message).orElse(null);
        if (eventRecordEntity != null) {
            String projectId = eventRecordEntity.getProjectInfo().getProjectId();
            String deviceId = eventRecordEntity.getDeviceInfo().getDeviceId();
            String eventType = eventRecordEntity.getEventType();
            log.info("Notify start :{},{},{}", projectId, deviceId, eventType);

            EventNotifySettingEntity eventNotifySettingEntity = eventNotifySettingRepo.findByEventTypeAndProjectId(eventType,projectId);
            if (eventNotifySettingEntity != null) {
                log.info("Notify end :{},{},{}",eventNotifySettingEntity.getEventNotifySettingPk().getEventType(), eventNotifySettingEntity.getEmailNotifyGroup(), eventNotifySettingEntity.getLineNotifyGroup());
            }else{
                log.info("{},{},{} 沒有通知設定對象", projectId, deviceId, eventType);
            }
        }
    }
}
