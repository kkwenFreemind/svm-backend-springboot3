package my.backend.iot.telemetry.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.annotation.Resource;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import my.backend.admin.service.VendorService;
import my.backend.admin.controller.BaseController;
import my.backend.iot.telemetry.dto.AIMobileTelemetryDto;
import my.backend.iot.telemetry.dto.ResponseWrapper;
import my.backend.iot.telemetry.dto.WdmsTelemetryDto;
import my.backend.persistence.model.DeviceInfoEntity;
import my.backend.persistence.repository.DeviceInfoRepo;
import my.backend.iot.telemetry.service.EventService;
import my.backend.iot.telemetry.service.JsonErrorRecordService;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@RestController
@RequestMapping("${server.api-base-path}")
@RequiredArgsConstructor
@Validated
public class TelemetryController extends BaseController {

    @Resource
    private JsonErrorRecordService jsonErrorRecordService;

    @Resource
    private DeviceInfoRepo deviceInfoRepo;

    @Resource
    private EventService eventService;
    
    @Resource
    private VendorService vendorService;

    private static final DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmssX");


    @Operation(summary = "水情專用telemetry", description = "水情專用telemetry")
    @PostMapping("/v1/noauth/telemetry")
    public ResponseEntity<?> telemetryJson(@Validated @RequestBody WdmsTelemetryDto requestEntity, BindingResult bindingResult, HttpServletRequest request) throws Exception {

        AtomicBoolean checkflag = new AtomicBoolean(false);
        Map<String, Object> result = new HashMap<>();

        Optional.ofNullable(request.getHeader("Authorization"))
                .filter(authHeader -> authHeader.startsWith("Bearer "))
                .map(authHeader -> authHeader.substring(7))
                .map(vendorService::getVendor)
                .ifPresent(vendorInfoEntity -> checkflag.set(true));

        if(checkflag.get()) {
            String requestBody = new ObjectMapper().writeValueAsString(requestEntity);
            System.out.println("requestBody: " + requestBody);
            if (bindingResult.hasErrors()) {
                String errorMessage = bindingResult.getFieldErrors().stream()
                        .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                        .collect(Collectors.joining(", "));
                jsonErrorRecordService.saveErrorRequest(requestBody, errorMessage);
                return ResponseEntity.badRequest().body("Invalid request: " + errorMessage);
            }

            Map<String, Object> flatMap = new HashMap<>();
            Map<String, Object> errors = new HashMap<>();

            flatten(requestEntity.toMap(), flatMap, null);

            String deviceNo = (String) flatMap.get("stt_no");
            String measureTime = (String) flatMap.get("measure_time");

            DeviceInfoEntity deviceInfoEntity = deviceInfoRepo.findDeviceInfoEntityByDeviceNo(deviceNo);
            if (deviceInfoEntity != null) {
                flatMap.put("projectId", deviceInfoEntity.getProjectInfo().getProjectId());
                flatMap.put("deviceId", deviceInfoEntity.getDeviceId());
                flatMap.put("measureTime", measureTime);
                Stream.of("battery", "voltage", "rssi", "val")
                        .forEach(field -> convertAndPut(flatMap, errors, field));
                List<String> comparisonResult = eventService.eventCheck(flatMap);
                return ResponseEntity.ok(comparisonResult);
            } else {
                jsonErrorRecordService.saveErrorRequest(requestBody, "No station found for stt_no: " + deviceNo);
                result.put("stt_no", "No station found for stt_no: " + deviceNo);
            }
        }else{
            result.put("error", "Unauthorized");
        }
        return ResponseEntity.ok(result);
    }

    @Operation(summary = "交控專用telemetry", description = "交控專用telemetry")
    @PostMapping("/AIMobile/telemetry")
    public ResponseEntity<?> DeviceTelemetryJson(@Validated @RequestBody AIMobileTelemetryDto requestEntity, BindingResult bindingResult) throws Exception {

        String requestBody = new ObjectMapper().writeValueAsString(requestEntity);

        if (bindingResult.hasErrors()) {
            String errorMessage = bindingResult.getFieldErrors().stream()
                    .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                    .collect(Collectors.joining(", "));
            jsonErrorRecordService.saveErrorRequest(requestBody, errorMessage);
            return ResponseEntity.badRequest().body("Invalid request: " + errorMessage);
        }

        Map<String, Object> flatMap = new HashMap<>();
        Map<String, Object> errors = new HashMap<>();
        Map<String, Object> result = new HashMap<>();
        flatten(requestEntity.toMap(), flatMap, null);


        String deviceNo = (String) flatMap.get("deviId");
        String measureTime = (String) flatMap.get("dataTime");
        Stream.of("eventType", "eventSubType")
                .forEach(field -> convertAndPut(flatMap, errors, field));

        DeviceInfoEntity deviceInfoEntity = deviceInfoRepo.findDeviceInfoEntityByDeviceNo(deviceNo);
        if (deviceInfoEntity != null) {
            flatMap.put("projectId", deviceInfoEntity.getProjectInfo().getProjectId());
            flatMap.put("deviceId", deviceInfoEntity.getDeviceId());
            flatMap.put("measureTime", measureTime);
            List<String> comparisonResult = eventService.eventCheck(flatMap);
            return ResponseEntity.ok(comparisonResult);
        } else {
            jsonErrorRecordService.saveErrorRequest(requestBody, "No station found for stt_no: " + deviceNo);
            result.put("deviceNo", "No Device found for deviceNo: " + deviceNo);
        }
        
        return ResponseEntity.ok(result);
    }


    @Operation(summary = "通用telemetry", description = "通用telemetry")
    @PostMapping("/All/telemetry")
    public ResponseEntity<?> ABTelemetryJson(@RequestBody String requestBody, BindingResult bindingResult) throws Exception {



        ResponseEntity<?> responseEntity = isJsonType(requestBody);
        ResponseWrapper responseWrapper = (ResponseWrapper) responseEntity.getBody();
        Map<String, Object> result = new HashMap<>();

        if (responseWrapper != null) {

            // 取得類型名稱
            String typeName = responseWrapper.getTypeName();
            System.out.println("Type Name: " + typeName);

            // 取得實體物件
            Object entity = responseWrapper.getEntity();
            System.out.println("Entity: " + entity);


            if (bindingResult.hasErrors()) {
                String errorMessage = bindingResult.getFieldErrors().stream()
                        .map(fieldError -> fieldError.getField() + ": " + fieldError.getDefaultMessage())
                        .collect(Collectors.joining(", "));
                jsonErrorRecordService.saveErrorRequest(requestBody, errorMessage);
                return ResponseEntity.badRequest().body("Invalid request: " + errorMessage);
            }

            Map<String, Object> flatMap = new HashMap<>();
            Map<String, Object> errors = new HashMap<>();

            flatten(responseWrapper.entityToMap(), flatMap, null);

            // 根據類型名稱進行處理
            if ("wdmsTelemetryDto".equals(typeName)) {

                WdmsTelemetryDto wdmsTelemetryDto = (WdmsTelemetryDto) entity;
                // 處理 wdmsTelemetryDto

                String deviceNo = (String) flatMap.get("stt_no");
                String measureTime = (String) flatMap.get("measure_time");

                DeviceInfoEntity deviceInfoEntity = deviceInfoRepo.findDeviceInfoEntityByDeviceNo(deviceNo);
                if (deviceInfoEntity != null) {
                    flatMap.put("projectId", deviceInfoEntity.getProjectInfo().getProjectId());
                    flatMap.put("deviceId", deviceInfoEntity.getDeviceId());
                    flatMap.put("measureTime", measureTime);
                    Stream.of("battery", "voltage", "rssi", "val")
                            .forEach(field -> convertAndPut(flatMap, errors, field));
                    List<String> comparisonResult = eventService.eventCheck(flatMap);
                    return ResponseEntity.ok(comparisonResult);
                } else {
                    jsonErrorRecordService.saveErrorRequest(requestBody, "No station found for stt_no: " + deviceNo);
                    result.put("stt_no", "No station found for stt_no: " + deviceNo);
                }


            } else if ("aiMobileTelemetryDto".equals(typeName)) {

                AIMobileTelemetryDto aiMobileTelemetryDto = (AIMobileTelemetryDto) entity;

                String deviceNo = (String) flatMap.get("deviId");
                String measureTime = (String) flatMap.get("dataTime");
                Stream.of("eventType", "eventSubType")
                        .forEach(field -> convertAndPut(flatMap, errors, field));

                DeviceInfoEntity deviceInfoEntity = deviceInfoRepo.findDeviceInfoEntityByDeviceNo(deviceNo);
                if (deviceInfoEntity != null) {
                    flatMap.put("projectId", deviceInfoEntity.getProjectInfo().getProjectId());
                    flatMap.put("deviceId", deviceInfoEntity.getDeviceId());
                    flatMap.put("measureTime", measureTime);
                    List<String> comparisonResult = eventService.eventCheck(flatMap);
                    return ResponseEntity.ok(comparisonResult);
                } else {
                    jsonErrorRecordService.saveErrorRequest(requestBody, "No station found for stt_no: " + deviceNo);
                    result.put("deviceNo", "No Device found for deviceNo: " + deviceNo);
                }
            } else if ("Type3".equals(typeName)) {

                // 處理 type3
            }
        } else {
            System.out.println("Unknown JSON type or error occurred.");
        }

        return ResponseEntity.ok(result);
    }

    private ResponseEntity isJsonType(String requestBody) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            // 嘗試將JSON解析為Type1
            WdmsTelemetryDto wdmsTelemetryDto = objectMapper.readValue(requestBody, WdmsTelemetryDto.class);
            return ResponseEntity.ok(new ResponseWrapper("wdmsTelemetryDto", wdmsTelemetryDto));
        } catch (JsonProcessingException e1) {
            try {
                // 嘗試將JSON解析為Type2
                AIMobileTelemetryDto aiMobileTelemetryDto = objectMapper.readValue(requestBody, AIMobileTelemetryDto.class);
                return ResponseEntity.ok(new ResponseWrapper("aiMobileTelemetryDto", aiMobileTelemetryDto));
            } catch (JsonProcessingException e2) {
                // 如果都不匹配
                return ResponseEntity.badRequest().body("Unknown JSON type");
            }
        }
    }

    private void convertAndPut(Map<String, Object> flatMap, Map<String, Object> errors, String fieldName) {
        try {
            flatMap.computeIfPresent(fieldName, (key, value) -> Double.valueOf(value.toString()));
        } catch (NumberFormatException e) {
            errors.put(fieldName, "Field '" + fieldName + "' cannot be converted to Double: " + flatMap.get(fieldName));
        }
    }

    private static void flatten(Map<String, Object> source, Map<String, Object> target, String parentKey) {
        source.forEach((key, value) -> {
            String newKey = parentKey == null ? key : parentKey + "." + key;
            if (value instanceof Map) {
                flatten((Map<String, Object>) value, target, newKey);
            } else if (value instanceof Iterable) {
                flattenIterable((Iterable<?>) value, target, newKey);
            } else {
                target.put(newKey, value);
            }
        });
    }

    private static void flattenIterable(Iterable<?> iterable, Map<String, Object> target, String parentKey) {
        int index = 0;
        for (Object item : iterable) {
            flatten(Collections.singletonMap(String.valueOf(index), item), target, parentKey);
            index++;
        }
    }


}
