package my.backend.iot.telemetry.service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import my.backend.iot.telemetry.dto.EventLogDto;
import my.backend.iot.utils.IotUtil;
import my.backend.persistence.model.*;
import my.backend.persistence.repository.*;
import org.springframework.amqp.rabbit.core.RabbitTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.spel.support.StandardEvaluationContext;
import org.springframework.stereotype.Service;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.*;

@Slf4j
@Service
public class EventService {

    @Resource
    private ProjectEventSettingRepo projectEventSettingRepo;

    @Resource
    private EventRecordRepo eventRecordRepository;

    @Resource
    private ProjectInfoRepo projectInfoRepo;

    @Resource
    private DeviceTelemetryRepo deviceTelemetryRepo;

    @Resource
    private EventCountRepo eventCountRepository;

    @Resource
    private DeviceTelemetryRepo deviceTelemetryRepository;

    @Resource
    private DeviceInfoRepo deviceInfoRepo;

    @Resource
    private RabbitMQSender rabbitMQSender;

    @Resource
    private MqttMessageSender mqttMessageSender;

    private final ObjectMapper objectMapper = new ObjectMapper();

    private IotUtil iotUtil = new IotUtil();


    public void checkAvailability(){
        System.out.println("checkAvailability");
        String eventType = "availability";

        List<ProjectInfoEntity> projectInfoEntities = projectInfoRepo.findAll();
        for(ProjectInfoEntity projectInfoEntity : projectInfoEntities){
            String projectId = projectInfoEntity.getProjectId();
            Optional<ProjectEventSettingEntity> eventSettingEntity =  projectEventSettingRepo.findEventSettingByType(projectId,eventType);
            double alertValue = eventSettingEntity.get().getAlertThreshold();
            List<DeviceInfoEntity> deviceInfoEntities = deviceInfoRepo.findDeviceInfoEntityByProjectId(projectInfoEntity.getProjectId());
            for(DeviceInfoEntity  deviceInfoEntity : deviceInfoEntities){
                String stationId = deviceInfoEntity.getDeviceId();
                List<DeviceTelemetryEntity> entityList = deviceTelemetryRepo.findAll();
                Integer jsonCount = entityList.size();
                //先算出幾天前，該站點的json筆數 - A
                //若每分鐘一筆telemetry，則該站點應收1440筆
                //妥善率 = A / 1440
                double availabilityValue = iotUtil.calRoundingMode(( (double) jsonCount / 1440),5);
                log.info("stationId(availabilityValue)==>{}", availabilityValue);
                saveAvailability(eventType,projectId,stationId,availabilityValue);

                if(availabilityValue < alertValue){
                    eventType = "availability_abnormal";
                    saveAvailability(eventType,projectId,stationId,availabilityValue);
                }
            }
        }
    }

    public void checkOfflineStation() throws JsonProcessingException {

        System.out.println("checkOfflineStation");
        String eventType = "offline_station";

        List<ProjectInfoEntity> projectInfoEntities = projectInfoRepo.findAll();
        for(ProjectInfoEntity projectInfoEntity : projectInfoEntities){
            String projectId = projectInfoEntity.getProjectId();
            Optional<ProjectEventSettingEntity> eventSettingEntity = projectEventSettingRepo.findEventSettingByType(projectId,eventType);
            double alertValue = eventSettingEntity.get().getAlertThreshold();
            List<DeviceInfoEntity> deviceInfoRepoList = deviceInfoRepo.findDeviceInfoEntityByProjectId(projectInfoEntity.getProjectId());
            for(DeviceInfoEntity deviceInfoEntity : deviceInfoRepoList){
                String stationId = deviceInfoEntity.getDeviceId();
                LocalDateTime now = LocalDateTime.now();
                LocalDateTime localDateTime = now.minus(Math.round(alertValue), ChronoUnit.HOURS);
                Integer offlineStationCount = deviceTelemetryRepo.findRecordCountOfTelemetry(projectId,stationId,localDateTime);
                log.info("offlineStationCount: {}", offlineStationCount);

                EventRecordEntity eventRecord = eventRecordRepository.findTopByEventNameOrderByStartTimeDesc(projectId, stationId, eventType);
                if(offlineStationCount == 0){
                    handleEventStart(eventRecord, eventType, projectId, stationId,(double)offlineStationCount,LocalDateTime.now(),"null");
                    EventCountEntity eventCount = incrementEventCount(projectId, stationId, eventType);
                    if (eventCount.getEventCount().equals(eventSettingEntity.get().getSuccessThreshold())) {
                        //results.add(eventType);
                    }
                } else {
                    resetEventCount(projectId, stationId, eventType);
                    handleEventEnd(eventRecord,localDateTime);
                }
            }
        }
    }


    public List<String> eventCheck(Map<String, Object> input) throws JsonProcessingException {
        List<String> results = new ArrayList<>();

        String uuid = UUID.randomUUID().toString();
        JsonNode jsonNode = objectMapper.valueToTree(input);
        String projectId = (String) input.get("projectId");
        String deviceId = (String) input.get("deviceId");
        String rssi = jsonNode.get("rssi").asText();
        String val = jsonNode.get("val").asText();
        String battery = jsonNode.get("battery").asText();
        LocalDateTime localDateTime = iotUtil.calMeasureTime((String) input.get("measureTime"));

        EventLogDto eventLogDto = new EventLogDto();
        eventLogDto.setUuid(uuid);
        eventLogDto.setProjectId(projectId);
        eventLogDto.setDeviceId(deviceId);
        eventLogDto.setRssi(rssi);
        eventLogDto.setVal(val);
        eventLogDto.setBattery(battery);
        eventLogDto.setMeasureTime(localDateTime);

        // 比較與上一條記錄
        DeviceTelemetryEntity lastRecord = deviceTelemetryRepository.findTopByProjectIdAndOrderByCreatedAtDesc(projectId);

        if (Objects.nonNull(lastRecord)) {
            log.debug("==>{}", lastRecord.getId());
            JsonNode lastNode = objectMapper.readTree(lastRecord.getJsonData());
            List<ProjectEventSettingEntity> conditions = projectEventSettingRepo.findEventSettingByPreviousType(projectId);

            for (ProjectEventSettingEntity condition : conditions) {
                String field = condition.getConditionDescription();
                double threshold = condition.getAlertThreshold();
                String comparisonType = condition.getComparisonType();
                String eventType = condition.getEventType();

                double value1 = jsonNode.get(field).asDouble();
                double value2 = lastNode.path(field).asDouble(0);

                EventRecordEntity eventRecord = eventRecordRepository.findTopByEventNameOrderByStartTimeDesc(projectId, deviceId, eventType);
                if (projectId.equals(condition.getProjectInfo().getProjectId())) {
                    if (iotUtil.exceedsThreshold(value1, value2, threshold, comparisonType,eventLogDto)) {
                        handleEventStart(eventRecord, eventType, projectId, deviceId,value1,localDateTime,uuid);
                        EventCountEntity eventCount = incrementEventCount(projectId, deviceId, eventType);
                        if (eventCount.getEventCount().equals(condition.getSuccessThreshold())) {
                            results.add(eventType);
                        }
                    } else {
                        resetEventCount(projectId, deviceId, eventType);
                        handleEventEnd(eventRecord,localDateTime);
                    }
                }
            }
        }

        // 比較與警報條件
        List<ProjectEventSettingEntity> conditions = projectEventSettingRepo.findEventSettingByAlertValue(projectId);
        StandardEvaluationContext context = new StandardEvaluationContext(input);

        for (ProjectEventSettingEntity condition : conditions) {
            String eventType = condition.getEventType();
            Double alertValue = condition.getAlertThreshold();
            EventRecordEntity eventRecord = eventRecordRepository.findTopByEventNameOrderByStartTimeDesc(projectId, deviceId, eventType);

            context.setVariable("alertValue", alertValue);
            if (projectId.equals(condition.getProjectInfo().getProjectId())) {
                if (iotUtil.evaluateCondition(context, condition.getConditionDescription(), eventLogDto)) {
                    handleEventStart(eventRecord, eventType, projectId, deviceId,alertValue,localDateTime,uuid);
                    EventCountEntity eventCount = incrementEventCount(projectId, deviceId, eventType);
                    if (eventCount.getEventCount().equals(condition.getSuccessThreshold())) {
                        results.add(eventType);
                    }
                } else {
                    resetEventCount(projectId, deviceId, eventType);
                    handleEventEnd(eventRecord,localDateTime);
                }
            }
        }

        try {
            String jsonString = objectMapper.writeValueAsString(input);
            saveJsonRecord(jsonString, projectId, deviceId, localDateTime,uuid);
        } catch (JsonProcessingException e) {
            log.error("Error converting input to JSON: {}", input, e);
        }

        if (results.isEmpty()) {
            results.add("沒有觸發事件");
        }
        return results;
    }

    private void saveAvailability(String eventType, String projectId, String deviceId,Double eventValue ){

        ProjectInfoEntity projectInfoEntity = new ProjectInfoEntity();
        projectInfoEntity.setProjectId(projectId);

        DeviceInfoEntity deviceInfoEntity = new DeviceInfoEntity();
        deviceInfoEntity.setDeviceId(deviceId);

        EventRecordEntity eventRecord = new EventRecordEntity();
        eventRecord.setId(UUID.randomUUID().toString());
        eventRecord.setEventType(eventType);
        eventRecord.setProjectInfo(projectInfoEntity);
        eventRecord.setDeviceInfo(deviceInfoEntity);
        eventRecord.setEventValue(eventValue);
        eventRecord.setStartMeasureTime(LocalDateTime.now());
        eventRecord.setEndMeasureTime(LocalDateTime.now());
        eventRecord.setStartTime(LocalDateTime.now());
        eventRecord.setEndTime(LocalDateTime.now());
        eventRecord.setTelemetryUuid("null");
        eventRecordRepository.save(eventRecord);
    }

    private void handleEventStart(EventRecordEntity eventRecord, String eventType, String projectId, String deviceId,Double eventValue,LocalDateTime measureTime,String uuid) throws JsonProcessingException {
        if (eventRecord == null || eventRecord.getEndTime() != null) {

            ProjectInfoEntity projectInfoEntity = new ProjectInfoEntity();
            projectInfoEntity.setProjectId(projectId);

            DeviceInfoEntity deviceInfoEntity = new DeviceInfoEntity();
            deviceInfoEntity.setDeviceId(deviceId);

            EventRecordEntity newRecord = new EventRecordEntity();
            newRecord.setId(UUID.randomUUID().toString());
            newRecord.setEventType(eventType);
            newRecord.setStartTime(LocalDateTime.now());
            newRecord.setProjectInfo(projectInfoEntity);
            newRecord.setDeviceInfo(deviceInfoEntity);
            newRecord.setEventValue(eventValue);
            newRecord.setStartMeasureTime(measureTime);
            newRecord.setTelemetryUuid(uuid);
            eventRecordRepository.save(newRecord);

            rabbitMQSender.send(newRecord.getId());
            mqttMessageSender.sendToMqtt(newRecord.getId());
        }
    }

    private void handleEventEnd(EventRecordEntity eventRecord, LocalDateTime measureTime) {
        if (eventRecord != null && eventRecord.getEndTime() == null) {
            eventRecord.setEndTime(LocalDateTime.now());
            eventRecord.setEndMeasureTime(measureTime);
            eventRecordRepository.save(eventRecord);
        }
    }

    private void saveJsonRecord(String jsonData, String projectId,String stationId, LocalDateTime localDateTime,String uuid) {

        ProjectInfoEntity projectInfoEntity = new ProjectInfoEntity();
        projectInfoEntity.setProjectId(projectId);

        DeviceInfoEntity deviceInfoEntity = new DeviceInfoEntity();
        deviceInfoEntity.setDeviceId(stationId);

        DeviceTelemetryEntity record = new DeviceTelemetryEntity();
        record.setId(uuid);
        record.setJsonData(jsonData);
        record.setCreatedAt(LocalDateTime.now());
        record.setProjectInfo(projectInfoEntity);
        record.setMeasureTime(LocalDateTime.now());
        record.setMeasureTime(localDateTime);
        record.setDeviceInfo(deviceInfoEntity);
        deviceTelemetryRepository.save(record);
    }


    private EventCountEntity incrementEventCount(String projectId, String deviceId, String eventType) {

        EventCountEntity eventCount = eventCountRepository.findByProjectIdAndStationIdAndEventType(projectId, deviceId, eventType)
                .orElseGet(() -> {

                    ProjectInfoEntity projectInfoEntity = new ProjectInfoEntity();
                    projectInfoEntity.setProjectId(projectId);

                    DeviceInfoEntity deviceInfoEntity = new DeviceInfoEntity();
                    deviceInfoEntity.setDeviceId(deviceId);

                    EventCountEntity newEventCount = new EventCountEntity();
                    newEventCount.setId(UUID.randomUUID().toString());
                    newEventCount.setProjectInfo(projectInfoEntity);
                    newEventCount.setDeviceInfo(deviceInfoEntity);
                    newEventCount.setEventType(eventType);
                    newEventCount.setEventCount(0);
                    return newEventCount;
                });

        eventCount.setEventCount(eventCount.getEventCount() + 1);
        return eventCountRepository.save(eventCount);
    }

    private void resetEventCount(String projectId, String deviceId, String eventType) {
        EventCountEntity eventCount = eventCountRepository.findByProjectIdAndStationIdAndEventType(projectId, deviceId, eventType)
                .orElseGet(() -> {

                    ProjectInfoEntity projectInfoEntity = new ProjectInfoEntity();
                    projectInfoEntity.setProjectId(projectId);

                    DeviceInfoEntity deviceInfoEntity = new DeviceInfoEntity();
                    deviceInfoEntity.setDeviceId(deviceId);

                    EventCountEntity newEventCount = new EventCountEntity();
                    newEventCount.setId(UUID.randomUUID().toString());
                    newEventCount.setEventType(eventType);
                    newEventCount.setProjectInfo(projectInfoEntity);
                    newEventCount.setDeviceInfo(deviceInfoEntity);
                    newEventCount.setEventCount(0);
                    return newEventCount;
                });

        eventCount.setEventCount(0);
        eventCountRepository.save(eventCount);
    }

    private static LocalDateTime convertToLocalDateTime(String dateStr) {
        DateTimeFormatter formatter;

        if (dateStr.contains("-")) {
            // 格式: YYYY-MM-DD hh:mm:ss
            formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        } else {
            // 格式: 20240425T100000+08
            formatter = DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmssX");
        }

        return LocalDateTime.parse(dateStr, formatter);
    }

//    private double calculateAverageValue(List<Map<String, Object>> dataList, String field) {
//        return dataList.stream()
//                .filter(data -> data.containsKey(field))
//                .mapToDouble(data -> ((Number) data.get(field)).doubleValue())
//                .average()
//                .orElse(0);
//    }
//
//    private Set<String> extractFieldsFromCondition(String conditionDescription) {
//
//        return Pattern.compile("\\['(\\w+)'\\]")
//                .matcher(conditionDescription)
//                .results()
//                .map(matchResult -> matchResult.group(1))
//                .collect(Collectors.toSet());
//    }
//
//    private double calculateStandardDeviation(List<Map<String, Object>> dataList, String field) {
//        double mean = 0;
//        double sumOfSquares = 0;
//        int count = 0;
//
//        for (Map<String, Object> data : dataList) {
//            if (data.containsKey(field)) {
//                double value = ((Number) data.get(field)).doubleValue();
//                count++;
//                double delta = value - mean;
//                mean += delta / count;
//                sumOfSquares += delta * (value - mean);
//            }
//        }
//        return count > 1 ? Math.sqrt(sumOfSquares / (count - 1)) : 0;
//    }


}
