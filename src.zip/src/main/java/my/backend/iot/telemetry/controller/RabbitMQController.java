package my.backend.iot.telemetry.controller;

import jakarta.annotation.Resource;
import lombok.RequiredArgsConstructor;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import my.backend.iot.telemetry.service.RabbitMQSender;


@RestController
@RequestMapping("${server.api-base-path}")
@RequiredArgsConstructor
@Validated
public class RabbitMQController {

    @Resource
    private RabbitMQSender rabbitMQSender;

    @PostMapping("/rabbitmq/send")
    public String sendMessage(@RequestBody String message) {
        rabbitMQSender.send(message);
        return "Message sent to the RabbitMQ Queue Successfully";
    }
}
