package my.backend.iot.telemetry.service;


import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import my.backend.persistence.model.JsonErrorRecordEntity;
import my.backend.persistence.repository.JsonErrorRecordRepo;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.UUID;

@Slf4j
@Service
public class JsonErrorRecordService {

    @Resource
    private JsonErrorRecordRepo errorRequestRepository;

    public JsonErrorRecordEntity saveErrorRequest(String requestBody, String errorMessage) {
        JsonErrorRecordEntity errorRequestEntity = new JsonErrorRecordEntity();

        errorRequestEntity.setId(UUID.randomUUID().toString());
        errorRequestEntity.setJsonData(requestBody);
        errorRequestEntity.setErrorMessage(errorMessage);
        errorRequestEntity.setCreatedAt(LocalDateTime.now());
        return errorRequestRepository.save(errorRequestEntity);
    }
}
