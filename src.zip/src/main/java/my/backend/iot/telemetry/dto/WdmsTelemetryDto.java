package my.backend.iot.telemetry.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import my.backend.common.validation.DoubleString;
import my.backend.common.validation.TimestampString;
import my.backend.common.validation.ValidSttNo;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

@Schema
@Data
public class WdmsTelemetryDto {

    @NotEmpty
    @ValidSttNo
    private String stt_no;

    @NotEmpty
    @DoubleString
    private String battery;

    @NotEmpty
    @DoubleString
    private String voltage;

    @NotEmpty
    @DoubleString
    private String rssi;

    @NotEmpty
    @DoubleString
    private String val;

    @NotEmpty
    @TimestampString
    private String measure_time;

    public Map<String, Object> toMap() {
        Map<String, Object> map = new HashMap<>();
        for (Field field : this.getClass().getDeclaredFields()) {
            field.setAccessible(true);
            try {
                map.put(field.getName(), field.get(this));
            } catch (IllegalAccessException e) {
                // 處理異常，可以選擇忽略或者記錄日誌
                e.printStackTrace();
            }
        }
        return map;
    }
}
