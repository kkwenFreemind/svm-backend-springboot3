package my.backend.config;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import jakarta.persistence.EntityManagerFactory;
import lombok.extern.slf4j.Slf4j;
import org.flywaydb.core.Flyway;
import org.flywaydb.core.internal.info.MigrationInfoDumper;
import org.hibernate.jpa.HibernatePersistenceProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.flyway.FlywayMigrationInitializer;
import org.springframework.boot.autoconfigure.flyway.FlywayMigrationStrategy;
import org.springframework.boot.autoconfigure.flyway.FlywayProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.DependsOn;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import java.util.Properties;

@Configuration
@EnableJpaRepositories(
        entityManagerFactoryRef = "entityManager",
        transactionManagerRef = "transactionManager",
        basePackages = "my.backend.persistence.repository")
@EnableTransactionManagement
@Slf4j
public class DBPrimaryConfig {

    public static final String PERSISTENCE_UNIT_NAME = "";
    public static final String[] MODEL_PACKAGE = new String[]{"my.backend.persistence.model"};

    @Primary
    @Bean
    public HikariDataSource dataSource() {
        return new HikariDataSource(hikariConfig());
    }

    @Primary
    @Bean
    @DependsOn("flywayInitializer")
    public LocalContainerEntityManagerFactoryBean entityManager(final HikariDataSource dataSource) {
        return new LocalContainerEntityManagerFactoryBean() {
            {
                setDataSource(dataSource());
                setPersistenceProviderClass(HibernatePersistenceProvider.class);
                setJpaProperties(jpaProperties());
                setPackagesToScan(MODEL_PACKAGE);
                setJpaVendorAdapter(new HibernateJpaVendorAdapter());
                setPersistenceUnitName(PERSISTENCE_UNIT_NAME);
            }
        };
    }

    @Primary
    @Bean
    @ConfigurationProperties(prefix = "flyway")
    @ConditionalOnProperty(
            prefix = "spring.flyway",
            name = {"enabled"},
            matchIfMissing = true)
    public Flyway flyway() {
        log.info("#################### {} ####################", "flyway");
        HikariConfig hikariConfig = hikariConfig();
        FlywayProperties props = flywayProperties();
        props.setUrl(hikariConfig.getJdbcUrl().replaceFirst("log4jdbc:", ""));
        props.setUser(hikariConfig.getUsername());
        props.setPassword(hikariConfig.getPassword());
        Flyway flyway =
                Flyway.configure()
                        .dataSource(props.getUrl(), props.getUser(), props.getPassword())
                        .defaultSchema(props.getDefaultSchema())
                        .schemas(props.getSchemas().stream().toArray(String[]::new))
                        .locations(props.getLocations().stream().toArray(String[]::new))
                        .baselineOnMigrate(true)
                        .baselineVersion("1.0.0")
                        .validateMigrationNaming(true)
                        .validateOnMigrate(true)
                        .load();
        return flyway;
    }

    @Primary
    @Bean
    @ConditionalOnProperty(
            prefix = "spring.flyway",
            name = {"enabled"},
            matchIfMissing = true)
    FlywayMigrationInitializer flywayInitializer(Flyway flyway) {
        log.info("#################### flywayInitializer() ####################");
        log.info(
                "================================================================================================");
        FlywayMigrationStrategy strategy =
                new FlywayMigrationStrategy() {
                    @Override
                    public void migrate(Flyway flyway) {
                        log.info("-----------------------------------------------------------------------");
                        log.info("\n{}", MigrationInfoDumper.dumpToAsciiTable(flyway.info().all()));
                        flyway.migrate();
                        log.info("\n{}", MigrationInfoDumper.dumpToAsciiTable(flyway.info().all()));
                        log.info("-----------------------------------------------------------------------");
                    }
                };

        return new FlywayMigrationInitializer(flyway, strategy);
    }

    @Primary
    @Bean
    @ConfigurationProperties(prefix = "datasource.primary.flyway")
    public FlywayProperties flywayProperties() {
        return new FlywayProperties();
    }

    @Primary
    @Bean
    @ConfigurationProperties(prefix = "datasource.primary.hikari")
    public HikariConfig hikariConfig() {
        return new HikariConfig();
    }

    @Primary
    @Bean
    @ConfigurationProperties("datasource.primary.jpa.properties")
    public Properties jpaProperties() {
        return new Properties();
    }

    @Primary
    @Bean
    public PlatformTransactionManager transactionManager(EntityManagerFactory entityManager) {
        return new JpaTransactionManager(entityManager);
    }
}
