package my.backend.config;

import jakarta.annotation.Resource;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import my.backend.config.convertor.JwtAuthConverter;
import my.backend.config.handler.CustomAccessDeniedHandler;
import my.backend.config.handler.CustomAuthEntryPoint;
import my.backend.security.jwt.AuthEntryPointJwt;
import my.backend.security.jwt.AuthTokenFilter;
import my.backend.security.services.UserDetailsServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityCustomizer;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;

import java.util.Arrays;

import static org.springframework.security.config.http.SessionCreationPolicy.STATELESS;

@Configuration
//@EnableWebSecurity
@EnableMethodSecurity
@Slf4j
@RequiredArgsConstructor
public class SecurityConfig {

//
//    @Resource
//    private WhiteUrlsConfig whiteUrlsConfig;
//
//    @Resource
//    UserDetailsServiceImpl userDetailsService;
//
//    @Resource
//    private AuthEntryPointJwt unauthorizedHandler;
//
//    @Bean
//    public AuthTokenFilter authenticationJwtTokenFilter() {
//        return new AuthTokenFilter();
//    }
//
//    @Bean
//    public DaoAuthenticationProvider authenticationProvider() {
//
//        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider();
//
//        authProvider.setUserDetailsService(userDetailsService);
//        authProvider.setPasswordEncoder(passwordEncoder());
//
//        return authProvider;
//    }
//
//    @Bean
//    public AuthenticationManager authenticationManager(AuthenticationConfiguration authConfig) throws Exception {
//
//        return authConfig.getAuthenticationManager();
//    }
//
//    @Bean
//    public PasswordEncoder passwordEncoder() {
//        return new BCryptPasswordEncoder();
//    }
//
//    @Bean
//    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
//
//        http.csrf(csrf -> csrf.disable())
//                .exceptionHandling(exception -> exception.authenticationEntryPoint(unauthorizedHandler))
//                .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
//                .authorizeHttpRequests(auth -> auth
//                        .requestMatchers("/api/test/**").permitAll()
//                                .anyRequest().authenticated()
//                ).cors(cors -> cors.configurationSource(corsConfigurationSource()));
//
//        http.authenticationProvider(authenticationProvider());
//
//        http.addFilterBefore(authenticationJwtTokenFilter(), UsernamePasswordAuthenticationFilter.class);
//
//        return http.build();
//    }
//
//    CorsConfigurationSource corsConfigurationSource() {
//        final var configuration = new CorsConfiguration();
//
//        configuration.addAllowedOriginPattern("*");
//
//        configuration.setAllowedMethods(Arrays.asList("*"));
//        configuration.setAllowedHeaders(Arrays.asList("*"));
//        configuration.setExposedHeaders(Arrays.asList("*"));
//
//        final var source = new UrlBasedCorsConfigurationSource();
//        source.registerCorsConfiguration("/**", configuration);
//
//        return source;
//    }

    private final JwtAuthConverter jwtAuthConverter;
    @Value("${server.api-base-path}")
    private String apiBasePath;

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .csrf(AbstractHttpConfigurer::disable)
                .authorizeHttpRequests(authRegistry -> authRegistry
                        .requestMatchers(
                                apiBasePath + "/v1/auth/admin/version",
                                apiBasePath + "/v1/auth/user",
                                apiBasePath + "/v1/auth/device/install/check",
                                apiBasePath + "/v1/auth/device/install/detail/log",
                                apiBasePath + "/v1/auth/device/install/log",
                                apiBasePath + "/v1/auth/device/list",
                                apiBasePath + "/v1/auth/project/list",
                                apiBasePath + "/v1/auth/telemetry/time-series",
                                apiBasePath + "/v1/auth/telemetry/time-series/current",
                                apiBasePath + "/v1/auth/telemetry/time-series/status").hasAnyRole("SYSTEM_ADMIN", "PROJECT_ADMIN", "ENGINEER", "USER", "CLIENT_VIEWER")
                        .requestMatchers(
                                apiBasePath + "/v1/auth/event/error/log",
                                apiBasePath + "/v1/auth/event/error/statistics",
                                apiBasePath + "/v1/auth/event/input/error/**/**",
                                apiBasePath + "/v1/auth/event/log",
                                apiBasePath + "/v1/auth/event/setting",
                                apiBasePath + "/v1/auth/event/ups/work/log",
                                apiBasePath + "/v1/auth/intersection/battery/level",
                                apiBasePath + "/v1/auth/intersection/device/current",
                                apiBasePath + "/v1/auth/intersection/list",
                                apiBasePath + "/v1/auth/otp/user/otp-secret",
                                apiBasePath + "/v1/auth/otp/user/verify-code",
                                apiBasePath + "/v1/auth/project/user/list",
                                apiBasePath + "/v1/auth/setting/install/device/status/list",
                                apiBasePath + "/v1/auth/setting/project/params",
                                apiBasePath + "/v1/auth/setting/role/group/list",
                                apiBasePath + "/v1/auth/user/group/list",
                                apiBasePath + "/v1/auth/user/list",
                                apiBasePath + "/v1/auth/rabbitmq/send",
                                apiBasePath + "/v1/auth/user/project/default",
                                apiBasePath + "/v1/auth/user/update-secret",
                                apiBasePath + "/v1/auth/user/hello").hasAnyRole("SYSTEM_ADMIN", "PROJECT_ADMIN", "ENGINEER", "USER")
                        .requestMatchers(
                                apiBasePath + "/v1/auth/device/install/detail",
                                apiBasePath + "/v1/auth/device/install").hasAnyRole("SYSTEM_ADMIN", "PROJECT_ADMIN", "ENGINEER")
                        .requestMatchers(
                                apiBasePath + "/v1/auth/device",
                                apiBasePath + "/v1/auth/device/install/detail",
                                apiBasePath + "/v1/auth/device/unbind",
                                apiBasePath + "/v1/auth/event/setting",
                                apiBasePath + "/v1/auth/intersection",
                                apiBasePath + "/v1/auth/intersection/device/history",
                                apiBasePath + "/v1/auth/user/group").hasAnyRole("SYSTEM_ADMIN", "PROJECT_ADMIN")
                        .requestMatchers(
                                apiBasePath + "/v1/auth/admin/cache/refresh/all",
                                apiBasePath + "/v1/auth/admin/notify/status",
                                apiBasePath + "/v1/auth/admin/notify/status/count",
                                apiBasePath + "/v1/auth/admin/user/login/log",
                                apiBasePath + "/v1/auth/client",
                                apiBasePath + "/v1/auth/client/list",
                                apiBasePath + "/v1/auth/client/reset-secret",
                                apiBasePath + "/v1/auth/vendor",
                                apiBasePath + "/v1/auth/vendor/list",
                                apiBasePath + "/v1/auth/vendor/reset-secret",
                                apiBasePath + "/v1/auth/otp/admin/otp-secret",
                                apiBasePath + "/v1/auth/project",
                                apiBasePath + "/v1/auth/project/user").hasAnyRole("SYSTEM_ADMIN")
                        .anyRequest().authenticated());
        http
                .exceptionHandling(handlingConfigurer -> handlingConfigurer
                        .authenticationEntryPoint(new CustomAuthEntryPoint())
                        .accessDeniedHandler(new CustomAccessDeniedHandler()));
        http
                .oauth2ResourceServer(oAuth2Configurer -> oAuth2Configurer
                        .jwt(jwtConfigurer -> jwtConfigurer
                                .jwtAuthenticationConverter(jwtAuthConverter))
                        .authenticationEntryPoint(new CustomAuthEntryPoint()));
        http
                .sessionManagement(sessionConfig -> sessionConfig.sessionCreationPolicy(STATELESS));

        return http.build();
    }

    @Bean
    public WebSecurityCustomizer webSecurityCustomizer() {
        return (web) -> web.ignoring().requestMatchers(
                "/",
                apiBasePath + "/v3/api-docs/**",
                apiBasePath + "/swagger-ui/**",
                apiBasePath + "/v1/noauth/**",
                "/kkadmin/login",
                apiBasePath + "/actuator/**");
    }
}
