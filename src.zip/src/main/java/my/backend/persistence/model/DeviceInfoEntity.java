package my.backend.persistence.model;


import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;


@Data
@Entity
@Table(name = "device_info")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class DeviceInfoEntity {

    @Id
    @Column(name = "device_id", nullable = false, length = 50)
    private String deviceId;

    @ManyToOne
    @JoinColumn(name = "project_id", nullable = false)
    private ProjectInfoEntity projectInfo;

    @Column(name = "device_label", length = 255)
    private String deviceLabel;

    @Column(name = "device_no", length = 20)
    private String deviceNo;

    @Column(name = "county_code", length = 20)
    private String countyCode;

    @Column(name = "longitude")
    private Double longitude;

    @Column(name = "latitude")
    private Double latitude;

    @Column(name = "device_purpose", length = 255)
    private String devicePurpose;

    @Column(name = "transport_method", length = 30)
    private String transportMethod;

    @Column(name = "device_type", length = 255)
    private String deviceType;

    @Column(name = "device_status", length = 255)
    private String deviceStatus;


}
