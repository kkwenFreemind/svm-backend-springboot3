package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "json_error_records")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class JsonErrorRecordEntity {

    @Id
    private String id;

    @Column(name = "json_data")
    private String jsonData;

    @Column(name = "created_at")
    private LocalDateTime createdAt;

    @Column(name = "error_message")
    private String errorMessage;
}
