package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Data
@Entity
@Table(name = "ums_user_info")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class UmsUserInfoEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "user_id", length = 50, nullable = false)
    private Long userId;

    @Column(name = "user_name", length = 50, nullable = false)
    private String username;

    @Column(name = "user_password", length = 255, nullable = false)
    private String userPassword;

    @Column(name = "email", length = 100, nullable = false)
    private String email;

    @Column(name = "mobile", length = 20)
    private String mobile;

    @Column(name = "nick_name", length = 50)
    private String nickName;

    @Column(name = "note", length = 50)
    private String note;

    @Column(name = "status")
    private Boolean status;

    @CreatedDate
    @Column(name = "create_time")
    private LocalDateTime createTime;

    @LastModifiedDate
    @Column(name = "update_time")
    private LocalDateTime updateTime;

    @Column(name = "login_time")
    private LocalDateTime loginTime;

    @Column(name = "logout_time")
    private LocalDateTime logoutTime;

    @Column(name = "create_by", length = 50)
    private String createBy;

    @Column(name = "create_name", length = 50)
    private String createName;

    @Column(name = "update_by", length = 50)
    private String updateBy;

    @Column(name = "update_name", length = 50)
    private String updateName;

    @ManyToMany(fetch = FetchType.LAZY)
    @JoinTable(  name = "ums_user_roles",
            joinColumns = @JoinColumn(name = "user_id"),
            inverseJoinColumns = @JoinColumn(name = "role_id"))
    private Set<UmsRoleInfoEntity> roles = new HashSet<>();

    public UmsUserInfoEntity(String username, String email, String password) {
        this.username = username;
        this.email = email;
        this.userPassword = password;
        this.createTime = LocalDateTime.now();
        this.mobile = "0982158008";
        this.status = true;
        this.nickName = "hello";
        this.note = "hello";
        this.createBy = "1";
        this.createName = "hello";

    }

    public UmsUserInfoEntity() {

    }
}
