package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import my.backend.admin.controller.dto.ProjectDto;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "project_info")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class ProjectInfoEntity implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;
    @CreatedDate
    @Column(name = "create_time", nullable = false, updatable = false)
    private LocalDateTime createTime;
    @Column(name = "enabled", nullable = false)
    private Boolean enabled;
    @Id
    @Column(name = "project_id", nullable = false, unique = true)
    private String projectId;
    @Column(name = "project_label", nullable = false, unique = true)
    private String projectLabel;
    @LastModifiedDate
    @Column(name = "update_time")
    private LocalDateTime updateTime;

    public ProjectInfoEntity() {
    }
    public ProjectInfoEntity(ProjectDto projectDto) {
        this.projectId = projectDto.getProjectId();
        this.projectLabel = projectDto.getProjectLabel();
        this.enabled = true;
    }

    public Boolean isEnabled() {
        return this.isEnabled();
    }
}
