package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Data
@Entity
@Table(name = "conditions")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class ConditionEntity {
    @Id
    private Long id;

    @Column(name="project_id")
    private String projectId;

    @Column(name = "event_name")
    private String eventName;

    @Column(name = "condition_description")
    private String conditionDescription;

    @Column(name = "success_threshold")
    private int successThreshold;

}
