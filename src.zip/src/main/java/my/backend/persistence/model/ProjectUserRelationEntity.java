package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;


@Data
@Entity
@Table(name = "project_user_relation")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class ProjectUserRelationEntity {

    @Id
    @Column(name = "relation_id", nullable = false, length = 50)
    private String relationId;

    @ManyToOne
    @JoinColumn(name = "project_id", nullable = false)
    private ProjectInfoEntity projectInfo;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private UserInfoEntity userInfo;

    @Column(name = "create_time")
    private LocalDateTime createTime;

    @Column(name = "update_time")
    private LocalDateTime updateTime;
}
