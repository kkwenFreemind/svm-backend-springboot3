package my.backend.persistence.model;


import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Data
@Entity
@Table(name = "resources_info")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class ResourceInfoEntity {

    @Id
    @Column(name = "resource_id", nullable = false, length = 50)
    private String resourceId;

    @Column(name = "resource_label", nullable = false, length = 100)
    private String resourceLabel;

    @Column(name = "resource_url", nullable = false, length = 200)
    private String resourceUrl;

    @Column(name = "resource_description", length = 100)
    private String resourceDescription;

    @ManyToOne
    @JoinColumn(name = "resource_id", insertable = false, updatable = false)
    private RoleInfoEntity role;
}
