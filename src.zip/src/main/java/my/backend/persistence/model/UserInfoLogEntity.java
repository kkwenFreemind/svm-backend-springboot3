package my.backend.persistence.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "user_info_log")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class UserInfoLogEntity implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;
    @Column(name = "action_user_id", length = 50)
    private String actionUserId;
    @CreatedDate
    @Column(name = "create_time", nullable = false, updatable = false)
    private LocalDateTime createTime;
    @Column(name = "default_project_id", length = 50)
    private String defaultProjectId;
    @Column(name = "email", nullable = false, length = 200)
    private String email;
    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @Column(name = "password_update_time")
    private LocalDateTime passwordUpdateTime;
    @Column(name = "status", length = 10)
    private String status;
    @Column(name = "user_id", length = 50)
    private String userId;
    @Id
    @Column(name = "user_info_log_pk", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userInfoLogPk;
    @Column(name = "user_label", length = 200)
    private String userLabel;
    @Column(name = "user_role_group_name", length = 50)
    private String userRoleGroupName;
}
