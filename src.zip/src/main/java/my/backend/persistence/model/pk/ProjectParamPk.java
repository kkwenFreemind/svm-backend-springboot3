/* (C)2021 */
package my.backend.persistence.model.pk;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;
import lombok.ToString;

@Embeddable
@Data
@ToString
public class ProjectParamPk implements java.io.Serializable {
    private static final long serialVersionUID = 1L;

    @Column(name = "project_id", nullable = false)
    private String projectId;
    @Column(name = "param_no", nullable = false)
    private String paramNo;

    public ProjectParamPk() {
        super();
    }


    public ProjectParamPk(String projectId, String paramNo) {
        super();
        this.projectId = projectId;
        this.paramNo = paramNo;
    }
}
