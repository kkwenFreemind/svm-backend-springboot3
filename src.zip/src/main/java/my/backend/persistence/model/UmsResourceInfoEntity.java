package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serializable;
import java.time.LocalDateTime;


@Data
@Entity
@Table(name = "ums_resource_info")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class UmsResourceInfoEntity implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", nullable = false)
    private Long id;

    @CreatedDate
    @Column(name = "create_time")
    private LocalDateTime createTime;

    @Column(name = "resource_label", length = 255, nullable = false)
    private String resourceLabel;

    @Column(name = "resource_url", length = 255)
    private String resourceUrl;

    @Column(name = "description", length = 50)
    private String description;

    @Column(name = "category_id")
    private Integer categoryId;
}
