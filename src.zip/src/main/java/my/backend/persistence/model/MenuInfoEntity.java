package my.backend.persistence.model;


import com.google.common.util.concurrent.ClosingFuture;
import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "menu_info")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class MenuInfoEntity {

    @Id
    @Column(name = "menu_id", nullable = false, length = 50)
    private String menuId;

    @Column(name = "parent_id", nullable = false, length = 50)
    private String parentId;

    @Column(name = "menu_title", nullable = false, length = 100)
    private String menuTitle;

    @Column(name = "menu_level")
    private Integer menuLevel;

    @Column(name = "sort")
    private Integer sort;

    @Column(name = "menu_label", length = 100)
    private String menuLabel;

    @Column(name = "menu_icon", length = 50)
    private String menuIcon;

    @Column(name = "hidden")
    private Integer hidden;

    @Column(name = "create_time")
    private LocalDateTime createTime;

    @Column(name = "update_time")
    private LocalDateTime updateTime;

    @ManyToOne
    @JoinColumn(name = "menu_id", insertable = false, updatable = false)
    private RoleInfoEntity role;
}
