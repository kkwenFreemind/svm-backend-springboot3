package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serial;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "client_login_log")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class ClientLoginLogEntity {

    @Serial
    private static final long serialVersionUID = 1L;
    @Column(name = "client_id", length = 50)
    private String clientId;

    @Id
    @Column(name = "client_login_log_pk", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long clientLoginLogPk;

    @CreatedDate
    @Column(name = "create_time", nullable = false, updatable = false)
    private LocalDateTime createTime;

    @Column(name = "error_code", length = 5)
    private String errorCode;

    @Column(name = "ip_address", length = 50)
    private String ipAddress;

}
