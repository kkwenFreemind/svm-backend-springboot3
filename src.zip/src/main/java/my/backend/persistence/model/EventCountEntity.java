package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.util.UUID;

@Data
@Entity
@Table(name = "event_count")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class EventCountEntity {

    @Id
    @Column(name = "id", nullable = false, length = 50)
    private String id;

    @Column(name = "event_count")
    private Integer eventCount;

    @ManyToOne
    @JoinColumn(name = "project_id", nullable = false)
    private ProjectInfoEntity projectInfo;

    @ManyToOne
    @JoinColumn(name = "device_id", nullable = false)
    private DeviceInfoEntity deviceInfo;

    @Column(name = "event_type", nullable = false, length = 100)
    private String eventType;

}
