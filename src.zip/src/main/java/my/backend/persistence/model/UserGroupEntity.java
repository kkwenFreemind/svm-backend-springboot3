package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import my.backend.persistence.model.pk.UserGroupPk;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serial;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "user_group")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class UserGroupEntity {

    @Serial
    private static final long serialVersionUID = 1L;
    @CreatedDate
    @Column(name = "create_time", nullable = false, updatable = false)
    private LocalDateTime createTime;
    @LastModifiedDate
    @Column(name = "update_time", nullable = false)
    private LocalDateTime updateTime;
    @EmbeddedId
    private UserGroupPk userGroupPk;
}
