package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serial;

@Data
@Entity
@Table(name = "project_info_log")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class RoleInfoEntity {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "role_id", length = 50)
    private String roleId;

    @Column(name = "role_label",length = 50)
    private String roleLabel;

    @Column(name = "role_desc", length = 100)
    private String roleDesc;

}
