package my.backend.persistence.model;


import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Data
@Entity
@Table(name = "user_role_relation")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class UserRoleRelationEntity {

    @Id
    @Column(name = "user_role_id", nullable = false, length = 50)
    private String userRoleId;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private UserInfoEntity user;

    @ManyToOne
    @JoinColumn(name = "role_id", nullable = false)
    private RoleInfoEntity role;
}
