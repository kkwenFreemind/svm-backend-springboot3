package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "device_telemetry")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class DeviceTelemetryEntity {

    @Id
    @Column(name = "id", nullable = false, length = 50)
    private String id;

    @Column(name = "json_data", nullable = false, length = 800)
    private String jsonData;

    @Column(name = "created_at", nullable = true, columnDefinition = "timestamp default current_timestamp")
    private LocalDateTime createdAt;

    @ManyToOne
    @JoinColumn(name = "project_id", nullable = false)
    private ProjectInfoEntity projectInfo;

    @Column(name = "measure_time", nullable = false)
    private LocalDateTime measureTime;

    @ManyToOne
    @JoinColumn(name = "device_id", nullable = false)
    private DeviceInfoEntity deviceInfo;
}
