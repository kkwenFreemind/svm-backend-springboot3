/* (C)2021 */
package my.backend.persistence.model;



import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import my.backend.persistence.model.pk.ProjectParamPk;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "project_param")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class ProjectParamEntity implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;
    @CreatedDate
    @Column(name = "create_time", nullable = false, updatable = false)
    private LocalDateTime createTime;
    @Column(name = "memo", length = 200)
    private String memo;
    @Column(name = "param_value", length = 2000)
    private String paramValue;
    @EmbeddedId
    private ProjectParamPk projectParamPk;
    @LastModifiedDate
    @Column(name = "update_time")
    private LocalDateTime updateTime;

    public ProjectParamEntity(String projectId, String paramNo, String paramValue) {
        this.projectParamPk = new ProjectParamPk(projectId, paramNo);
        this.paramValue = paramValue;
    }

    public ProjectParamEntity() {
    }
}
