package my.backend.persistence.model.pk;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;
import lombok.ToString;

@Embeddable
@Data
@ToString
public class UserGroupPk implements java.io.Serializable{
    private static final long serialVersionUID = 1L;
    @Column(name = "user_group_id", nullable = false)
    private String userGroupId;
    @Column(name = "user_id", nullable = false)
    private String userId;

    public UserGroupPk() {
        super();
    }

    public UserGroupPk(String userId, String userGroupId) {
        super();
        this.userId = userId;
        this.userGroupId = userGroupId;
    }
}
