package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import my.backend.iot.telemetry.code.EventTypeEnum;
import my.backend.persistence.model.pk.EventNotifySettingPk;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serial;
import java.time.LocalDateTime;

@Entity
@Table(name = "event_notify_setting")
@Data
@ToString
@EntityListeners(AuditingEntityListener.class)
public class EventNotifySettingEntity {
    @Serial
    private static final long serialVersionUID = 1L;
    @Column(name = "continuous_interval")
    private Integer continuousInterval;
    @Column(name = "create_time", nullable = false, updatable = false)
    @CreatedDate
    private LocalDateTime createTime;
    @Column(name = "email_notify_enable", nullable = false)
    private Boolean emailNotifyEnable;
    @Column(name = "email_notify_group", length = 200)
    private String emailNotifyGroup;
    @Column(name = "event_condition", length = 200, nullable = false)
    private String eventCondition;
    @Column(name = "event_description", length = 200, nullable = false)
    private String eventDescription;
    @EmbeddedId
    private EventNotifySettingPk eventNotifySettingPk;
    @Column(name = "line_notify_enable", nullable = false)
    private Boolean lineNotifyEnable;
    @Column(name = "line_notify_group", length = 200)
    private String lineNotifyGroup;
    @Column(name = "message", length = 200)
    private String message;
    @Column(name = "show_in_event_list", nullable = false)
    private Boolean showInEventList;
    @Column(name = "title", length = 100)
    private String title;
    @LastModifiedDate
    @Column(name = "update_time")
    private LocalDateTime updateTime;


    public EventNotifySettingEntity(String projectId, EventTypeEnum eventType) {
        this.eventNotifySettingPk = new EventNotifySettingPk(projectId, eventType.getEventType());
        this.lineNotifyEnable = false;
        this.emailNotifyEnable = false;
        this.title = eventType.getTitle();
        this.message = eventType.getMessage();
        this.eventDescription = eventType.getDescription();
        this.eventCondition = eventType.getCondition();
        this.showInEventList = false;
    }

    public EventNotifySettingEntity() {

    }
}
