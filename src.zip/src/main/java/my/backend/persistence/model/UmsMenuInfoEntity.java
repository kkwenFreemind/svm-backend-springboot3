package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "ums_menu_info")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class UmsMenuInfoEntity implements Serializable {

    @Id
    @Column(name = "menu_id", length = 50, nullable = false)
    private String menuId;

    @Column(name = "parent_id")
    private Integer parentId;

    @CreatedDate
    @Column(name = "create_time")
    private LocalDateTime createTime;

    @Column(name = "menu_title", length = 50, nullable = false)
    private String menuTitle;

    @Column(name = "level")
    private Integer level;

    @Column(name = "sort")
    private Integer sort;

    @Column(name = "menu_label", length = 50)
    private String menuLabel;

    @Column(name = "icon", length = 255)
    private String icon;

    @Column(name = "hidden")
    private Boolean hidden;
}
