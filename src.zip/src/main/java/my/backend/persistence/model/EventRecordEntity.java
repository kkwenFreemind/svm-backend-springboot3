package my.backend.persistence.model;

import com.fasterxml.jackson.annotation.JsonFormat;
import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "event_records")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class EventRecordEntity {

    @Id
    @Column(name = "id", nullable = false, length = 50)
    private String id;

    @Column(name = "event_type", nullable = false, length = 200)
    private String eventType;

    @Column(name = "start_time")
    private LocalDateTime startTime;

    @Column(name = "end_time")
    private LocalDateTime endTime;

    @ManyToOne
    @JoinColumn(name = "project_id", nullable = false)
    private ProjectInfoEntity projectInfo;

    @ManyToOne
    @JoinColumn(name = "device_id", nullable = false)
    private DeviceInfoEntity deviceInfo;

    @Column(name = "event_value")
    private Double eventValue;

    @Column(name = "start_measure_time")
    private LocalDateTime startMeasureTime;

    @Column(name = "end_measure_time")
    private LocalDateTime endMeasureTime;

    @Column(name = "telemetry_uuid", length = 50)
    private String telemetryUuid;
}
