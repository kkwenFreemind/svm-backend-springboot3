/* (C)2021 */
package my.backend.persistence.model.pk;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;

@Embeddable
@Data
public class EventNotifySettingPk implements java.io.Serializable {
    private static final long serialVersionUID = 1L;
    @Column(name = "event_type", nullable = false)
    private String eventType;
    @Column(name = "project_id", nullable = false)
    private String projectId;

    public EventNotifySettingPk() {
        super();
    }

    public EventNotifySettingPk(String projectId, String eventType) {
        super();
        this.projectId = projectId;
        this.eventType = eventType;
    }
}
