package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "user_info")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class UserInfoEntity implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;
    @CreatedDate
    @Column(name = "create_time", nullable = false, updatable = false)
    private LocalDateTime createTime;
    @Column(name = "default_project_id", length = 50)
    private String defaultProjectId;
    @Column(name = "email", nullable = false, length = 200)
    private String email;
    @Column(name = "password_update_time")
    private LocalDateTime passwordUpdateTime;
    @LastModifiedDate
    @Column(name = "update_time", nullable = false)
    private LocalDateTime updateTime;
    @Id
    @Column(name = "user_id", unique = true, length = 50)
    private String userId;
    @Column(name = "user_label", length = 200)
    private String userLabel;
    @Column(name = "user_role_group_name", length = 50)
    private String userRoleGroupName;


}
