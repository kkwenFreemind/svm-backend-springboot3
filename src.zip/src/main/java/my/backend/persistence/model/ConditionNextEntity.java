package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Data
@Entity
@Table(name = "conditions_next")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class ConditionNextEntity {

    @Id
    private Long id;

    @Column(name = "event_name")
    private String eventName;

    @Column(name = "field_name")
    private String fieldName;

    private Double threshold;

    @Column(name = "comparison_type")
    private String comparisonType;

    @Column(name = "success_threshold")
    private Integer successThreshold;

    @Column(name = "project_id")
    private String projectId;
}
