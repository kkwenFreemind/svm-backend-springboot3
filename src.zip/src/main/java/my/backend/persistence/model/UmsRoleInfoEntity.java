package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "ums_role_info")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class UmsRoleInfoEntity implements Serializable {

    @Id
    @Column(name = "role_id", length = 50, nullable = false)
    private String roleId;

    @Column(name = "role_label", length = 255, nullable = false)
    private String roleLabel;

    @Column(name = "description", length = 50)
    private String description;

    @Column(name = "admin_count")
    private Integer adminCount;

    @CreatedDate
    @Column(name = "create_time")
    private LocalDateTime createTime;

    @Column(name = "status")
    private Boolean status;

    @Column(name = "sort")
    private Integer sort;


}
