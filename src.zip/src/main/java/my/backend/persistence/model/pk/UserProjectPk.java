package my.backend.persistence.model.pk;

import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.Data;
import lombok.ToString;

@Embeddable
@Data
@ToString
public class UserProjectPk {
    private static final long serialVersionUID = 1L;

    @Column(name = "user_id", nullable = false)
    private String userId;

    @Column(name = "project_id", nullable = false)
    private String projectId;

    public UserProjectPk() {
        super();
    }

    public UserProjectPk(String userId, String projectId) {
        super();
        this.userId = userId;
        this.projectId = projectId;
    }
}
