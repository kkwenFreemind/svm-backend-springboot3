package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "user_group_info_log")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class UserGroupInfoLogEntity implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;
    @Column(name = "action_user_id", length = 50)
    private String actionUserId;
    @CreatedDate
    @Column(name = "create_time", nullable = false, updatable = false)
    private LocalDateTime createTime;
    @Column(name = "line_token", length = 30)
    private String lineToken;
    @Column(name = "project_id", length = 50)
    private String projectId;
    @Column(name = "status", length = 10)
    private String status;
    @Column(name = "user_group_id", length = 50)
    private String userGroupId;
    @Id
    @Column(name = "user_group_info_log_pk", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userGroupInfoLogPk;
    @Column(name = "user_group_label", length = 200)
    private String userGroupLabel;
}
