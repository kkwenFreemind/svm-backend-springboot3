package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

@Data
@Entity
@Table(name = "project_event_setting")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class ProjectEventSettingEntity {

    @Id
    @Column(name = "id", nullable = false, length = 50)
    private String id;

    @ManyToOne
    @JoinColumn(name = "project_id")
    private ProjectInfoEntity projectInfo;

    @Column(name = "event_type", length = 30)
    private String eventType;

    @Column(name = "event_name", length = 100)
    private String eventName;

    @Column(name = "condition_description", length = 800)
    private String conditionDescription;

    @Column(name = "success_threshold")
    private Integer successThreshold;

    @Column(name = "immediate_alert")
    private Boolean immediateAlert;

    @Column(name = "schedule_alert")
    private Boolean scheduleAlert;

    @Column(name = "alert_threshold")
    private Double alertThreshold;

    @Column(name = "compare_with_previous")
    private Boolean compareWithPrevious;

    @Column(name = "comparison_type", length = 100)
    private String comparisonType;

    @Column(name = "email_alert")
    private Boolean emailAlert;

    @Column(name = "line_alert")
    private Boolean lineAlert;

    @Column(name = "line_frequency", length = 10)
    private String lineFrequency;
}
