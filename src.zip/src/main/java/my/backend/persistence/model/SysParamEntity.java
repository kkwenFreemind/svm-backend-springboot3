package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "sys_param")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class SysParamEntity implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @CreatedDate
    @Column(name = "create_time", nullable = false, updatable = false)
    private LocalDateTime createTime;

    @Column(name = "memo", length = 200)
    private String memo;

    @Id
    @Column(name = "param_no", unique = true, length = 50)
    private String paramNo;

    @Column(name = "param_value", length = 200)
    private String paramValue;

    @LastModifiedDate
    @Column(name = "update_time")
    private LocalDateTime updateTime;
}
