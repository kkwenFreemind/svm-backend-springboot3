package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "client_info")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class ClientInfoEntity implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "client_id", unique = true, length = 50)
    private String clientId;

    @Column(name = "client_label", length = 200)
    private String clientLabel;

    @Column(name = "client_name", length = 50)
    private String clientName;

    @Column(name = "client_role_group_name", length = 50)
    private String clientRoleGroupName;

    @CreatedDate
    @Column(name = "create_time", nullable = false, updatable = false)
    private LocalDateTime createTime;

    @Column(name = "project_id", length = 50)
    private String projectId;

    @Column(name = "secret_update_time")
    private LocalDateTime secretUpdateTime;

    @LastModifiedDate
    @Column(name = "update_time", nullable = false)
    private LocalDateTime updateTime;
}
