package my.backend.persistence.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.ToString;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "vendor_info")
@ToString
public class VendorInfoEntity {

    @Id
    @Column(name = "vendor_id", nullable = false, length = 50)
    private String vendorId;

    @Column(name = "vendor_label", length = 100)
    private String vendorLabel;

    @Column(name = "vendor_pwd", nullable = false, length = 100)
    private String vendorPwd;

    @Column(name = "vendor_token", nullable = false, length = 200)
    private String vendorToken;

    @Column(name ="project_id" , nullable = false, length = 50)
    private String projectId;

    @Column(name = "create_time")
    private LocalDateTime createTime;

    @Column(name = "update_time")
    private LocalDateTime updateTime;

}
