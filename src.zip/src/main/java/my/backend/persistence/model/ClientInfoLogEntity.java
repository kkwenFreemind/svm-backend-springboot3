package my.backend.persistence.model;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "client_info_log")
@ToString
@EntityListeners(AuditingEntityListener.class)
public class ClientInfoLogEntity  implements Serializable {
    @Serial
    private static final long serialVersionUID = 1L;
    @Column(name = "action_user_id", length = 50)
    private String actionUserId;
    @Column(name = "client_id", unique = true, length = 50)
    private String clientId;
    @Id
    @Column(name = "client_info_log_pk", nullable = false)
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long clientInfoLogPk;
    @Column(name = "client_label", length = 200)
    private String clientLabel;
    @Column(name = "client_name", length = 50)
    private String clientName;
    @Column(name = "client_role_group_name", length = 50)
    private String clientRoleGroupName;
    @CreatedDate
    @Column(name = "create_time", nullable = false, updatable = false)
    private LocalDateTime createTime;
    @Column(name = "project_id", length = 50)
    private String projectId;
    @Column(name = "secret_update_time")
    private LocalDateTime secretUpdateTime;
    @Column(name = "status", length = 10)
    private String status;

    @Override
    public String toString() {
        return "ClientInfoLogEntity{" +
                "actionUserId='" + actionUserId + '\'' +
                ", clientId='" + clientId + '\'' +
                ", clientInfoLogPk=" + clientInfoLogPk +
                ", clientLabel='" + clientLabel + '\'' +
                ", clientName='" + clientName + '\'' +
                ", clientRoleGroupName='" + clientRoleGroupName + '\'' +
                ", createTime=" + createTime +
                ", projectId='" + projectId + '\'' +
                ", secretUpdateTime=" + secretUpdateTime +
                ", status='" + status + '\'' +
                '}';
    }
}
