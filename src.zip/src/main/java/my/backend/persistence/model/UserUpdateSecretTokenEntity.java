package my.backend.persistence.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.ToString;

import java.io.Serial;
import java.io.Serializable;
import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "user_update_secret_token")
@ToString
public class UserUpdateSecretTokenEntity implements Serializable {

    @Serial
    private static final long serialVersionUID = 1L;
    @Id
    @Column(name = "user_id", length = 50, nullable = false, unique = true)
    private String userId;
    @Column(name = "token", length = 50, nullable = false)
    private String token;
    @Column(name = "execution", nullable = false)
    private Boolean execution;
    @Column(name = "expired_time")
    private LocalDateTime expiredTime;
}
