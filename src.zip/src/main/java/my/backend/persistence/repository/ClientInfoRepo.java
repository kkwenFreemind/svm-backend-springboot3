package my.backend.persistence.repository;

import my.backend.persistence.model.ClientInfoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ClientInfoRepo extends JpaRepository<ClientInfoEntity, String> {

    List<ClientInfoEntity> findAllByOrderByCreateTime();

    ClientInfoEntity findByClientId(String clientId);
}
