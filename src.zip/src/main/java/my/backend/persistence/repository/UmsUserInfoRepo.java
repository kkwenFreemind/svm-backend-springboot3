package my.backend.persistence.repository;

import my.backend.persistence.model.SysParamEntity;
import my.backend.persistence.model.UmsUserInfoEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UmsUserInfoRepo extends JpaRepository<UmsUserInfoEntity, Long> {

    @Query(value = "select * from ums_user_info where user_name = :username", nativeQuery = true)
    Optional<UmsUserInfoEntity> findByUsername(String username);

    Boolean existsByEmail(String email);
    Boolean existsByUsername(String username);
}
