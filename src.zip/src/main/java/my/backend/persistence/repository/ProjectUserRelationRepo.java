package my.backend.persistence.repository;

import my.backend.persistence.model.ProjectUserRelationEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectUserRelationRepo extends JpaRepository<ProjectUserRelationEntity, String> {
}
