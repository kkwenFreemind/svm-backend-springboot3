package my.backend.persistence.repository;

import my.backend.persistence.model.ClientLoginLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientLoginLogRepo extends JpaRepository<ClientLoginLogEntity, String> {
}
