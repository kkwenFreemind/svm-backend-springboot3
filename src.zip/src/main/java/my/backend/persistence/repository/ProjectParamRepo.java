/* (C)2021 */
package my.backend.persistence.repository;


import my.backend.persistence.model.ProjectParamEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProjectParamRepo extends JpaRepository<ProjectParamEntity, String> {

}
