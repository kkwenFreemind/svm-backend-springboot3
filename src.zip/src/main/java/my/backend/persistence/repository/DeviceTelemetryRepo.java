package my.backend.persistence.repository;


import my.backend.persistence.model.DeviceTelemetryEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;

public interface DeviceTelemetryRepo extends JpaRepository<DeviceTelemetryEntity, String> {

    @Query(value = "select  * from device_telemetry where project_id = :projectId order by measure_time desc limit 1", nativeQuery = true)
    DeviceTelemetryEntity findTopByProjectIdAndOrderByCreatedAtDesc(String projectId);

    @Query(value = "select count(*) from device_telemetry where project_id = :projectId and station_id = :stationId and measure_time between :startTime and NOW()",nativeQuery = true)
    Integer findRecordCountOfTelemetry(String projectId, String stationId, LocalDateTime startTime);
}
