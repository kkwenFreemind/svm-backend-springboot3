package my.backend.persistence.repository;

import my.backend.persistence.model.UserGroupInfoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserGroupInfoRepo extends JpaRepository<UserGroupInfoEntity, String> {

    List<UserGroupInfoEntity> findAllByProjectId(String projectId);

    List<UserGroupInfoEntity> findAllByProjectIdOrderByCreateTimeDesc(String projectId);

    UserGroupInfoEntity findByUserGroupId(String userGroupId);

    UserGroupInfoEntity findByUserGroupLabel(String userGroupLabel);
}
