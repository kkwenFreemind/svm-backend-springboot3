package my.backend.persistence.repository;

import my.backend.persistence.model.ProjectInfoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ProjectInfoRepo extends JpaRepository<ProjectInfoEntity, String> {

    List<ProjectInfoEntity> findAllByOrderByCreateTimeDesc();

    List<ProjectInfoEntity> findAllByProjectLabel(String projectLabel);

    ProjectInfoEntity findByProjectId(String projectId);

}
