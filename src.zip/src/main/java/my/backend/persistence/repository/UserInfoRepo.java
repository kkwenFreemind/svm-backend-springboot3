package my.backend.persistence.repository;

import my.backend.persistence.model.UserInfoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserInfoRepo extends JpaRepository<UserInfoEntity, String> {

    List<UserInfoEntity> findAllByOrderByCreateTimeDesc();

    UserInfoEntity findByUserId(String userId);

    UserInfoEntity findByEmail(String email);
}
