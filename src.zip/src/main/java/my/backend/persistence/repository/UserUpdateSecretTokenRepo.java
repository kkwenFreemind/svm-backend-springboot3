package my.backend.persistence.repository;

import my.backend.persistence.model.UserUpdateSecretTokenEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.time.LocalDateTime;

public interface UserUpdateSecretTokenRepo extends JpaRepository<UserUpdateSecretTokenEntity, String> {

    UserUpdateSecretTokenEntity findByUserId(String userId);

    UserUpdateSecretTokenEntity findTopByTokenIsAndExecutionIsAndExpiredTimeGreaterThanEqual(String token, Boolean isExecution, LocalDateTime dateTime);

    @Query(value = "select * from user_update_secret_token s where s.token = :token", nativeQuery = true)
    UserUpdateSecretTokenEntity findByToken(String token);
}
