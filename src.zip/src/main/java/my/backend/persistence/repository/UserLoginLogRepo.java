package my.backend.persistence.repository;

import my.backend.persistence.model.UserLoginLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UserLoginLogRepo extends JpaRepository<UserLoginLogEntity, Long> {
    //Page<UserLoginLogEntity> findAllByCreateTimeBetween(LocalDateTime start, LocalDateTime end, Pageable pageable);

}
