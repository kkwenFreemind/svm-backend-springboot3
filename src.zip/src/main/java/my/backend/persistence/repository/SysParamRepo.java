package my.backend.persistence.repository;

import my.backend.persistence.model.SysParamEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SysParamRepo extends JpaRepository<SysParamEntity, String> {
}
