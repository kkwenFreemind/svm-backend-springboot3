package my.backend.persistence.repository;

import my.backend.persistence.model.UserProjectEntity;
import my.backend.persistence.model.pk.UserProjectPk;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserProjectRepo extends JpaRepository<UserProjectEntity, UserProjectPk> {

    List<UserProjectEntity> findAllByUserProjectPkProjectId(String projectId);

    List<UserProjectEntity> findAllByUserProjectPkUserId(String userId);
}
