package my.backend.persistence.repository;

import my.backend.persistence.model.UserLoginLogEntity;
import my.backend.persistence.model.UserRoleRelationEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRoleRelationRepo extends JpaRepository<UserRoleRelationEntity, String> {
}
