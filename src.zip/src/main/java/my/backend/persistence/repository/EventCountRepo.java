package my.backend.persistence.repository;

import my.backend.persistence.model.EventCountEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Optional;

public interface EventCountRepo extends JpaRepository<EventCountEntity, String> {

//    Optional<EventCountEntity> findByEventName(String eventName);

    @Query(value = "select * from event_count where project_id = :projectId and device_id = :deviceId and event_type = :eventType", nativeQuery = true)
    Optional<EventCountEntity> findByProjectIdAndStationIdAndEventType(String projectId, String deviceId, String eventType);
}
