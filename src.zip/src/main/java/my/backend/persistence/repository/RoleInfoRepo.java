package my.backend.persistence.repository;

import my.backend.persistence.model.ProjectInfoEntity;
import my.backend.persistence.model.RoleInfoEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleInfoRepo  extends JpaRepository<RoleInfoEntity, String> {
}
