package my.backend.persistence.repository;

import my.backend.persistence.model.UserGroupInfoLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserGroupInfoLogRepo extends JpaRepository<UserGroupInfoLogEntity, String> {

}