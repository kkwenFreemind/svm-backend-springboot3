package my.backend.persistence.repository;

import my.backend.persistence.model.DeviceInfoEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface DeviceInfoRepo extends JpaRepository<DeviceInfoEntity, String> {

    @Query(value = "select * from device_info where device_no = :deviceNo", nativeQuery = true)
    DeviceInfoEntity findDeviceInfoEntityByDeviceNo(String deviceNo);

    @Query(value ="select * from device_info where project_id = :projectId", nativeQuery = true)
    List<DeviceInfoEntity> findDeviceInfoEntityByProjectId(String projectId);
}
