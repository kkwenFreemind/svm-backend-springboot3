package my.backend.persistence.repository;

import my.backend.persistence.model.ClientInfoLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ClientInfoLogRepo extends JpaRepository<ClientInfoLogEntity, String> {
}
