package my.backend.persistence.repository;

import my.backend.persistence.model.ProjectEventSettingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface ProjectEventSettingRepo extends JpaRepository<ProjectEventSettingEntity, String> {

    @Query(value = "select * from project_event_setting where project_id = :projectId and compare_with_previous = true and immediate_alert = true", nativeQuery = true)
    List<ProjectEventSettingEntity> findEventSettingByPreviousType(String projectId);

    @Query(value = "select * from project_event_setting where project_id = :projectId and compare_with_previous = false and immediate_alert = true", nativeQuery = true)
    List<ProjectEventSettingEntity> findEventSettingByAlertValue(String projectId);

    @Query(value = "select * from project_event_setting where project_id = :projectId and schedule_alert = true and event_type = :eventType",nativeQuery = true)
    Optional<ProjectEventSettingEntity> findEventSettingByType(String projectId, String eventType);
}
