package my.backend.persistence.repository;

import my.backend.persistence.model.UserGroupEntity;
import my.backend.persistence.model.pk.UserGroupPk;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface UserGroupRepo extends JpaRepository<UserGroupEntity, UserGroupPk> {

    List<UserGroupEntity> findAllByUserGroupPkUserGroupId(String userGroupId);

    List<UserGroupEntity> findAllByUserGroupPkUserId(String userId);

}
