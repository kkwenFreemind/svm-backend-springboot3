package my.backend.persistence.repository;

import my.backend.persistence.model.VendorInfoEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface VendorInfoRepo  extends JpaRepository<VendorInfoEntity, String> {

    @Query(value ="select * from vendor_info where vendor_token = ?1", nativeQuery = true)
    VendorInfoEntity findByVendorToken(String token);
}
