package my.backend.persistence.repository;

import my.backend.persistence.model.ChangeSecretLogEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChangeSecretLogRepo extends JpaRepository<ChangeSecretLogEntity, String> {
}
