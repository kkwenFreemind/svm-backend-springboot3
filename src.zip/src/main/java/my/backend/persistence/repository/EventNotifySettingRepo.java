package my.backend.persistence.repository;

import my.backend.persistence.model.EventNotifySettingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface EventNotifySettingRepo  extends JpaRepository<EventNotifySettingEntity, String> {

    @Query(value = "select * from event_notify_setting where event_type = :eventType and project_id = :projectId", nativeQuery = true)
    EventNotifySettingEntity findByEventTypeAndProjectId(String eventType, String projectId);
}
