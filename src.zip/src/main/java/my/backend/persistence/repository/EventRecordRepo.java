package my.backend.persistence.repository;

import io.lettuce.core.dynamic.annotation.Param;
import my.backend.persistence.model.EventRecordEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface EventRecordRepo extends JpaRepository<EventRecordEntity, String> {

    //找這個事件最後一筆
    @Query(value = "select * from event_records where project_id = :projectId and device_id = :deviceId and event_type = :eventType order by start_measure_time desc limit 1", nativeQuery = true)
    EventRecordEntity findTopByEventNameOrderByStartTimeDesc(String projectId, String deviceId, String eventType);

}
