package my.backend.persistence.repository;

import my.backend.persistence.model.RoleInfoEntity;
import my.backend.persistence.model.UmsRoleInfoEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Optional;

public interface UmsRoleInfoRepo  extends JpaRepository<UmsRoleInfoEntity, Long> {

    @Query(value = "select * from ums_role_info where role_label = :roleLabel", nativeQuery = true)
    Optional<UmsRoleInfoEntity> findByRoleLabel(String roleLabel);

    @Query(value = "select role_label from ums_role_info where role_id = 1", nativeQuery = true)
    List<String> getRoleLabelByRoleId(Long roleId);
}
