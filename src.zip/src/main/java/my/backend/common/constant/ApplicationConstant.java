package my.backend.common.constant;

public class ApplicationConstant {

    public static final String serverIpSet = "server_ip_set";

    private ApplicationConstant() {
    }

}
