package my.backend.common.error;

import java.util.Arrays;

public enum ErrorCode {

    SUCCESS("00000", "Success", "成功"),
    // 1xxxx Authentication and Permission
    ACCESS_TOKEN_INVALID("10001", "Access Token Invalid", "帳號密碼錯誤"),
    ACCESS_TOKEN_GET_INFO_FAILED("10002", "Failed to get access token information", "獲取 Access Token 信息失敗"),
    ACCOUNT_LOCKED("10003", "Account Locked", "帳戶被鎖定"),
    ROLE_PERMISSION_DENIED("10004", "Role Permission Denied", "角色權限被拒絕"),
    REFRESH_TOKEN_INVALID("10005", "Refresh Token Invalid", "Refresh Token 失效"),
    ROLE_GROUP_NOT_FOUND("10006", "Role Group Not Found", "系統尚未建立此角色群組"),
    ACCESS_IMAGE_INVALID("10007", "Access Image Invalid", "圖形驗證錯誤"),
    TOTP_INVALID("10008", "TOTP Invalid", "TOTP驗證碼錯誤"),
    TOTP_EXISTED("10009", "TOTP Existed", "此帳號已註冊"),
    TOTP_NOT_EXIST("10010", "TOTP Existed", "此帳號TOTP不存在"),

    // 2xxxx Project User Management
    USER_MANAGEMENT_CONFLICT("20001", "User Management Conflict", "新增使用者管理相關帳號或角色群組發生衝突"),
    USER_NOT_FOUND("20002", "User Not Found", "查無此使用者"),
    PROJECT_NOT_FOUND("20003", "Project Not Found", "查無此專案"),
    RESET_SECRET_ERROR("20004", "Reset Secret Error", "密碼請輸入長度至少8碼且包含英數字大小寫各一字元且不能與前5次密碼相同"),
    INVALID_SECRET_HISTORY("20005", "Invalid Secret History", "密碼不能與前5次密碼相同"),
    ROLE_GROUP_ID_NOT_FOUND("20006", "Role Group Id Not Found", "查無此角色群組"),
    PROJECT_LABEL_CONFLICT("20007", "Project Label Conflict", "專案名稱重複"),
    USER_GROUP_NOT_FOUND("20008", "User Group Not Found", "查無使用者群組"),
    CLIENT_NOT_FOUND("20009", "Client Not Found", "查無此客戶端"),
    USER_NOT_EXIST_IN_PROJECT("20010", "User not exist in project", "使用者不存在於此專案中"),
    USER_GROUP_LABEL_EXIST("20011", "User Group Label Exist", "使用者群組名稱重複"),
    CAT_CLIENT_ID_CONFLICT("20012", "Cat Client Id Conflict", "Cat Client Id 重複"),
    CAT_CLIENT_SECRET_CONFLICT("20013", "Cat Client Secret Conflict", "Cat Client Secret 重複"),
    RESET_SECRET_INVALID_TOKEN("20014", "Reset Secret Error", "設定或更新密碼權限過期"),
    UPDATE_SECRET_EMAIL_SEND_FAILED("20015", "Update Secret Email Send Failed", "更新密碼信件發送失敗，請再試一次"),
    DEFAULT_PROJECT_ID_NOT_IN_PROJECT_ID_LIST("20016", "Default Project Id Not In Project Id List", "預設專案ID不在專案ID清單中"),
    USER_MANAGEMENT_RESPONSE_ERROR("29999", "User Management Response Error", "使用者管理錯誤"),

    // 3xxxx Device Management
    DEVICE_MANAGEMENT_TOKEN_INVALID("30001", "Device Management Token Invalid", "裝置管理 Token 無效"),
    DEVICE_MANAGEMENT_PERMISSION_DENIED("30002", "Device Management Permission Denied", "裝置管理權限被拒絕"),
    DEVICE_MANAGEMENT_CONFLICT("30003", "Device Management Conflict", "新增裝置管理相關帳號或裝置發生衝突"),
    DEVICE_VENDOR_NOT_EXIST("30004", "Device Vendor Not Exist", "裝置廠商不存在"),
    DEVICE_TYPE_ERROR("30005", "Device Type Error", "裝置種類錯誤"),
    DEVICE_TELEMETRY_NOT_FOUND("30006", "Device Telemetry Not Found", "查無路口Telemetry資料(Telemetry資料僅保留三個月)"),
    DEVICE_MANAGEMENT_CREATE_DEVICE_FAILED("30007", "Device Management Create Device Failed", "裝置管理新增裝置失敗"),
    DEVICE_MANAGEMENT_UPDATE_DEVICE_FAILED("30008", "Device Management Update Device Failed", "裝置管理更新裝置失敗"),
    DEVICE_NOT_FOUND("30009", "Device Not Found", "查無裝置"),
    DEVICE_MANAGEMENT_DELETE_DEVICE_FAILED("30010", "Device Management Delete Device Failed", "設備無法刪除因為設備已經被綁定或是不存在"),
    DEVICE_MANAGEMENT_RESPONSE_ERROR("39999", "Device Management Response Error", "裝置管理錯誤"),

    // 4xxxx Intersection Management
    INTERSECTION_DUPLICATE("40001", "Intersection Duplicate", "新增路口發生衝突"),
    INTERSECTION_GROUP_NOT_EXIST("40002", "Intersection Group Not Exist", "路口群組不存在"),
    INTERSECTION_NOT_FOUND("40003", "Intersection Not Found", "查無路口"),
    INTERSECTION_INSTALL_DEVICE_LOG_NOT_FOUND("40004", "Intersection Install Device Log Not Found", "查無路口裝置安裝紀錄"),
    INTERSECTION_INSTALL_DEVICE_DETAIL_LOG_NOT_FOUND("40005", "Intersection Install Device Detail Log Not Found", "查無路口裝置安裝細節紀錄"),
    INTERSECTION_INSTALL_DEVICE_LOG_EXIST("40006", "Intersection Install Device Log Exist", "路口裝置安裝紀錄已存在"),
    INTERSECTION_STATUS_NOT_FOUND("40007", "Intersection Status Not Found", "查無路口狀態"),
    INTERSECTION_STATUS_NOT_NOT_INSTALL("40008", "Intersection Status Not Not Install", "路口狀態不是未安裝"),
    INTERSECTION_DEVICE_INFO_PROJECT_ID_NOT_MATCH("40009", "Intersection Device Info Project Id Not Match", "請確認設備是否已註冊於本專案"),
    INTERSECTION_TYPE_NOT_FOUND("40010", "Intersection Type Not Found", "查無路口類型"),

    // 5xxxx Event Management
    EVENT_NOTIFY_SETTING_NOT_FOUND("50001", "Event Notify Setting Not Found", "查無事件通知設定"),
    EVENT_TYPE_NOT_FOUND("50002", "Event Type Not Found", "查無事件類型"),
    LINE_NOTIFY_GROUP_NOT_FOUND("50003", "Line Notify Group Not Found", "查無 Line Notify 群組"),
    EVENT_LOG_FOUND_ERROR("50004", "Event Log Found Error", "查詢事件紀錄錯誤"),
    NOTIFY_EMAIL_SEND_FAILED("50005", "Notify Email Send Failed", "告警通知 Email 發送失敗"),
    INPUT_ERROR_EVENT_DETAIL_LOG_NOT_FOUND("50006", "Input Error Event Detail Log Not Found", "查無輸入錯誤事件細節紀錄"),
    // 9xxxx Runtime
    MISSING_REQUEST_INPUT("90001", "Missing Request Parameter", "缺少請求參數"),
    HTTP_MESSAGE_NOT_READABLE("90002", "Http Message Not Readable", "Http 訊息不可讀"),
    METHOD_ARGUMENT_NOT_VALID("90003", "Method Argument Not Valid", "方法參數無效"),
    TIME_NOT_NEGATIVE("90004", "Time Cannot Be Negative", "時間欄位不能為負值"),
    TIME_RANGE_ERROR("90005", "StartTime After EndTime", "起始時間大於終止時間"),
    NOT_OVER_31_DAYS_BETWEEN_STARTTIME_AND_ENDTIME("90005", "not over 31 days between startTime and endTime", "startTime 和 endTime 之間不超過 31 天"),
    SORT_IS_ASC_OR_DESC("90006", "Sort must be either ASC or DESC", "Sort 必須是 ASC 或 DESC"),
    EITHER_PROJECT_ID_OR_DEVICE_ID("90007", "Either projectId or deviceId must have a value", "projectId 或 deviceId 必須有一個值"),
    PAGE_SIZE_BETWEEN_1_AND_100("90008", "PageSize must be between 1 and 100", "PageSize 必須介於 1 到 100 之間"),
    PAGE_GREATER_EQUAL_0("90009", "Page must be greater than or equal to 0", "Page 必須大於或等於 0"),
    DATABASE_ERROR("90010", "Database Error", "資料庫錯誤"),
    PAGE_SIZE_CANNOT_BE_ZERO("90011", "PageSize cannot be zero", "PageSize 不能為零"),
    PAGE_SIZE_OR_TOTAL_ERROR("90012", "PageSize or total error", "PageSize 或 total 錯誤"),
    CACHE_REFRESH_FAILED("90013", "Cache Refresh Failed", "Cache 更新失敗"),
    INVALID_PARAMETER("90014", "Invalid Parameter", "參數錯誤"),
    UNKNOWN_ERROR_OCCURRED("99999", "Unknown Error Occurred", "發生未知錯誤"),
    ;

    private final String code;
    private final String reason;
    private final String message;

    ErrorCode(String code, String reason, String message) {
        this.code = code;
        this.reason = reason;
        this.message = message;
    }

    public static ErrorCode valueOf(int value) {
        return Arrays.stream(values()).filter(e -> e.getCode().equals(String.valueOf(value))).findAny()
                .orElseThrow(() -> new IllegalArgumentException("No matching error code for [" + value + "]"));
    }

    public String getCode() {
        return this.code;
    }

    public String getMessage() {
        return this.message;
    }

    public String getReason() {
        return this.reason;
    }

    @Override
    public String toString() {
        return this.code + " " + name();
    }

}
