package my.backend.common.error;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;

@Data
public class ResponsePayload<T> {

    @Schema(description = "回傳資料, 成功時才有值")
    private T body;
    @Schema(description = "錯誤代碼, 00表示成功, 其他表示失敗")
    private String errCode;
    @Schema(description = "錯誤細節描述, 成功時無此欄位")
    private String errDetail;
    @Schema(description = "錯誤訊息, 成功時無此欄位")
    private String errMsg;

    private ResponsePayload(String errCode) {
        this(errCode, null, null, null);
    }

    private ResponsePayload(String errCode, T body) {
        this(errCode, null, null, body);
    }

    private ResponsePayload(String errCode, String errMsg, String errDetail, T body) {
        this.errCode = errCode;
        this.errMsg = errMsg;
        this.errDetail = errDetail;
        this.body = body;
    }

    public ResponsePayload(ErrorCode errorCode, String errorDetail) {
        this.errCode = errorCode.getCode();
        this.errMsg = errorCode.getMessage();
        this.errDetail = errorDetail;
    }

    public static ResponsePayload<Object> success() {
        return new ResponsePayload<>("00");
    }

    public static <T> ResponsePayload<T> success(T body) {
        return new ResponsePayload<>("00", body);
    }
}
