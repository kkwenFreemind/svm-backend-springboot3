package my.backend.common.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.util.regex.Pattern;

public class DateTimeFormatValidator implements ConstraintValidator<ValidDateTimeFormat, String>{

    //20240799T120000+08
    private static final String DATE_TIME_PATTERN = "^\\d{8}T\\d{6}[+-]\\d{2}$";
    private static final Pattern PATTERN = Pattern.compile(DATE_TIME_PATTERN);

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null) {
            return false;
            // 或者返回 true，取決於你是否允許 null 值
        }
        return PATTERN.matcher(value).matches();
    }

}
