package my.backend.common.validation;

import jakarta.validation.Constraint;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Payload;

import java.lang.annotation.*;
import java.util.regex.Pattern;

@Documented
@Constraint(validatedBy = SttNoValidator.class)
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidSttNo {
    String message() default "必須符合 XXXXX-XXXXXX 格式";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}

