package my.backend.common.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

public class NotNullStringValidator implements ConstraintValidator<NotNullString, String>{

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        return value != null && !"null".equalsIgnoreCase(value.trim()) && !value.isEmpty();
    }

}
