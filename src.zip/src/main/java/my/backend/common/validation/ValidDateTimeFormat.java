package my.backend.common.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = DateTimeFormatValidator.class)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface ValidDateTimeFormat {

    String message() default "Invalid date time format. Expected format: yyyyMMdd'T'HHmmssZ";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
