package my.backend.common.validation;

import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;

import java.util.regex.Pattern;

public class SttNoValidator implements ConstraintValidator<ValidSttNo, String> {
    private static final Pattern STT_NO_PATTERN = Pattern.compile("^\\d{5}-\\d{6}$");

    @Override
    public void initialize(ValidSttNo constraintAnnotation) {}

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (value == null) {
            return true; // 如果允許 null 值，保留此行；否則返回 false
        }
        return STT_NO_PATTERN.matcher(value).matches();
    }
}
