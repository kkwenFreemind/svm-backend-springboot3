package my.backend.common.validation;

import jakarta.validation.Constraint;
import jakarta.validation.ConstraintValidator;
import jakarta.validation.ConstraintValidatorContext;
import jakarta.validation.Payload;

import java.lang.annotation.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

@Documented
@Constraint(validatedBy = TimestampStringValidator.class)
@Target({ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
public @interface TimestampString {
    String message() default "必須是有效的時間戳記字串，格式為yyyyMMdd'T'HHmmssX";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}

