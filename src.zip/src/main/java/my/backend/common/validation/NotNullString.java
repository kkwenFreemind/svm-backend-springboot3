package my.backend.common.validation;

import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.*;

@Documented
@Constraint(validatedBy = NotNullStringValidator.class)
@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
public @interface NotNullString {
    String message() default "Value cannot be null or 'null'";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
}
