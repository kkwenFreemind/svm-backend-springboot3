package my.backend.common.aop;

import com.google.common.base.Joiner;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.log4j.Log4j2;
import my.backend.common.error.ResponsePayload;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.MDC;
import org.springframework.web.context.request.ServletWebRequest;
import org.springframework.web.context.request.WebRequest;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.Duration;
import java.time.LocalDateTime;

@Log4j2
public class LoggingHelper {

    private LoggingHelper() {
    }

    public static void doErrorLog(Throwable t) {
        log.error(ExceptionUtils.getStackTrace(t));
    }

    public static void doErrorLog(String message, String logType, String clientIp) {
        MDC.put("clientIp", clientIp);
        MDC.put("logType", logType);
        log.error(message);
        MDC.put("clientIp", "");
        MDC.put("logType", "Error");
    }

    private static String getJoinedArgs(Object[] args) {
        return args == null ? null : Joiner.on(",").useForNull("null").join(args);
    }

    public static void info(String message, String logType, String clientIp) {
        MDC.put("clientIp", clientIp);
        MDC.put("logType", logType);
        log.info(message);
        MDC.put("clientIp", "");
        MDC.put("logType", "");
    }

    public static void toControllerProcessedLog(String className, String methodName, LocalDateTime start, Object[] args, Object result, LocalDateTime end, String clientIp) {
        String joinedArgs = getJoinedArgs(args);
        String builder = System.lineSeparator() + "   - class    : [" + className + "]" + System.lineSeparator() + "   - method   : [" + methodName + "]" + System.lineSeparator() + "   - Input    : [" + joinedArgs + "] " + System.lineSeparator() + "   - Output   : [" + result + "] " + System.lineSeparator() + "   - Started  : [" + start + "] " + System.lineSeparator() + "   - Ended    : [" + end + "] " + System.lineSeparator() + "   - Elapsed  : [" + Duration.between(start, end).toMillis() + "]" + System.lineSeparator() + "   - All done.";
        LoggingHelper.info(builder, "Controller", clientIp);
    }

    public static void toControllerRequestLog(String requestURI, Object[] args, String clientIp) {
        String joinedArgs = getJoinedArgs(args);
        String builder = System.lineSeparator() + "   - URI  : [" + requestURI + "]" + System.lineSeparator() + "   - Input : [" + joinedArgs + "] " + System.lineSeparator() + "   - All done.";
        LoggingHelper.info(builder, "Request", clientIp);
    }

    public static void toExceptionLogger(String className, String methodName, Object[] args, Throwable t, String clientIp) {
        String joinedArgs = getJoinedArgs(args);
        String builder = System.lineSeparator() + "   - class    : [" + className + "]" + System.lineSeparator() + "   - method   : [" + methodName + "]" + System.lineSeparator() + "   - Input    : [" + joinedArgs + "] " + System.lineSeparator() + "   - Message  : [" + ExceptionUtils.getStackTrace(t) + "]" + System.lineSeparator() + "   - All done.";
        LoggingHelper.doErrorLog(builder, "Exception", clientIp);
    }

    public static void toRequestInvalidLog(WebRequest request, ResponsePayload<Object> responsePayload, String clientIp) {
        LocalDateTime now = LocalDateTime.now();
        String requestURI = ((ServletWebRequest) request).getRequest().getRequestURI();
        String builder = System.lineSeparator() + "    - URI    :" + requestURI + "]" + System.lineSeparator() + "   - Started : [" + now + "]" + System.lineSeparator() + "   - output  : [" + responsePayload + "] " + System.lineSeparator() + "   - All done.";
        LoggingHelper.info(builder, "Invalid Request", clientIp);
    }

    public static void toServiceLog(String className, String methodName, LocalDateTime start, Object[] args, Object result, LocalDateTime end) {
        String joinedArgs = getJoinedArgs(args);
        String builder = System.lineSeparator() + "   - class    : [" + className + "]" + System.lineSeparator() + "   - method   : [" + methodName + "]" + System.lineSeparator() + "   - Input    : [" + joinedArgs + "] " + System.lineSeparator() + "   - Output   : [" + result + "] " + System.lineSeparator() + "   - Started  : [" + start + "] " + System.lineSeparator() + "   - Ended    : [" + end + "] " + System.lineSeparator() + "   - Elapsed  : [" + Duration.between(start, end).toMillis() + "]" + System.lineSeparator() + "   - All done.";
        LoggingHelper.info(builder, "Service", "");
    }

    public static void toScheduledLog(String className, String methodName, LocalDateTime start, LocalDateTime end) {
        String builder = System.lineSeparator() + "   - class    : [" + className + "]" + System.lineSeparator() + "   - method   : [" + methodName + "]" + System.lineSeparator() + "   - Started  : [" + start + "] " + System.lineSeparator() + "   - Ended    : [" + end + "] " + System.lineSeparator() + "   - Elapsed  : [" + Duration.between(start, end).toMillis() + "]" + System.lineSeparator() + "   - All done.";
        LoggingHelper.info(builder, "Scheduled", "");
    }

    public static String getClientIp(HttpServletRequest request) {
        String LOCALHOST_IPV4 = "127.0.0.1";
        String LOCALHOST_IPV6 = "0:0:0:0:0:0:0:1";
        String filterIpAddress = "";
        String ipAddress = request.getHeader("X-Forwarded-For");
        if (StringUtils.isEmpty(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader("Proxy-Client-IP");
        }
        if (StringUtils.isEmpty(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getHeader("WL-Proxy-Client-IP");
        }
        if (StringUtils.isEmpty(ipAddress) || "unknown".equalsIgnoreCase(ipAddress)) {
            ipAddress = request.getRemoteAddr();
            if (LOCALHOST_IPV4.equals(ipAddress) || LOCALHOST_IPV6.equals(ipAddress)) {
                InetAddress inetAddress = null;
                try {
                    inetAddress = InetAddress.getLocalHost();
                } catch (UnknownHostException e) {
                    throw new RuntimeException(e);
                }
                ipAddress = inetAddress.getHostAddress();
            }
        }
        if (!StringUtils.isEmpty(ipAddress) && isMatchRegexContent(ipAddress)) {
            filterIpAddress = ipAddress.substring(0, ipAddress.indexOf(","));
        } else {
            filterIpAddress = ipAddress;
        }
        //針對ipAddress做格式檢查要為IPV4或IPV6格式
        if (isNotMatchIpFormat(filterIpAddress)) {
            return "";
        }
        return filterIpAddress;
    }

    public static boolean isMatchRegexContent(String ipAddress) {
        return ipAddress.matches("^(?=.*[',]).{16,}$");
    }

    public static boolean isNotMatchIpFormat(String ipAddress) {
        return StringUtils.isEmpty(ipAddress) || (!ipAddress.matches("^(?!.*(?:^|\\.)(?:25[6-9]|2[6-9][0-9]|[3-9][0-9]{2}|[0-9]{4,})($|\\.))[0-9]{1,3}(?:\\.[0-9]{1,3}){3}$") && !ipAddress.matches("^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$"));
    }
}
