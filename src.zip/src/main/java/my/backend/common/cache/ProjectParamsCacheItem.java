package my.backend.common.cache;

import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import my.backend.persistence.model.ProjectParamEntity;
import my.backend.persistence.repository.ProjectParamRepo;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Component
public class ProjectParamsCacheItem extends ICacheItem {

    private Map<String, Map<String, String>> projectParamMapMap = null;
    @Resource
    private ProjectParamRepo projectParamRepo;

    public Map<String, Map<String, String>> getProjectParamMapMap() {
        if (projectParamMapMap == null) {
            loadProjectParams();
        }
        return projectParamMapMap;
    }

    @Override
    public void load() {
        loadProjectParams();
    }

    private synchronized void loadProjectParams() {
        if (projectParamMapMap != null) {
            return;
        }
        ////
        List<ProjectParamEntity> entities = projectParamRepo.findAll();
        this.projectParamMapMap = entities.stream()
                .collect(Collectors.groupingBy(
                        entity -> entity.getProjectParamPk().getProjectId(),
                        Collectors.toMap(
                                entity -> entity.getProjectParamPk().getParamNo(),
                                ProjectParamEntity::getParamValue,
                                (value1, value2) -> value1
                        )
                ));
    }

    @Override
    public void refresh() {
        if (projectParamMapMap != null) {
            projectParamMapMap.clear();
            projectParamMapMap = null;
        }
    }
}
