package my.backend.common.cache;

import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import my.backend.persistence.model.ProjectInfoEntity;
import my.backend.persistence.repository.ProjectInfoRepo;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Component
public class ProjectInfoCacheItem extends ICacheItem {

    private Map<String, ProjectInfoEntity> projectInfoMap = null;
    @Resource
    private ProjectInfoRepo projectInfoRepo;


    public Map<String, ProjectInfoEntity> getProjectInfoMap() {
        if (projectInfoMap == null) {
            loadProjectInfo();
        }
        return projectInfoMap;
    }

    @Override
    public void load() {
        loadProjectInfo();
    }

    /**
     * 載入系統變數的Map
     */
    private synchronized void loadProjectInfo() {
        if (this.projectInfoMap != null) {
            return;
        }
        ////
        this.projectInfoMap = projectInfoRepo.findAll().stream()
                .collect(Collectors.toMap(ProjectInfoEntity::getProjectId, Function.identity()));
    }

    @Override
    public void refresh() {
        ////
        if (projectInfoMap != null) {
            projectInfoMap.clear();
            projectInfoMap = null;
        }
    }

}
