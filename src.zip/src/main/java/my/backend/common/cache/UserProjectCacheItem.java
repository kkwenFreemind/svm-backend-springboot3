package my.backend.common.cache;

import jakarta.annotation.Resource;
import my.backend.persistence.model.UserProjectEntity;
import my.backend.persistence.repository.UserProjectRepo;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class UserProjectCacheItem  extends ICacheItem{

    private Map<String, Set<String>> userProjectMapByProjectId = null;
    private Map<String, Set<String>> userProjectMapByUserId = null;
    @Resource
    private UserProjectRepo userProjectRepo;

    public Map<String, Set<String>> getUserProjectMapByProjectId() {
        if (userProjectMapByProjectId == null) {
            loadUserProject();
        }
        return userProjectMapByProjectId;
    }

    public Map<String, Set<String>> getUserProjectMapByUserId() {
        if (userProjectMapByUserId == null) {
            loadUserProject();
        }
        return userProjectMapByUserId;
    }

    @Override
    public void load() {
        loadUserProject();
    }

    /**
     * 載入系統變數的Map
     */
    private synchronized void loadUserProject() {
        if (this.userProjectMapByUserId != null && this.userProjectMapByProjectId != null) {
            return;
        }
        ////
        List<UserProjectEntity> entities = userProjectRepo.findAll();
        this.userProjectMapByUserId = entities.stream()
                .collect(Collectors.groupingBy(
                        entity -> entity.getUserProjectPk().getUserId(),
                        Collectors.mapping(
                                entity -> entity.getUserProjectPk().getProjectId(),
                                Collectors.toSet()
                        )
                ));
        this.userProjectMapByProjectId = entities.stream()
                .collect(Collectors.groupingBy(
                        entity -> entity.getUserProjectPk().getProjectId(),
                        Collectors.mapping(
                                entity -> entity.getUserProjectPk().getUserId(),
                                Collectors.toSet()
                        )
                ));
    }

    @Override
    public void refresh() {
        ////
        if (userProjectMapByUserId != null) {
            userProjectMapByUserId.clear();
            userProjectMapByUserId = null;
        }
        ////
        if (userProjectMapByProjectId != null) {
            userProjectMapByProjectId.clear();
            userProjectMapByProjectId = null;
        }
    }
}
