package my.backend.common.cache;

import jakarta.annotation.Resource;
import my.backend.persistence.model.UserGroupEntity;
import my.backend.persistence.repository.UserGroupRepo;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class UserGroupCacheItem extends ICacheItem{

    private Map<String, Set<String>> userGroupMapByUserId = null;
    @Resource
    private UserGroupRepo userGroupRepo;

    public Map<String, Set<String>> getUserGroupMapByUserId() {
        if (userGroupMapByUserId == null) {
            loadUserGroup();
        }
        return userGroupMapByUserId;
    }

    @Override
    public void load() {
        loadUserGroup();
    }

    /**
     * 載入系統變數的Map
     */
    private synchronized void loadUserGroup() {
        if (this.userGroupMapByUserId != null) {
            return;
        }
        ////
        List<UserGroupEntity> entities = userGroupRepo.findAll();
        this.userGroupMapByUserId = entities.stream()
                .collect(Collectors.groupingBy(
                        entity -> entity.getUserGroupPk().getUserId(),
                        Collectors.mapping(
                                entity -> entity.getUserGroupPk().getUserGroupId(),
                                Collectors.toSet()
                        )
                ));
    }

    @Override
    public void refresh() {
        ////
        if (userGroupMapByUserId != null) {
            userGroupMapByUserId.clear();
            userGroupMapByUserId = null;
        }
    }
}
