package my.backend.common.cache;

import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import my.backend.persistence.repository.SysParamRepo;
import org.springframework.stereotype.Component;
import my.backend.persistence.model.SysParamEntity;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Component
public class SystemParamsCacheItem extends ICacheItem{

    private Map<String, String> paramsMap = null;
    @Resource
    private SysParamRepo sysParamRepo;

    public Map<String, String> getCacheContent() {
        if (paramsMap == null) {
            loadParamsMap();
        }

        return paramsMap;
    }

    @Override
    public void load() {
        loadParamsMap();
    }

    private synchronized void loadParamsMap() {
        if (paramsMap != null) {
            return;
        }
        this.paramsMap = sysParamRepo.findAll().stream()
                .collect(Collectors.toMap(SysParamEntity::getParamNo, SysParamEntity::getParamValue));
    }

    @Override
    public void refresh() {
        if (paramsMap != null) {
            paramsMap.clear();
            paramsMap = null;
        }
    }
}
