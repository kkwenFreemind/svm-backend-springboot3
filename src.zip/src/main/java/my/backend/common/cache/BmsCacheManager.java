package my.backend.common.cache;

import jakarta.annotation.PostConstruct;
import jakarta.annotation.Resource;
import lombok.extern.log4j.Log4j2;
import my.backend.common.cache.service.AsyncHttpClientService;
import my.backend.common.code.RedisLockEnum;
import my.backend.common.code.SystemParamsEnum;
import my.backend.common.constant.ApplicationConstant;
import my.backend.common.error.ErrorCode;
import my.backend.common.exception.ActionRuntimeException;
import my.backend.persistence.model.ClientInfoEntity;
import my.backend.persistence.model.ProjectInfoEntity;
import my.backend.persistence.model.UserInfoEntity;
import org.apache.commons.codec.binary.StringUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.*;

@Log4j2
@Component
public class BmsCacheManager {
    private final List<ICacheItem> cacheList = new ArrayList<>();
    @Value("${spring.application.name}")
    private String applicationName;
    @Resource
    private AsyncHttpClientService asyncHttpClientService;
    @Resource
    private ClientInfoCacheItem clientInfoCacheItem;
//    @Resource
//    private DeviceInfoCacheItem deviceInfoCacheItem;
//    @Resource
//    private EventNotifySettingCacheItem eventNotifySettingCacheItem;
//    @Resource
//    private IntersectionDeviceMappingCacheItem intersectionDeviceMappingCacheItem;
//    @Resource
//    private IntersectionInfoCacheItem intersectionInfoCacheItem;
//    @Resource
//    private NotifyGroupCacheItem notifyGroupCacheItem;
    @Resource
    private ProjectInfoCacheItem projectInfoCacheItem;
    @Resource
    private ProjectParamsCacheItem projectParamsCacheItem;
    @Resource
    private RedisServerCache redisServerCache;
    @Resource
    private RoleGroupCacheItem roleGroupCacheItem;
    @Resource
    private SystemParamsCacheItem systemParamsCacheItem;
    @Resource
    private UserGroupCacheItem userGroupCacheItem;
    @Resource
    private UserInfoCacheItem userInfoCacheItem;
//    @Resource
//    private UserOtpSecretCacheItem userOtpSecretCacheItem;
    @Resource
    private UserProjectCacheItem userProjectCacheItem;
//    @Resource
//    private AvgUpsOutputCacheItem avgUpsOutputCacheItem;

    public boolean acquireLock(RedisLockEnum redisLockEnum) {
        return redisServerCache.acquireLock(redisLockEnum);
    }

//    public Map<String, Double> getAvgUpsOutputMap() {
//        return avgUpsOutputCacheItem.getAvgUpsOutputMap();
//    }

    public Map<String, ClientInfoEntity> getClientInfoMapByClientId() {
        return clientInfoCacheItem.getClientInfoMapByClientId();
    }

//    public Map<String, DeviceInfoEntity> getDeviceIdMap() {
//        return deviceInfoCacheItem.getDeviceIdMap();
//    }
//
//    public Map<String, DeviceInfoEntity> getDeviceTokenMap() {
//        return deviceInfoCacheItem.getDeviceTokenMap();
//    }

//    public Map<String, List<String>> getEmailNotifyGroupMap(String projectId) {
//        Map<String, Map<String, List<String>>> emailNotifyGroupMapByProjectId = notifyGroupCacheItem.getEmailNotifyGroupMap();
//        if (emailNotifyGroupMapByProjectId == null) {
//            throw new ActionRuntimeException(ErrorCode.EVENT_NOTIFY_SETTING_NOT_FOUND);
//        }
//        Map<String, List<String>> emailNotifyGroupMapByEventType = emailNotifyGroupMapByProjectId.get(projectId);
//        if (emailNotifyGroupMapByEventType == null) {
//            throw new ActionRuntimeException(ErrorCode.EVENT_NOTIFY_SETTING_NOT_FOUND);
//        }
//        return emailNotifyGroupMapByEventType;
//    }

//    public Map<String, EventNotifySettingEntity> getEventNotifySettingMap(String projectId) {
//        Map<String, Map<String, EventNotifySettingEntity>> eventNotifySettingMapByProjectId = eventNotifySettingCacheItem.getEventNotifySettingMap();
//        if (eventNotifySettingMapByProjectId == null) {
//            throw new ActionRuntimeException(ErrorCode.EVENT_NOTIFY_SETTING_NOT_FOUND);
//        }
//        Map<String, EventNotifySettingEntity> eventNotifySettingMapByEventType = eventNotifySettingMapByProjectId.get(projectId);
//        if (eventNotifySettingMapByEventType == null) {
//            throw new ActionRuntimeException(ErrorCode.EVENT_NOTIFY_SETTING_NOT_FOUND);
//        }
//        return eventNotifySettingMapByEventType;
//    }
//
//    public Map<String, IntersectionDeviceMappingEntity> getIntersectionDeviceMap() {
//        return intersectionDeviceMappingCacheItem.getIntersectionDeviceMap();
//    }
//
//    public Map<String, IntersectionInfoEntity> getIntersectionInfoMap() {
//        return intersectionInfoCacheItem.getIntersectionInfoMap();
//    }
//
//    public Map<String, List<IntersectionInfoEntity>> getIntersectionInfoListMap() {
//        return intersectionInfoCacheItem.getIntersectionInfoListMap();
//    }
//
//    public Map<String, List<DeviceInfoEntity>> getIntersectionListMap() {
//        return deviceInfoCacheItem.getIntersectionListMap();
//    }

    public Date getIntersectionTelemetryUpdateTime(String intersectionId) {
        return (Date) redisServerCache.get("IntersectionTelemetryUpdateTime_" + intersectionId);
    }

//    public Map<String, String> getLineNotifyGroupMap(String projectId) {
//        Map<String, Map<String, String>> lineNotifyGroupMapByProjectId = notifyGroupCacheItem.getLineNotifyGroupMap();
//        if (lineNotifyGroupMapByProjectId == null) {
//            throw new ActionRuntimeException(ErrorCode.LINE_NOTIFY_GROUP_NOT_FOUND);
//        }
//        Map<String, String> lineNotifyGroupMap = lineNotifyGroupMapByProjectId.get(projectId);
//        if (lineNotifyGroupMap == null) {
//            throw new ActionRuntimeException(ErrorCode.LINE_NOTIFY_GROUP_NOT_FOUND);
//        }
//        return lineNotifyGroupMap;
//    }

//    public NotifyStatus getNotifyStatus(String uniqueId, EventTypeEnum notifyType) {
//        String key = uniqueId + "_" + notifyType.getEventType();
//        NotifyStatus notifyStatus = (NotifyStatus) redisServerCache.get(key);
//        if (notifyStatus == null) {
//            log.error("notifyStatus = null, key = " + key);
//            //// 當如果Redis異常，BATTERY_CHANGE_END、INPUT_RESET、UPS_ENABLE、BATTERY_RESET、BATTERY_REMOVE預設值是【已經發過通知】
//            if (EventTypeEnum.BATTERY_CHANGE_END.equals(notifyType) || EventTypeEnum.INPUT_RESET.equals(notifyType) || EventTypeEnum.UPS_DISABLE.equals(notifyType) || EventTypeEnum.BATTERY_CONNECT_RESET.equals(notifyType) || EventTypeEnum.BATTERY_INSTALL.equals(notifyType)) {
//                notifyStatus = new NotifyStatus(1);
//                redisServerCache.set(key, notifyStatus);
//                return notifyStatus;
//
//            }
//            ////
//            notifyStatus = new NotifyStatus(0);
//            redisServerCache.set(key, notifyStatus);
//        }
//        return notifyStatus;
//    }

//    public Integer getNotifyStatusCount(String accessToken, EventTypeEnum notifyType) {
//        NotifyStatus notifyStatus = (NotifyStatus) redisServerCache.get(accessToken + "_" + notifyType.getEventType() + "_count");
//        if (notifyStatus == null) {
//            notifyStatus = new NotifyStatus(0);
//        }
//        return notifyStatus.getStatus();
//    }

    public Map<String, ProjectInfoEntity> getProjectInfoMap() {
        return projectInfoCacheItem.getProjectInfoMap();
    }

    public Map<String, Map<String, String>> getProjectParamMapMap() {
        return projectParamsCacheItem.getProjectParamMapMap();
    }

    public Map<String, String> getRoleGroupMap(String authToken) {
        return roleGroupCacheItem.getRoleGroupMap(authToken);
    }

    public String getSysParams(SystemParamsEnum params) {
        Map<String, String> map = getSysParamsMap();
        String paramValue = map.get(params.getParamNo());
        if (paramValue == null) {
            paramValue = params.getDefaultValue();
        }
        return paramValue;
    }

    public Map<String, String> getSysParamsMap() {
        return systemParamsCacheItem.getCacheContent();
    }

    public Date getSystemStartTime() {
        return (Date) redisServerCache.get("SystemStartTime");
    }

    public void setSystemStartTime(Date date) {
        redisServerCache.set("SystemStartTime", date);
    }

    public Map<String, Set<String>> getUserGroupMapByUserId() {
        return userGroupCacheItem.getUserGroupMapByUserId();
    }

    public Map<String, UserInfoEntity> getUserInfoMapByEmail() {
        return userInfoCacheItem.getUserInfoMapByEmail();
    }

    public Map<String, UserInfoEntity> getUserInfoMapById() {
        return userInfoCacheItem.getUserInfoMapById();
    }

//    public Map<String, UserOtpSecretEntity> getUserOtpSecretMapById() {
//        return userOtpSecretCacheItem.getUserOtpSecretMapById();
//    }

    public Map<String, Set<String>> getUserProjectMapByProjectId() {
        return userProjectCacheItem.getUserProjectMapByProjectId();
    }

    public Map<String, Set<String>> getUserProjectMapByUserId() {
        return userProjectCacheItem.getUserProjectMapByUserId();
    }

    @PostConstruct
    public void init() throws UnknownHostException {
        //// keep server ip+port
        updateServerSet();
        ////
        put(clientInfoCacheItem);
//        put(deviceInfoCacheItem);
//        put(eventNotifySettingCacheItem);
//        put(intersectionDeviceMappingCacheItem);
//        put(intersectionInfoCacheItem);
//        put(notifyGroupCacheItem);
        put(projectInfoCacheItem);
//        put(projectParamsCacheItem);
        put(roleGroupCacheItem);
        put(systemParamsCacheItem);
        put(userInfoCacheItem);
        put(userProjectCacheItem);
//        put(userOtpSecretCacheItem);
//        put(userGroupCacheItem);
//        put(avgUpsOutputCacheItem);
    }

    private void put(ICacheItem item) {
        cacheList.add(item);
    }

    /**
     * refresh all cache
     */
    public synchronized void refresh() {
        // 如有其他Clone的Pod也要通知refresh
        try {
            String ip = InetAddress.getLocalHost().getHostAddress();
            Set<String> serverSet = redisServerCache.getSet(applicationName + "_" + ApplicationConstant.serverIpSet);
            for (String serverIp : serverSet) {
                if (!StringUtils.equals(serverIp, ip)) {
                    asyncHttpClientService.notifyRefresh(serverIp);
                }
            }
            refreshCache();
        } catch (Exception e) {
            refreshCache();
            throw new ActionRuntimeException(ErrorCode.CACHE_REFRESH_FAILED, e.getMessage());
        }
    }

    public synchronized void refreshCache() {
        for (ICacheItem cache : cacheList) {
            cache.refresh();
        }
    }

    public void releaseLock(RedisLockEnum redisLockEnum) {
        redisServerCache.releaseLock(redisLockEnum);
    }

    public void setIntersectionTelemetryUpdateTime(String intersectionId, Date date) {
        redisServerCache.set("IntersectionTelemetryUpdateTime_" + intersectionId, date);
    }

//    public void setNotifyStatus(String uniqueId, EventTypeEnum notifyType, Integer status) {
//        redisServerCache.set(uniqueId + "_" + notifyType.getEventType(), new NotifyStatus(status));
//    }

//    public void setNotifyStatusCount(String uniqueId, EventTypeEnum notifyType, Integer count) {
//        String key = uniqueId + "_" + notifyType.getEventType() + "_count";
//        NotifyStatus notifyStatus = (NotifyStatus) redisServerCache.get(key);
//        if (notifyStatus == null) {
//            notifyStatus = new NotifyStatus(count);
//        } else {
//            notifyStatus.setStatus(count);
//            notifyStatus.setUpdateTime(new Date());
//        }
//        redisServerCache.set(key, notifyStatus);
//    }

    public void updateServerSet() throws UnknownHostException {
        log.info("[updateServerSet][B]update server set, serverSet = " + redisServerCache.getSet(applicationName + "_" + ApplicationConstant.serverIpSet));
        String ip = InetAddress.getLocalHost().getHostAddress();
        if (!redisServerCache.isMember(applicationName + "_" + ApplicationConstant.serverIpSet, ip)) {
            redisServerCache.addSet(applicationName + "_" + ApplicationConstant.serverIpSet, ip);
        }
        log.info("[updateServerSet][E]update server set, serverSet = " + redisServerCache.getSet(applicationName + "_" + ApplicationConstant.serverIpSet));
    }

}
