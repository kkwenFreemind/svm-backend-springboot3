package my.backend.common.cache;


import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import my.backend.admin.service.KeycloakAdapterService;
import org.springframework.stereotype.Component;
import my.backend.admin.service.dto.KeycloakUserGroupDto;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Component
public class RoleGroupCacheItem extends ICacheItem{

    @Resource
    KeycloakAdapterService keycloakAdapterService;

    private Map<String, String> roleGroupMap = null;

    public Map<String, String> getRoleGroupMap(String authToken) {
        if (roleGroupMap == null) {
            loadRoleGroupMap(authToken);
        }
        return roleGroupMap;
    }

    @Override
    public void load() {
    }


    private synchronized void loadRoleGroupMap(String authToken) {
        if (roleGroupMap != null) {
            return;
        }
        ////
        roleGroupMap = keycloakAdapterService.getUserGroupList(authToken).stream()
                .collect(Collectors.toMap(KeycloakUserGroupDto::getName, KeycloakUserGroupDto::getId));
    }

    @Override
    public void refresh() {
        if (roleGroupMap != null) {
            roleGroupMap.clear();
            roleGroupMap = null;
        }
    }
}
