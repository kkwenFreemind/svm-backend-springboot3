package my.backend.common.cache;

public abstract class ICacheItem {

    /**
     * 更新Cache
     */
    public abstract void refresh();

    /**
     * 載入
     */
    public abstract void load();
}
