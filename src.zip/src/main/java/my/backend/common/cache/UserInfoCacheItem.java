package my.backend.common.cache;

import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import my.backend.persistence.model.UserInfoEntity;
import my.backend.persistence.repository.UserInfoRepo;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Component
public class UserInfoCacheItem  extends ICacheItem{

    private Map<String, UserInfoEntity> userInfoMapByEmail = null;
    private Map<String, UserInfoEntity> userInfoMapById = null;

    @Resource
    private UserInfoRepo userInfoRepo;

    public Map<String, UserInfoEntity> getUserInfoMapByEmail() {
        if (userInfoMapByEmail == null) {
            loadUserInfo();
        }
        userInfoMapByEmail.forEach((email, userInfo) -> {
            System.out.println("Email: " + email + ", User Info: " + userInfo);
        });
        return userInfoMapByEmail;
    }

    public Map<String, UserInfoEntity> getUserInfoMapById() {
        if (userInfoMapById == null) {
            loadUserInfo();
        }
        return userInfoMapById;
    }

    @Override
    public void load() {
        loadUserInfo();
    }

    /**
     * 載入系統變數的Map
     */
    private synchronized void loadUserInfo() {
        if (this.userInfoMapByEmail != null && this.userInfoMapById != null) {
            return;
        }
        ////
        List<UserInfoEntity> entities = userInfoRepo.findAll();
        this.userInfoMapByEmail = entities.stream()
                .collect(Collectors.toMap(UserInfoEntity::getEmail, Function.identity()));
        this.userInfoMapById = entities.stream()
                .collect(Collectors.toMap(UserInfoEntity::getUserId, Function.identity()));
    }

    @Override
    public void refresh() {
        ////
        if (userInfoMapByEmail != null) {
            userInfoMapByEmail.clear();
            userInfoMapByEmail = null;
        }
        ////
        if (userInfoMapById != null) {
            userInfoMapById.clear();
            userInfoMapById = null;
        }
    }

}
