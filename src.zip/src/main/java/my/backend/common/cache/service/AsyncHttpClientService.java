package my.backend.common.cache.service;

import jakarta.annotation.Resource;
import my.backend.common.cache.RedisServerCache;
import my.backend.common.constant.ApplicationConstant;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.web.client.ResourceAccessException;
import org.springframework.web.client.RestTemplate;

@Service
public class AsyncHttpClientService {
    @Resource
    private RestTemplate restTemplate;
    @Resource
    private RedisServerCache redisServerCache;
    @Value("${spring.application.name}")
    private String applicationName;
    @Value("${server.port}")
    private String serverPort;
    @Value("${server.api-base-path}")
    private String apiBasePath;

    @Async
    public void notifyRefresh(String serverIp) {
        try {
            restTemplate.exchange("http://" + serverIp + ":" + serverPort + apiBasePath + "/v1/noauth/admin/cache/refresh?authToken=c5cbb68f-f230-4ade-80ca-17690fa5fefc", HttpMethod.GET, null, String.class);
        } catch (ResourceAccessException e) {
            redisServerCache.removeSet(applicationName + "_" + ApplicationConstant.serverIpSet, serverIp);
            throw e;
        }
    }
}
