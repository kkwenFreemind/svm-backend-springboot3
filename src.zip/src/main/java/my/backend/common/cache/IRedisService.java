package my.backend.common.cache;

import my.backend.common.code.RedisLockEnum;

import java.util.List;
import java.util.Set;

public interface IRedisService {


    boolean acquireLock(RedisLockEnum redisLockEnum);

    boolean addSet(String key, Object... values);

    /**
     * 判斷快取中是否有對應的value
     */
    boolean exists(String key);

    /**
     * 讀取快取
     */
    Object get(String key);

    /**
     * 集合獲取
     */
    Set<Object> getArray(String key);

    Set getSet(String key);

    /**
     * 雜湊獲取資料
     */
    Object hmGet(String key, Object hashKey);

    /**
     * 雜湊 新增
     */
    void hmSet(String key, Object hashKey, Object value);

    boolean isMember(String key, Object value);

    /**
     * 列表新增
     */
    void lPush(String k, Object v);

    /**
     * 列表獲取
     */
    List<Object> lRange(String k, long l, long l1);

    /**
     * 有序集合獲取
     */
    Set<Object> rangeByScore(String key, double scoure, double scoure1);

    void releaseLock(RedisLockEnum redisLockEnum);

    void remove(String... keys);

    /**
     * 刪除對應的value
     */
    void remove(String key);

    /**
     * 批量刪除key
     */
    void removePattern(String pattern);

    boolean removeSet(String key, Object... values);

    boolean set(String key, Object value);

    boolean set(String key, Object value, Long expireTime);

    /**
     * 集合新增
     */
    void setArray(String key, Object value);

    /**
     * 有序集合新增
     */
    void zAdd(String key, Object value, double scoure);

}
