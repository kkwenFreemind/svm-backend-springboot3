package my.backend.common.cache;

import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import my.backend.persistence.model.ClientInfoEntity;
import my.backend.persistence.repository.ClientInfoRepo;
import org.springframework.stereotype.Component;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Slf4j
@Component
public class ClientInfoCacheItem extends ICacheItem{

    private Map<String, ClientInfoEntity> clientInfoMapById = null;
    @Resource
    private ClientInfoRepo clientInfoRepo;

    public Map<String, ClientInfoEntity> getClientInfoMapByClientId() {
        if (clientInfoMapById == null) {
            loadClientInfo();
        }
        return clientInfoMapById;
    }

    @Override
    public void load() {
        loadClientInfo();
    }

    /**
     * 載入系統變數的Map
     */
    private synchronized void loadClientInfo() {
        if (this.clientInfoMapById != null) {
            return;
        }
        ////
        this.clientInfoMapById = clientInfoRepo.findAll().stream()
                .collect(Collectors.toMap(ClientInfoEntity::getClientId, Function.identity()));
    }

    @Override
    public void refresh() {
        ////
        if (clientInfoMapById != null) {
            clientInfoMapById.clear();
            clientInfoMapById = null;
        }
    }

}
