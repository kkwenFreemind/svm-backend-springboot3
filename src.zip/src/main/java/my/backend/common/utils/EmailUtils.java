package my.backend.common.utils;

import jakarta.annotation.Resource;
import jakarta.mail.internet.MimeMessage;
import lombok.extern.slf4j.Slf4j;
import my.backend.common.error.ErrorCode;
import my.backend.common.exception.ActionRuntimeException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.thymeleaf.context.Context;
import org.thymeleaf.spring6.SpringTemplateEngine;

@Slf4j
@Component
public class EmailUtils {

    @Resource
    private JavaMailSender javaMailSender;
    @Resource
    private SpringTemplateEngine thymeleafTemplateEngine;

    public void sendNotifyEmail(String from, String senderLabel, String toAddress, String subject, String message, String name, String url) {
        try {
            MimeMessage mimeMessage = javaMailSender.createMimeMessage();
            MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, false, "UTF-8");
            Context thymeleafContext = new Context();
            thymeleafContext.setVariable("name", name);
            thymeleafContext.setVariable("message", message);
            thymeleafContext.setVariable("url", url);
            mimeMessageHelper.setFrom(from, senderLabel);
            mimeMessageHelper.setTo(toAddress);
            mimeMessageHelper.setSubject(subject);
            mimeMessageHelper.setText(thymeleafTemplateEngine.process("notify-email.html", thymeleafContext), true);
            javaMailSender.send(mimeMessageHelper.getMimeMessage());
        } catch (Exception e) {
            throw new ActionRuntimeException(ErrorCode.NOTIFY_EMAIL_SEND_FAILED, e.getMessage());
        }
    }

    public void sendSecretUpdateEmail(String from, String senderLabel, String toAddress, String subject, String name, String url) {
        try {
            MimeMessage mimeMessage = javaMailSender.createMimeMessage();
            MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(mimeMessage, false, "UTF-8");
            Context thymeleafContext = new Context();
            thymeleafContext.setVariable("name", name);
            thymeleafContext.setVariable("url", url);
            mimeMessageHelper.setFrom(from, senderLabel);
            mimeMessageHelper.setTo(toAddress);
            mimeMessageHelper.setSubject(subject);
            mimeMessageHelper.setText(thymeleafTemplateEngine.process("update-secret-email.html", thymeleafContext), true);
            javaMailSender.send(mimeMessageHelper.getMimeMessage());
        } catch (Exception e) {
            throw new ActionRuntimeException(ErrorCode.UPDATE_SECRET_EMAIL_SEND_FAILED, e.getMessage());
        }
    }
}
