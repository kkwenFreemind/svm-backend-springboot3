package my.backend.common.code;

import lombok.Getter;
import my.backend.common.error.ErrorCode;
import my.backend.common.exception.ActionRuntimeException;

@Getter
public enum RoleGroupEnum {
    USER("USER", "一般使用者"),
    ENGINEER("ENGINEER", "工班"),
    PROJECT_ADMIN("PROJECT_ADMIN", "一般管理者"),
    SYSTEM_ADMIN("SYSTEM_ADMIN", "專案管理者");

    private final String roleGroupName;
    private final String roleGroupDesc;

    RoleGroupEnum(String roleGroupName, String roleGroupDesc) {
        this.roleGroupName = roleGroupName;
        this.roleGroupDesc = roleGroupDesc;
    }

    public static RoleGroupEnum getByRoleGroup(String roleGroupName) {
        for (RoleGroupEnum tmp : values()) {
            System.out.println("tmp.getRoleGroupName()==>"+tmp.getRoleGroupName()+","+roleGroupName);
            if (tmp.getRoleGroupName().equals(roleGroupName)) {
                return tmp;
            }
        }
        throw new ActionRuntimeException(ErrorCode.ROLE_GROUP_ID_NOT_FOUND);
    }

    public boolean isEngineer() {
        return this.roleGroupName.equals(ENGINEER.getRoleGroupName());
    }

    public boolean isSystemAdmin() {
        return this.roleGroupName.equals(SYSTEM_ADMIN.getRoleGroupName());
    }
}
