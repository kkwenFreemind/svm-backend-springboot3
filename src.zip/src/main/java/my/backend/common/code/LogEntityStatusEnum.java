package my.backend.common.code;

import lombok.Getter;

@Getter
public enum LogEntityStatusEnum {

    INSERT("insert", "新增"),
    UPDATE("update", "修改"),
    DELETE("delete", "刪除");
    private final String status;
    private final String description;

    LogEntityStatusEnum(String status, String description) {
        this.status = status;
        this.description = description;
    }
}
