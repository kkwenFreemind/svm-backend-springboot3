package my.backend.common.code;

import lombok.Getter;

@Getter
public enum SystemParamsEnum {
    SYS_CAPTCHA_IS_VERIFY("sys_captcha_is_verify", "1"),
    SYS_EMAIL_SENDER("sys_email_sender", "no-reply@fetnet.net"),
    SYS_EMAIL_SENDER_LABEL("sys_email_sender_label", "交通號誌不斷電系統"),
    SYS_UPDATE_SECRET_EMAIL_SUBJECT("sys_update_secret_email_subject", "[交通號誌不斷電系統] 密碼設定信件"),
    SYS_UPDATE_SECRET_USER("sys_update_secret_user", "wdms_update_secret"),
    SYS_UPDATE_SECRET_USER_CREDENTIALS("sys_update_secret_user_credentials", "7E46CD7311867417D9D25292791F19dd"),
    SERVER_DOMAIN("server_domain", "http://localhost:8080"),
    UPDATE_SECRET_PATH("update_secret_path", "/web/resetPassword"),
    OTP_IS_VERIFY("otp_is_verify", "0");

    private final String paramNo;
    private final String defaultValue;

    SystemParamsEnum(String paramNo, String defaultValue) {
        this.paramNo = paramNo;
        this.defaultValue = defaultValue;
    }

}
