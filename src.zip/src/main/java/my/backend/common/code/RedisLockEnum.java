package my.backend.common.code;

import lombok.Getter;

@Getter
public enum RedisLockEnum {

    OVER_10_MINUTES_NO_RESPONSE("over10MinutesNoResponse"),
    OVER_30_MINUTES_NO_RESPONSE("over30MinutesNoResponse"),
    COMPUTE_AVG_UPS_OUTPUT("computeAvgUpsOutput"),
    BATCH_CHECK_INPUT_ERROR_EVENT("batchCheckInputErrorEvent"),
    BATCH_CHECK_MOBILE_INPUT_ERROR_EVENT_END("batchCheckMobileInputErrorEventEnd"),
    ;

    private final String lockType;

    RedisLockEnum(String lockType) {
        this.lockType = lockType;
    }
}
