package my.backend.common.code;

import lombok.Getter;
import my.backend.common.error.ErrorCode;
import my.backend.common.exception.ActionRuntimeException;

@Getter
public enum ClientRoleGroupEnum {

    CLIENT_VIEWER("CLIENT_VIEWER", "客戶端查看資料權限");

    private final String roleGroupName;
    private final String roleGroupDesc;

    ClientRoleGroupEnum(String roleGroupName, String roleGroupDesc) {
        this.roleGroupName = roleGroupName;
        this.roleGroupDesc = roleGroupDesc;
    }

    public static ClientRoleGroupEnum getByRoleGroup(String roleGroupName) {
        for (ClientRoleGroupEnum tmp : values()) {
            if (tmp.getRoleGroupName().equals(roleGroupName)) {
                return tmp;
            }
        }
        throw new ActionRuntimeException(ErrorCode.ROLE_GROUP_ID_NOT_FOUND);
    }
}
