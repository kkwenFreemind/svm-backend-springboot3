package my.backend;


import my.backend.common.cache.BmsCacheManager;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.scheduling.annotation.EnableScheduling;

import java.util.Date;

@EnableJpaAuditing
@SpringBootApplication
@EnableScheduling
public class MyApplication {


    public MyApplication(BmsCacheManager bmsCacheManager) {
        bmsCacheManager.setSystemStartTime(new Date());
    }

    public static void main(String[] args) {
        SpringApplication.run(MyApplication.class, args);
    }

}
