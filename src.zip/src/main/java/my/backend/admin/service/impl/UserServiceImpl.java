package my.backend.admin.service.impl;

import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import my.backend.admin.service.UserService;
import my.backend.admin.service.code.LogEntityStatusEnum;
import my.backend.admin.service.dto.KeycloakUserDto;
import my.backend.common.cache.BmsCacheManager;
import my.backend.admin.service.dto.KeycloakCreateUserDto;
import my.backend.admin.service.dto.ResetPasswordDto;
import my.backend.admin.service.KeycloakAdapterService;
import my.backend.common.code.SystemParamsEnum;
import my.backend.common.error.ErrorCode;
import my.backend.common.exception.ActionRuntimeException;
import my.backend.common.utils.BmsUtils;
import my.backend.common.utils.EmailUtils;
import my.backend.persistence.model.UserInfoEntity;
import my.backend.persistence.model.UserInfoLogEntity;
import my.backend.persistence.model.UserUpdateSecretTokenEntity;
import my.backend.persistence.repository.UserGroupRepo;
import my.backend.persistence.repository.UserInfoLogRepo;
import my.backend.persistence.repository.UserInfoRepo;
import my.backend.persistence.repository.UserUpdateSecretTokenRepo;
import my.backend.iot.client.dto.UpdateStDto;
import my.backend.admin.controller.dto.UserDto;
import my.backend.admin.service.utils.UserProjectUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.LocalDateTime;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Service
public class UserServiceImpl implements UserService {

    @Value("${application.default}")
    private String default_password;

    @Resource
    private UserInfoRepo userInfoRepo;

    @Resource
    private UserInfoLogRepo userInfoLogRepo;

    @Resource
    private KeycloakAdapterService keycloakAdapterService;

    @Resource
    private UserUpdateSecretTokenRepo userUpdateSecretTokenRepo;

    @Resource
    private BmsCacheManager bmsCacheManager;

    @Resource
    private UserProjectUtils userProjectUtils;

    @Resource
    private EmailUtils emailUtils;

    @Resource
    private UserGroupRepo userGroupRepo;

    private KeycloakCreateUserDto getKeycloakCreateUserDto(UserDto userDto) {
        KeycloakCreateUserDto user = new KeycloakCreateUserDto();
        user.setUsername(userDto.getEmail());
        user.setEnabled(true);
        user.setEmailVerified(false);
        user.setFirstName("MYSORE");
        user.setLastName("MYSORE");
        user.setEmail(userDto.getEmail());

        KeycloakCreateUserDto.CredentialDTO credential = new KeycloakCreateUserDto.CredentialDTO();
        credential.setType("password");
        credential.setValue(default_password);
        credential.setTemporary(false);
        user.setCredentials(Collections.singletonList(credential));
        return user;
    }

    @Override
    @Transactional
    @Modifying
    public UserDto createUser(String authToken, String actionUserId, UserDto userDto) {
        ////
        KeycloakUserDto keycloakUserDto = new KeycloakUserDto();
        BeanUtils.copyProperties(userDto, keycloakUserDto);
        keycloakUserDto.setEmailVerified(true);
        keycloakUserDto.setEnabled(true);
        keycloakUserDto.setUsername(userDto.getEmail());
        keycloakUserDto.setGroups(new String[]{userDto.getUserRoleGroupName()});
        ////後端根據 FET NT 信箱之帳號名稱
        keycloakUserDto.setUsername(userDto.getEmail());
        ////
        String userId = keycloakAdapterService.createUser(authToken, keycloakUserDto);
        ////
        UserInfoEntity userInfoEntity = new UserInfoEntity();
        userInfoEntity.setUserId(userId);
        userInfoEntity.setUserLabel(userDto.getUserLabel());
        userInfoEntity.setEmail(userDto.getEmail());
        userInfoEntity.setUserRoleGroupName(userDto.getUserRoleGroupName());
        userInfoEntity.setDefaultProjectId(userDto.getDefaultProjectId());
        userInfoEntity = userInfoRepo.save(userInfoEntity);
        userInfoLogRepo.saveAndFlush(genUserInfoLogEntity(actionUserId, userInfoEntity, LogEntityStatusEnum.INSERT.getStatus()));
        ////
        if (userDto.getProjectIdList() != null && !userDto.getProjectIdList().isEmpty()) {
            userProjectUtils.checkAndUpdateUserProject(actionUserId, UserProjectUtils.PROJECT, userId, userDto.getProjectIdList());
        }
        ////
        if (userDto.getUserGroupIdList() != null && !userDto.getUserGroupIdList().isEmpty()) {
            userProjectUtils.checkAndUpdateUserGroup(actionUserId, UserProjectUtils.USER_GROUP, userId, userDto.getUserGroupIdList());
        }
        ////
        bmsCacheManager.refresh();
        try {
            applyUpdateUserSecret(userId);
        } catch (Throwable t) {
            log.error("applyUpdateUserSecret error", t);
        }
        userDto.setUserId(userId);
        userDto.setCreateTime(BmsUtils.toEpochMilli(userInfoEntity.getCreateTime()));
        userDto.setUpdateTime(BmsUtils.toEpochMilli(userInfoEntity.getUpdateTime()));
        return userDto;
    }

    @Transactional
    @Modifying
    @Override
    public void applyUpdateUserSecret(String actionUserId) throws MalformedURLException {
        UserInfoEntity entity = bmsCacheManager.getUserInfoMapById().get(actionUserId);
        if (entity == null) {
            throw new ActionRuntimeException(ErrorCode.USER_NOT_FOUND);
        }
        sendUpdateSecretEmail(actionUserId, entity.getEmail(), entity.getUserLabel());
    }

    @Override
    @Transactional
    @Modifying
    public String deleteUser(String authToken, String actionUserId, String userId) {
        keycloakAdapterService.deleteUser(authToken, userId);
        ////
        UserInfoEntity userInfoEntity = userInfoRepo.findByUserId(userId);
        if (userInfoEntity == null) {
            throw new ActionRuntimeException(ErrorCode.USER_NOT_FOUND);
        }
        userInfoRepo.delete(userInfoEntity);
        userInfoLogRepo.save(genUserInfoLogEntity(actionUserId, userInfoEntity, LogEntityStatusEnum.DELETE.getStatus()));
        ////
        userGroupRepo.findAllByUserGroupPkUserId(userId).forEach(userGroupEntity -> userProjectUtils.deleteUserGroup(actionUserId, userGroupEntity));
        userProjectUtils.deleteUserProjectByUserId(actionUserId, userId);
        bmsCacheManager.refresh();
        return "Delete user, userId = " + userInfoEntity.getUserId();
    }

    @Override
    @Transactional
    @Modifying
    public String updateUserSecret(UpdateStDto updateStDto) {


//        String userId = entity.getUserId();
       // String userId = "d0006933-ea1c-41b2-8b09-103d52b3f0fe";
//        String sysUpdateSecretUser = bmsCacheManager.getSysParams(SystemParamsEnum.SYS_UPDATE_SECRET_USER);
//        String sysUpdateSecretUserCredentials = bmsCacheManager.getSysParams(SystemParamsEnum.SYS_UPDATE_SECRET_USER_CREDENTIALS);

        UserInfoEntity userInfoEntity = userInfoRepo.findByEmail(updateStDto.getAccount());
        String userId = userInfoEntity.getUserId();
        String sysUpdateSecretUser = updateStDto.getAccount();
        String sysUpdateSecretUserCredentials = updateStDto.getValue();
        String authToken = keycloakAdapterService.getKeycloakToken(sysUpdateSecretUser, sysUpdateSecretUserCredentials, null).getAccessToken();

        ResetPasswordDto resetPasswordDto = new ResetPasswordDto(userId, updateStDto.getValue());


        return keycloakAdapterService.resetPassword(authToken, resetPasswordDto);


//        userProjectUtils.saveChangeSecretLog(sysUpdateSecretUser, userId, "user");
//        //紀錄
//        UserInfoEntity userInfoEntity = userInfoRepo.findByUserId(userId);
//        userInfoEntity.setPasswordUpdateTime(LocalDateTime.now());
//        userInfoRepo.save(userInfoEntity);
//        userInfoLogRepo.save(genUserInfoLogEntity(sysUpdateSecretUser, userInfoEntity, LogEntityStatusEnum.UPDATE.getStatus()));
//        //完成更新密碼改變token狀態
//        entity.setExecution(true);
//        userUpdateSecretTokenRepo.save(entity);
        //return "Updated user password success userId: " + userId;
    }

    @Override
    public List<UserDto> getProjectUserList(String actionUserId) {
        return getUserDtoList(userInfoRepo.findAllByOrderByCreateTimeDesc());
    }

    private UserInfoLogEntity genUserInfoLogEntity(String actionUserId, UserInfoEntity userInfoEntity, String status) {
        UserInfoLogEntity userInfoLogEntity = new UserInfoLogEntity();
        BeanUtils.copyProperties(userInfoEntity, userInfoLogEntity);
        userInfoLogEntity.setActionUserId(actionUserId);
        userInfoLogEntity.setStatus(status);
        return userInfoLogEntity;
    }

    public List<UserDto> getUserDtoList(List<UserInfoEntity> userInfoEntityList) {
        List<UserDto> userDtoList = userInfoEntityList.stream().map(UserDto::new).collect(Collectors.toList());
        ////
        Map<String, Set<String>> userProjectMapByUserId = bmsCacheManager.getUserProjectMapByUserId();
        userDtoList.forEach(userDto -> Optional.ofNullable(userProjectMapByUserId.get(userDto.getUserId()))
                .ifPresent(projectIdSet -> userDto.setProjectIdList(new ArrayList<>(projectIdSet))));
        ////
        Map<String, Set<String>> userGroupMapByUserId = bmsCacheManager.getUserGroupMapByUserId();
        userDtoList.forEach(userDto -> Optional.ofNullable(userGroupMapByUserId.get(userDto.getUserId()))
                .ifPresent(userGroupSet -> userDto.setUserGroupIdList(new ArrayList<>(userGroupSet))));
        return userDtoList;
    }

//    @Transactional
//    @Modifying
//    @Override
//    public void applyUpdateUserSecret(String actionUserId) throws MalformedURLException {
//        UserInfoEntity entity = bmsCacheManager.getUserInfoMapById().get(actionUserId);
//        if (entity == null) {
//            throw new ActionRuntimeException(ErrorCode.USER_NOT_FOUND);
//        }
//        //sendUpdateSecretEmail(actionUserId, entity.getEmail(), entity.getUserLabel());
//    }

    private void sendUpdateSecretEmail(String actionUserId, String userEmail, String userName) throws MalformedURLException {
        String token = createToken(actionUserId);
        String sender = bmsCacheManager.getSysParams(SystemParamsEnum.SYS_EMAIL_SENDER);
        String senderLabel = bmsCacheManager.getSysParams(SystemParamsEnum.SYS_EMAIL_SENDER_LABEL);
        String serverDomain = bmsCacheManager.getSysParams(SystemParamsEnum.SERVER_DOMAIN);
        String updateSecretPath = bmsCacheManager.getSysParams(SystemParamsEnum.UPDATE_SECRET_PATH);
        String subject = bmsCacheManager.getSysParams(SystemParamsEnum.SYS_UPDATE_SECRET_EMAIL_SUBJECT);
        URL url = new URL("%s%s?token=%s".formatted(serverDomain, updateSecretPath, token));
        //emailUtils.sendSecretUpdateEmail(sender, senderLabel, userEmail, subject, userName, url.toString());
    }


    private String createToken(String userId) {
        String token = UUID.randomUUID().toString();
        UserUpdateSecretTokenEntity entity = userUpdateSecretTokenRepo.findByUserId(userId);
        if (entity == null) {
            entity = new UserUpdateSecretTokenEntity();
            entity.setUserId(userId);
        }
        entity.setToken(token);
        entity.setExecution(false);
        entity.setExpiredTime(LocalDateTime.now().plusHours(24));
        userUpdateSecretTokenRepo.saveAndFlush(entity);
        return token;
    }
}
