package my.backend.admin.service.dto;


import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.ToString;

@Schema
@Data
@ToString
public class CreateProjectRequest {

    @Schema(description = "專案標籤")
    @NotEmpty(message = "專案標籤不可為空")
    @Size(max = 30)
    private String projectLabel;

//    @Schema(description = "UPS廠商群組")
//    private String upsVendorGroup;
//
//    @Schema(description = "電池廠商群組")
//    private String batteryVendorGroup;
//    @Schema(description = "閘道器廠商群組")
//    private String gatewayVendorGroup;
//    @Schema(description = "路口群組")
//    private String intersectionGroup;
//    @Schema(description = "地圖初始緯度")
//    private String mapInitLatitude;
//    @Schema(description = "地圖初始經度")
//    private String mapInitLongitude;
//    @Schema(description = "地圖初始縮放比例")
//    private String mapInitZoom;


}
