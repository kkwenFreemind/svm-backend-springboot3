package my.backend.admin.service.utils;

import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import my.backend.common.error.ErrorCode;
import my.backend.common.exception.ActionRuntimeException;
import my.backend.common.exception.UnauthorizedException;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

@Component
@Slf4j
public class KeycloakUtils {


    @Value("${keycloak.auth-server-url}")
    private String apiKeycloakUrl;

    @Resource
    private RestTemplate restTemplate;

    public String genHttpErrorResponseMassage(ResponseEntity<?> responseEntity) {
        return "HttpStatus:" + responseEntity.getStatusCode() + ", ResponseBody:" + responseEntity.getBody();
    }

    private <T> ResponseEntity<T> gettResponseEntity(String apiPath, HttpEntity<?> entity, ResponseEntity<T> responseEntity) {
        ////
        if (responseEntity.getStatusCode().is2xxSuccessful()) {
            return responseEntity;
        }
        ////
        if (responseEntity.getStatusCode().equals(HttpStatus.UNAUTHORIZED)) {
            throw new UnauthorizedException(ErrorCode.ACCESS_TOKEN_INVALID, genHttpErrorResponseMassage(responseEntity));
        }
        ////
        if (responseEntity.getStatusCode().equals(HttpStatus.FORBIDDEN)) {
            throw new ActionRuntimeException(ErrorCode.ROLE_PERMISSION_DENIED, genHttpErrorResponseMassage(responseEntity));
        }
        ////
        if (responseEntity.getStatusCode().equals(HttpStatus.CONFLICT)) {
            throw new ActionRuntimeException(ErrorCode.USER_MANAGEMENT_CONFLICT, genHttpErrorResponseMassage(responseEntity));
        }
        ////如果HttpStatus=400
        if (responseEntity.getStatusCode().equals(HttpStatus.BAD_REQUEST)) {
            ////取 keycloak token 如果HttpStatus=400，表示帳號被停用
            if (apiPath.contains("/protocol/openid-connect/token") && entity.getBody() != null) {
                String grantType = ((HttpEntity<MultiValueMap<String, String>>) entity).getBody().get("grant_type").get(0);
                if ("password".equals(grantType)) {
                    throw new ActionRuntimeException(ErrorCode.ACCOUNT_LOCKED, genHttpErrorResponseMassage(responseEntity));
                }
                if ("refresh_token".equals(grantType)) {
                    throw new ActionRuntimeException(ErrorCode.REFRESH_TOKEN_INVALID, genHttpErrorResponseMassage(responseEntity));
                }
            }
            ////
            if (apiPath.contains("/reset-password")) {
                String responseEntityBody = (String) responseEntity.getBody();
                if (responseEntityBody != null && responseEntityBody.contains("invalidPasswordHistoryMessage")) {
                    throw new ActionRuntimeException(ErrorCode.INVALID_SECRET_HISTORY, genHttpErrorResponseMassage(responseEntity));
                }
                throw new ActionRuntimeException(ErrorCode.RESET_SECRET_ERROR, genHttpErrorResponseMassage(responseEntity));
            }
        }
        ////
        throw new ActionRuntimeException(ErrorCode.USER_MANAGEMENT_RESPONSE_ERROR, genHttpErrorResponseMassage(responseEntity));
    }

    public <T> ResponseEntity<T> sendKeycloakRestApi(String apiPath, HttpMethod httpMethod, HttpEntity<?> entity, Class<T> responseType) {
        log.info("api path==>{}{}", apiKeycloakUrl, apiPath);
        log.info("httpMethod==>{}", httpMethod);
        log.info("entity==>{}", entity.getBody());
        ResponseEntity<T> responseEntity = restTemplate.exchange(apiKeycloakUrl + apiPath, httpMethod, entity, responseType);
        return gettResponseEntity(apiPath, entity, responseEntity);
    }

    public <T> ResponseEntity<T> sendKeycloakRestApi(String apiPath, HttpMethod httpMethod, HttpEntity<?> entity, ParameterizedTypeReference<T> responseType) {
        ResponseEntity<T> responseEntity = restTemplate.exchange(apiKeycloakUrl + apiPath, httpMethod, entity, responseType);
        return gettResponseEntity(apiPath, entity, responseEntity);
    }
}
