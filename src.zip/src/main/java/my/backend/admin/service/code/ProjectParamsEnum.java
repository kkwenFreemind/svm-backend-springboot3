package my.backend.admin.service.code;

import lombok.Getter;

@Getter
public enum ProjectParamsEnum {

    INTERSECTION_GROUP("intersectionGroup", null),
    GATEWAY_VENDOR_GROUP("gatewayVendorGroup", "{\"oring\":\"威力\",\"atop\":\"atop\"}"),
    UPS_VENDOR_GROUP("upsVendorGroup", "{\"powercom\":\"科風\"}"),
    BATTERY_VENDOR_GROUP("batteryVendorGroup", "{\"gogoro\":\"gogoro\",\"kycom\":\"KYCOM\"}"),
    MAP_INIT_LATITUDE("mapInitLatitude", null),
    MAP_INIT_LONGITUDE("mapInitLongitude", null),
    MAP_INIT_ZOOM("mapInitZoom", null),
    ;

    private final String paramNo;
    private final String defaultValue;

    ProjectParamsEnum(String paramNo, String defaultValue) {
        this.paramNo = paramNo;
        this.defaultValue = defaultValue;
    }
}
