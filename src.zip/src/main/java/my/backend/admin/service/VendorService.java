package my.backend.admin.service;


import my.backend.admin.service.dto.VendorDto;
import my.backend.persistence.model.VendorInfoEntity;

public interface VendorService {

    VendorDto createVendor(VendorDto vendorDto);

    VendorInfoEntity getVendor(String token);
}
