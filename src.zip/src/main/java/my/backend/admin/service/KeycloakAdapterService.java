package my.backend.admin.service;

import my.backend.admin.service.dto.*;

import java.util.List;

public interface KeycloakAdapterService {

    void addGroupFromUser(String authToken, String userId, String roleGroupId);

    String createUser(String authToken, KeycloakUserDto keycloakUserDto);

    String createKeycloakUser(String authToken, KeycloakCreateUserDto keycloakCreateUserDto);

    void deleteGroupFromUser(String authToken, String userId, String roleGroupId);

    void deleteUser(String authToken, String userId);

    KeycloakAuthTokenDto getKeycloakToken(String email, String pd, String totp);

    List<KeycloakUserGroupDto> getUserGroupList(String authToken);

    KeycloakAuthTokenDto refreshToken(String refreshToken);

    String resetPassword(String authToken, ResetPasswordDto resetPasswordDto);

}
