package my.backend.admin.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;


@Schema
@Data
@ToString
public class ResetPasswordDto {

    @Schema(description = "ID")
    private String id;

    @Schema(description = "是否為暫時密碼")
    private Boolean temporary;

    @Schema(description = "類型")
    private String type;

    @Schema(description = "密碼")
    private String value;

    public ResetPasswordDto(String id, String value) {
        this.id = id;
        this.value = value;
    }

}
