package my.backend.admin.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Timestamp;


@Schema
@Data
@NoArgsConstructor
public class VendorDto {

    private String vendorId;
    private String vendorLabel;
    private String vendorPwd;
    private String vendorToken;
    private String projectId;
    private Long createTime;
    private Long updateTime;
}
