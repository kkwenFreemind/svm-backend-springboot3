package my.backend.admin.service.impl;


import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import my.backend.admin.service.VendorService;
import my.backend.admin.service.dto.VendorDto;
import my.backend.common.utils.BmsUtils;
import my.backend.persistence.model.VendorInfoEntity;
import my.backend.persistence.repository.VendorInfoRepo;
import org.springframework.stereotype.Service;

import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;

import java.security.Key;
import java.security.SecureRandom;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.UUID;

@Slf4j
@Service
public class VendorServiceImpl implements VendorService {

    @Resource
    VendorInfoRepo vendorInfoRepo;

    private static final String CHARACTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*()-_+=<>?";
    private static final int PASSWORD_LENGTH = 12;
    private static final Key key = Keys.secretKeyFor(SignatureAlgorithm.HS256); // 使用 HMAC SHA-256 算法生成密鑰+

    @Override
    public VendorDto createVendor(VendorDto vendorDto) {
        VendorInfoEntity vendorInfoEntity = new VendorInfoEntity();
        vendorInfoEntity.setVendorId(UUID.randomUUID().toString());
        vendorInfoEntity.setVendorLabel(vendorDto.getVendorLabel());
        vendorInfoEntity.setCreateTime(LocalDateTime.now());
        vendorInfoEntity.setUpdateTime(LocalDateTime.now());
        vendorInfoEntity.setProjectId(vendorDto.getProjectId());
        vendorInfoEntity.setVendorToken(generateToken(vendorDto.getVendorLabel()));
        vendorInfoEntity.setVendorPwd(generatePassword(12));
        vendorInfoRepo.save(vendorInfoEntity);

        vendorDto.setVendorId(vendorInfoEntity.getVendorId());
        vendorDto.setVendorPwd(vendorInfoEntity.getVendorPwd());
        vendorDto.setCreateTime(BmsUtils.toEpochMilli(vendorInfoEntity.getCreateTime()));
        return vendorDto;
    }

    @Override
    public VendorInfoEntity getVendor(String token) {
        return vendorInfoRepo.findByVendorToken(token);

    }

    private String generatePassword(int length) {
        SecureRandom random = new SecureRandom();
        StringBuilder password = new StringBuilder(length);

        for (int i = 0; i < length; i++) {
            int index = random.nextInt(CHARACTERS.length());
            password.append(CHARACTERS.charAt(index));
        }
        return password.toString();
    }

    public static String generateToken(String subject) {
        return Jwts.builder()
                .setSubject(subject)
                .setIssuedAt(new Date())
                .setExpiration(new Date(System.currentTimeMillis() + 3600000)) // 1 小時後過期
                .signWith(key)
                .compact();
    }
}
