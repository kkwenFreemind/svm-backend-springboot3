package my.backend.admin.service.impl;

import jakarta.annotation.Resource;
import my.backend.admin.controller.dto.ProjectDto;
import my.backend.common.code.RoleGroupEnum;
import my.backend.common.utils.BmsUtils;
import my.backend.persistence.model.ProjectInfoEntity;
import my.backend.persistence.repository.ProjectInfoRepo;
import my.backend.admin.service.ProjectService;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import my.backend.common.cache.BmsCacheManager;

import java.util.*;


@Service
public class ProjectServiceImpl implements ProjectService {

    @Resource
    private ProjectInfoRepo projectInfoRepo;

    @Resource
    private BmsCacheManager bmsCacheManager;
    @Resource
    private BmsUtils bmsUtils;


    @Override
    @Transactional
    @Modifying
    public ProjectDto createProject(String actionUserId, ProjectDto projectDto) {
        projectDto.setProjectId(UUID.randomUUID().toString());
        ProjectInfoEntity projectInfoEntity = new ProjectInfoEntity(projectDto);
        projectInfoRepo.save(projectInfoEntity);
        return projectDto;
    }

    @Override
    public String deleteProject(String actionUserId, String projectId) {
        return "";
    }

    @Override
    public List<ProjectDto> getProjectList(String actionUserId, String userRoleGroupName) {
        List<ProjectInfoEntity> projectInfoEntityList = projectInfoRepo.findAllByOrderByCreateTimeDesc();
        ////
        RoleGroupEnum role = RoleGroupEnum.getByRoleGroup(userRoleGroupName);
        if (role.equals(RoleGroupEnum.SYSTEM_ADMIN)) {
            return genProjectDtoList(projectInfoEntityList);
        }
        ////
        Map<String, Set<String>> userProjectMapByUserId = bmsCacheManager.getUserProjectMapByUserId();
        Set<String> projectIdSet = userProjectMapByUserId.get(actionUserId);
        ArrayList<ProjectInfoEntity> tmpProjectInfoEntityList = new ArrayList<>();
        for (ProjectInfoEntity projectInfoEntity : projectInfoEntityList) {
            if (projectIdSet.contains(projectInfoEntity.getProjectId())) {
                tmpProjectInfoEntityList.add(projectInfoEntity);
            }
        }
        return genProjectDtoList(tmpProjectInfoEntityList);
    }

    private List<ProjectDto> genProjectDtoList(List<ProjectInfoEntity> projectInfoEntityList) {
        Map<String, Map<String, String>> projectParamMapMap = bmsCacheManager.getProjectParamMapMap();
        List<ProjectDto> projectDtoList = new ArrayList<>();
        for (ProjectInfoEntity projectInfoEntity : projectInfoEntityList) {
            ProjectDto projectDto = new ProjectDto(projectInfoEntity, projectParamMapMap.get(projectInfoEntity.getProjectId()));
            projectDto.setUserIdList(getUserIdListByProjectId(projectDto.getProjectId()));
            projectDto.setCreateTime(BmsUtils.toEpochMilli(projectInfoEntity.getCreateTime()));
            projectDto.setUpdateTime(BmsUtils.toEpochMilli(projectInfoEntity.getUpdateTime()));
            projectDto.setEnabled(projectInfoEntity.getEnabled());
            projectDtoList.add(projectDto);
        }
        return projectDtoList;
    }

    private List<String> getUserIdListByProjectId(String projectId) {
        Set<String> userIdSet = bmsCacheManager.getUserProjectMapByProjectId().get(projectId);
        if (userIdSet != null) {
            //// remove client id
            Set<String> clientIdSet = bmsCacheManager.getClientInfoMapByClientId().keySet();
            userIdSet.removeAll(clientIdSet);
            ////
            return new ArrayList<>(userIdSet);
        }
        return new ArrayList<>();
    }


    @Override
    public ProjectDto updateProject(String actionUserId, ProjectDto projectDto) {
        return null;
    }

    @Override
    public ProjectInfoEntity getProjectInfo(String projectId) {
        return  projectInfoRepo.findByProjectId(projectId);
    }

    @Override
    public List<ProjectInfoEntity> getAllProjectList() {
        return projectInfoRepo.findAll();
    }


}
