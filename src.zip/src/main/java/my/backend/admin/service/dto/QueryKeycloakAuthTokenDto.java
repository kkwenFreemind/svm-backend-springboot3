package my.backend.admin.service.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;

@Schema
@Data
@ToString
public class QueryKeycloakAuthTokenDto {

    @Schema(description = "客戶端ID")
    @JsonProperty("client_id")
    private String clientId;
    @Schema(description = "客戶端Secret")
    @JsonProperty("client_secret")
    private String clientSt;
    @Schema(description = "授權類型")
    @JsonProperty("grant_type")
    private String grantType;
    @Schema(description = "客戶端密碼")
    @JsonProperty("pd")
    private String pd;
    @Schema(description = "刷新令牌")
    @JsonProperty("refresh_token")
    private String refreshToken;
    @Schema(description = "TOTP")
    @JsonProperty("totp")
    private String totp;
    @Schema(description = "用戶名稱")
    @JsonProperty("username")
    private String username;

    public QueryKeycloakAuthTokenDto(String apiKeycloakClientId, String apiKeycloakClientSt, String grantType, String username, String pd, String totp) {
        this.clientId = apiKeycloakClientId;
        this.clientSt = apiKeycloakClientSt;
        this.grantType = grantType;
        this.pd = pd;
        this.username = username;
        this.totp = totp;
    }

    public QueryKeycloakAuthTokenDto(String apiKeycloakClientId, String apiKeycloakClientSecret, String grantType, String refreshToken) {
        this.clientId = apiKeycloakClientId;
        this.clientSt = apiKeycloakClientSecret;
        this.grantType = grantType;
        this.refreshToken = refreshToken;
    }

}
