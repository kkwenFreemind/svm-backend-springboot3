package my.backend.admin.service.impl;

import jakarta.annotation.Resource;
import my.backend.admin.service.dto.*;
import my.backend.common.error.ErrorCode;
import my.backend.common.exception.ActionRuntimeException;
import my.backend.admin.service.KeycloakAdapterService;
import my.backend.admin.service.utils.KeycloakUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.List;

@Service
public class KeycloakAdapterServiceImpl implements KeycloakAdapterService {

    @Value("${keycloak.token.client-id}")
    private String apiKeycloakClientId;

    @Value("${keycloak.token.secret}")
    private String apiKeycloakClientSecret;

    @Value("${keycloak.realm}")
    private String apiKeycloakRealm;

    @Resource
    private KeycloakUtils keycloakUtils;

    @Override
    public void addGroupFromUser(String authToken, String userId, String roleGroupId) {
        HttpEntity<Void> entity = new HttpEntity<>(genKeycloakHeader(authToken));
        keycloakUtils.sendKeycloakRestApi("/admin/realms/" + apiKeycloakRealm + "/users/" + userId + "/groups/" + roleGroupId, HttpMethod.PUT, entity, String.class);
    }

    @Override
    public String createUser(String authToken, KeycloakUserDto keycloakUserDto) {
        HttpEntity<KeycloakUserDto> entity = new HttpEntity<>(keycloakUserDto, genKeycloakHeader(authToken));
        keycloakUtils.sendKeycloakRestApi("/admin/realms/" + apiKeycloakRealm + "/users", HttpMethod.POST, entity, String.class);
        return getUserIdByUserName(authToken, keycloakUserDto.getUsername());
    }

    @Override
    public String createKeycloakUser(String authToken, KeycloakCreateUserDto keycloakCreateUserDto) {
        HttpEntity<KeycloakCreateUserDto> entity = new HttpEntity<>(keycloakCreateUserDto, genKeycloakHeader(authToken));
        keycloakUtils.sendKeycloakRestApi("/admin/realms/" + apiKeycloakRealm + "/users", HttpMethod.POST, entity, String.class);
        return getUserIdByUserName(authToken, keycloakCreateUserDto.getUsername());
    }

    @Override
    public void deleteGroupFromUser(String authToken, String userId, String roleGroupId) {
        HttpEntity<Void> entity = new HttpEntity<>(genKeycloakHeader(authToken));
        keycloakUtils.sendKeycloakRestApi("/admin/realms/" + apiKeycloakRealm + "/users/" + userId + "/groups/" + roleGroupId, HttpMethod.DELETE, entity, String.class);
    }

    @Override
    public void deleteUser(String authToken, String userId) {
        HttpEntity<Void> entity = new HttpEntity<>(genKeycloakHeader(authToken));
        keycloakUtils.sendKeycloakRestApi("/admin/realms/" + apiKeycloakRealm + "/users/" + userId, HttpMethod.DELETE, entity, String.class);
    }

    private HttpHeaders genKeycloakHeader(String token) {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/json");
        headers.set("Authorization", "Bearer " + token);
        return headers;
    }

    private HttpHeaders genKeycloakTokenHeader() {
        HttpHeaders headers = new HttpHeaders();
        headers.set("Content-Type", "application/x-www-form-urlencoded");
        return headers;
    }

    @Override
    public KeycloakAuthTokenDto getKeycloakToken(String username, String pd, String totp) {
        return getOAuthTokenFromKeycloak(new QueryKeycloakAuthTokenDto(apiKeycloakClientId, apiKeycloakClientSecret, "password", username, pd, totp));
    }

    private KeycloakAuthTokenDto getOAuthTokenFromKeycloak(QueryKeycloakAuthTokenDto queryKeycloakAuthTokenDto) {
        MultiValueMap<String, String> requestBody = new LinkedMultiValueMap<>();
        requestBody.add("grant_type", queryKeycloakAuthTokenDto.getGrantType());
        requestBody.add("username", queryKeycloakAuthTokenDto.getUsername());
        requestBody.add("password", queryKeycloakAuthTokenDto.getPd());
        requestBody.add("client_id", queryKeycloakAuthTokenDto.getClientId());
        requestBody.add("client_secret", queryKeycloakAuthTokenDto.getClientSt());
        requestBody.add("refresh_token", queryKeycloakAuthTokenDto.getRefreshToken());
        requestBody.add("totp", queryKeycloakAuthTokenDto.getTotp());
        HttpEntity<MultiValueMap<String, String>> entity = new HttpEntity<>(requestBody, genKeycloakTokenHeader());
        ResponseEntity<KeycloakAuthTokenDto> response = keycloakUtils.sendKeycloakRestApi("/realms/" + apiKeycloakRealm + "/protocol/openid-connect/token", HttpMethod.POST, entity, KeycloakAuthTokenDto.class);
        return response.getBody();
    }

    @Override
    public List<KeycloakUserGroupDto> getUserGroupList(String authToken) {
        HttpEntity<Void> entity = new HttpEntity<>(genKeycloakHeader(authToken));
        ResponseEntity<List<KeycloakUserGroupDto>> response = keycloakUtils.sendKeycloakRestApi("/admin/realms/" + apiKeycloakRealm + "/groups", HttpMethod.GET, entity, new ParameterizedTypeReference<List<KeycloakUserGroupDto>>() {
        });
        List<KeycloakUserGroupDto> keycloakUserGroupDtoList = response.getBody();
        if (keycloakUserGroupDtoList == null || keycloakUserGroupDtoList.isEmpty()) {
            throw new ActionRuntimeException(ErrorCode.ROLE_GROUP_NOT_FOUND);
        }
        return keycloakUserGroupDtoList;
    }


    public String getUserIdByUserName(String authToken, String name) {
        HttpEntity<Void> entity = new HttpEntity<>(genKeycloakHeader(authToken));
        ResponseEntity<List<KeycloakUserDto>> response = keycloakUtils.sendKeycloakRestApi("/admin/realms/" + apiKeycloakRealm + "/users", HttpMethod.GET, entity, new ParameterizedTypeReference<List<KeycloakUserDto>>() {
        });
        List<KeycloakUserDto> keycloakUserDtoList = response.getBody();
        if (keycloakUserDtoList != null && !keycloakUserDtoList.isEmpty()) {
            for (KeycloakUserDto keycloakUserDto : keycloakUserDtoList) {
                if (name.equals(keycloakUserDto.getUsername())) {
                    return keycloakUserDto.getId();
                }
            }
        }
        throw new ActionRuntimeException(ErrorCode.USER_NOT_FOUND);
    }

    @Override
    public KeycloakAuthTokenDto refreshToken(String refreshToken) {
        return getOAuthTokenFromKeycloak(new QueryKeycloakAuthTokenDto(apiKeycloakClientId, apiKeycloakClientSecret, "refresh_token", refreshToken));
    }

    @Override
    public String resetPassword(String authToken, ResetPasswordDto resetPasswordDto) {
        resetPasswordDto.setType("password");
        resetPasswordDto.setTemporary(false);
        HttpEntity<ResetPasswordDto> entity = new HttpEntity<>(resetPasswordDto, genKeycloakHeader(authToken));
        return keycloakUtils.sendKeycloakRestApi("/admin/realms/" + apiKeycloakRealm + "/users/" + resetPasswordDto.getId() + "/reset-password", HttpMethod.PUT, entity, String.class).getBody();
    }
}
