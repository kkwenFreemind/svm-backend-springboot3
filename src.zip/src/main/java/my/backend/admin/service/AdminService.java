package my.backend.admin.service;

import my.backend.admin.service.dto.KeycloakAuthTokenDto;
import my.backend.admin.service.dto.RoleGroupDto;
import my.backend.iot.client.dto.ClientLoginDto;
import my.backend.admin.controller.dto.UserLoginDto;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.List;

public interface AdminService {

    KeycloakAuthTokenDto getAuthToken(UserLoginDto userLoginDto) throws NoSuchAlgorithmException, InvalidKeyException;

    KeycloakAuthTokenDto getClientAccessToken(ClientLoginDto clientLoginDto);

    List<RoleGroupDto> getRoleGroupList(String authToken);

}
