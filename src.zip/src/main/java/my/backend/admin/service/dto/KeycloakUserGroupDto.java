package my.backend.admin.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Schema(description = "Keycloak User Group Dto")
@Data
@ToString
public class KeycloakUserGroupDto {

    @Schema(description = "id")
    private String id;

    @Schema(description = "name")
    private String name;

    @Schema(description = "path")
    private String path;

    @Schema(description = "subGroups")
    private List<String> subGroups;

}
