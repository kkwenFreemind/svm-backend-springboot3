package my.backend.admin.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;

@Schema
@Data
@ToString
public class RoleGroupDto {

    @Schema(description = "角色群組描述")
    private String roleGroupDesc;

    @Schema(description = "角色群組ID")
    private String roleGroupId;

    @Schema(description = "角色群組名稱")
    private String roleGroupName;

}
