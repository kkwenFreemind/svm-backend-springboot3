package my.backend.admin.service.utils;

import jakarta.annotation.Resource;
import my.backend.common.cache.BmsCacheManager;
import my.backend.admin.service.KeycloakAdapterService;
import my.backend.persistence.model.*;
import my.backend.persistence.model.pk.UserGroupPk;
import my.backend.persistence.model.pk.UserProjectPk;
import my.backend.persistence.repository.*;
import my.backend.admin.service.code.LogEntityStatusEnum;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class UserProjectUtils {

    public static final String PROJECT = "project";
    public static final String USER = "user";
    public static final String USER_GROUP = "user_group";

    @Resource
    private BmsCacheManager bmsCacheManager;

    @Resource
    private ChangeSecretLogRepo changeSecretLogRepo;

    @Resource
    private KeycloakAdapterService keycloakAdapterService;
    @Resource
    private UserGroupInfoLogRepo userGroupInfoLogRepo;
    @Resource
    private UserGroupInfoRepo userGroupInfoRepo;
    @Resource
    private UserGroupLogRepo userGroupLogRepo;
    @Resource
    private UserGroupRepo userGroupRepo;
    @Resource
    private UserInfoLogRepo userInfoLogRepo;
    @Resource
    private UserInfoRepo userInfoRepo;

    @Resource
    private UserProjectRepo userProjectRepo;

    @Resource
    private UserProjectLogRepo userProjectLogRepo;


    public void checkAndUpdateUserGroup(String actionUserId, String target, String pairId, List<String> targetIdList) {
        ////
        HashMap<String, UserGroupEntity> beforeUserGroupMap = getBeforeUserGroupMap(target, pairId);
        HashSet<String> afterUserGroupIdSet = targetIdList == null ? new HashSet<String>() : new HashSet<String>(targetIdList);
        HashSet<String> allUserGroupIdSet = new HashSet<>(beforeUserGroupMap.keySet());
        allUserGroupIdSet.addAll(afterUserGroupIdSet);
        ////
        if (!allUserGroupIdSet.isEmpty()) {
            for (String targetId : allUserGroupIdSet) {
                UserGroupEntity userGroupEntity = beforeUserGroupMap.get(targetId);
                if (userGroupEntity == null) {
                    ////before沒有但after有，新增
                    insertUserGroup(actionUserId, target, pairId, targetId);
                } else if (afterUserGroupIdSet.contains(targetId)) {
                    ////before有跟after有，更新
                    updateUserGroup(actionUserId, userGroupEntity);
                } else {
                    ////before有但after沒有，刪除
                    deleteUserGroup(actionUserId, userGroupEntity);
                }
            }
        }
    }


    public void deleteUserGroup(String actionUserId, UserGroupEntity userGroupEntity) {
        userGroupRepo.delete(userGroupEntity);
        userGroupLogRepo.save(genUserGroupLogEntity(actionUserId, userGroupEntity, LogEntityStatusEnum.DELETE.getStatus()));
    }

    public void deleteUserGroupInfo(String actionUserId, UserGroupInfoEntity userGroupInfoEntity) {
        userGroupInfoRepo.delete(userGroupInfoEntity);
        userGroupInfoLogRepo.save(genUserGroupInfoLogEntity(actionUserId, userGroupInfoEntity, LogEntityStatusEnum.DELETE.getStatus()));
        userGroupRepo.findAllByUserGroupPkUserGroupId(userGroupInfoEntity.getUserGroupId()).forEach(userGroupEntity -> deleteUserGroup(actionUserId, userGroupEntity));
    }


    public UserGroupInfoLogEntity genUserGroupInfoLogEntity(String actionUserId, UserGroupInfoEntity userGroupInfoEntity, String status) {
        UserGroupInfoLogEntity userGroupInfoLogEntity = new UserGroupInfoLogEntity();
        BeanUtils.copyProperties(userGroupInfoEntity, userGroupInfoLogEntity);
        userGroupInfoLogEntity.setActionUserId(actionUserId);
        userGroupInfoLogEntity.setStatus(status);
        return userGroupInfoLogEntity;
    }

    public UserGroupLogEntity genUserGroupLogEntity(String actionUserId, UserGroupEntity userGroupEntity, String status) {
        UserGroupLogEntity userGroupLogEntity = new UserGroupLogEntity();
        UserGroupPk userGroupPk = userGroupEntity.getUserGroupPk();
        userGroupLogEntity.setUserGroupId(userGroupPk.getUserGroupId());
        userGroupLogEntity.setUserId(userGroupPk.getUserId());
        userGroupLogEntity.setActionUserId(actionUserId);
        userGroupLogEntity.setStatus(status);
        return userGroupLogEntity;
    }

    public UserInfoLogEntity genUserInfoLogEntity(String actionUserId, UserInfoEntity userInfoEntity, String status) {
        UserInfoLogEntity userInfoLogEntity = new UserInfoLogEntity();
        BeanUtils.copyProperties(userInfoEntity, userInfoLogEntity);
        userInfoLogEntity.setActionUserId(actionUserId);
        userInfoLogEntity.setStatus(status);
        return userInfoLogEntity;
    }

    public HashMap<String, UserGroupEntity> getBeforeUserGroupMap(String target, String pairId) {
        HashMap<String, UserGroupEntity> beforeUserGroupMap = new HashMap<>();
        if (target.equals(USER_GROUP)) {
            List<UserGroupEntity> userGroupEntityList = userGroupRepo.findAllByUserGroupPkUserId(pairId);
            if (userGroupEntityList != null && userGroupEntityList.size() > 0) {
                for (UserGroupEntity userGroupEntity : userGroupEntityList) {
                    beforeUserGroupMap.put(userGroupEntity.getUserGroupPk().getUserGroupId(), userGroupEntity);
                }
            }
        } else if (target.equals(USER)) {
            List<UserGroupEntity> userGroupEntityList = userGroupRepo.findAllByUserGroupPkUserGroupId(pairId);
            if (userGroupEntityList != null && userGroupEntityList.size() > 0) {
                userGroupEntityList.forEach(userGroupEntity -> beforeUserGroupMap.put(userGroupEntity.getUserGroupPk().getUserId(), userGroupEntity));
            }
        }
        return beforeUserGroupMap;
    }

    private UserGroupPk getUserGroupPk(String target, String pairId, String targetId) {
        UserGroupPk userGroupPk = null;
        if (USER_GROUP.equals(target)) {
            userGroupPk = new UserGroupPk(pairId, targetId);
        } else if (USER.equals(target)) {
            userGroupPk = new UserGroupPk(targetId, pairId);
        }
        return userGroupPk;
    }

    private UserProjectPk getUserProjectPk(String target, String pairId, String targetId) {
        UserProjectPk userProjectPk = null;
        if (PROJECT.equals(target)) {
            userProjectPk = new UserProjectPk(pairId, targetId);
        } else if (USER.equals(target)) {
            userProjectPk = new UserProjectPk(targetId, pairId);
        }
        return userProjectPk;
    }

    private void insertUserGroup(String actionUserId, String target, String pairId, String targetId) {
        UserGroupEntity userGroupEntity;
        userGroupEntity = new UserGroupEntity();
        userGroupEntity.setUserGroupPk(getUserGroupPk(target, pairId, targetId));
        userGroupRepo.save(userGroupEntity);
        userGroupLogRepo.save(genUserGroupLogEntity(actionUserId, userGroupEntity, LogEntityStatusEnum.INSERT.getStatus()));
    }


    public void saveChangeSecretLog(String actionUserId, String userId, String userType) {
        ChangeSecretLogEntity changeSecretLogEntity = new ChangeSecretLogEntity();
        changeSecretLogEntity.setUserType(userType);
        changeSecretLogEntity.setActionUserId(actionUserId);
        changeSecretLogEntity.setUserId(userId);
        changeSecretLogRepo.save(changeSecretLogEntity);
    }

    private void updateUserGroup(String actionUserId, UserGroupEntity userGroupEntity) {
        userGroupRepo.save(userGroupEntity);
        userGroupLogRepo.save(genUserGroupLogEntity(actionUserId, userGroupEntity, LogEntityStatusEnum.UPDATE.getStatus()));
    }

    public void checkAndUpdateUserProject(String actionUserId, String target, String pairId, List<String> targetIdList) {
        ////
        HashMap<String, UserProjectEntity> beforeUserProjectMap = getBeforeUserProjectMap(target, pairId);
        HashSet<String> afterTargetIdSet = targetIdList == null ? new HashSet<String>() : new HashSet<String>(targetIdList);
        HashSet<String> allTargetIdSet = new HashSet<>(beforeUserProjectMap.keySet());
        allTargetIdSet.addAll(afterTargetIdSet);
        //// remove client id
        if (target.equals(USER)) {
            allTargetIdSet.removeAll(bmsCacheManager.getClientInfoMapByClientId().keySet());
        }
        ////
        if (!allTargetIdSet.isEmpty()) {
            for (String targetId : allTargetIdSet) {
                UserProjectEntity userProjectEntity = beforeUserProjectMap.get(targetId);
                if (userProjectEntity == null) {
                    ////before無但after有，新增
                    insertUserProject(actionUserId, target, pairId, targetId);
                } else if (afterTargetIdSet.contains(targetId)) {
                    ////before有跟after有，更新
                    updateUserProject(actionUserId, userProjectEntity);
                } else {
                    ////before有但after無，刪除
                    deleteUserProject(actionUserId, userProjectEntity);
                }
            }
        }
    }

    private HashMap<String, UserProjectEntity> getBeforeUserProjectMap(String target, String pairId) {
        List<UserProjectEntity> userProjectEntityList;
        if (target.equals(PROJECT)) {
            userProjectEntityList = userProjectRepo.findAllByUserProjectPkUserId(pairId);
        } else if (target.equals(USER)) {
            userProjectEntityList = userProjectRepo.findAllByUserProjectPkProjectId(pairId);
        } else {
            return new HashMap<>();
        }
        return userProjectEntityList.stream()
                .collect(Collectors.toMap(
                        entity -> target.equals(PROJECT) ? entity.getUserProjectPk().getProjectId() : entity.getUserProjectPk().getUserId(),
                        entity -> entity,
                        (entity1, entity2) -> entity1,
                        HashMap::new
                ));
    }

    public void insertUserProject(String actionUserId, String target, String pairId, String targetId) {
        UserProjectEntity userProjectEntity = new UserProjectEntity();
        userProjectEntity.setUserProjectPk(getUserProjectPk(target, pairId, targetId));
        userProjectRepo.save(userProjectEntity);
        userProjectLogRepo.save(genUserProjectLogEntity(actionUserId, userProjectEntity, LogEntityStatusEnum.INSERT.getStatus()));
    }

    private void updateUserProject(String actionUserId, UserProjectEntity userProjectEntity) {
        userProjectRepo.save(userProjectEntity);
        userProjectLogRepo.save(genUserProjectLogEntity(actionUserId, userProjectEntity, LogEntityStatusEnum.UPDATE.getStatus()));
    }

    public UserProjectLogEntity genUserProjectLogEntity(String actionUserId, UserProjectEntity userProjectEntity, String status) {
        UserProjectLogEntity userProjectLogEntity = new UserProjectLogEntity();
        UserProjectPk userProjectPk = userProjectEntity.getUserProjectPk();
        userProjectLogEntity.setUserId(userProjectPk.getUserId());
        userProjectLogEntity.setProjectId(userProjectPk.getProjectId());
        userProjectLogEntity.setActionUserId(actionUserId);
        userProjectLogEntity.setStatus(status);
        return userProjectLogEntity;
    }

    public void deleteUserProject(String actionUserId, UserProjectEntity userProjectEntity) {
        userProjectRepo.delete(userProjectEntity);
        userProjectLogRepo.save(genUserProjectLogEntity(actionUserId, userProjectEntity, LogEntityStatusEnum.DELETE.getStatus()));
    }

    public void deleteUserProjectByUserId(String actionUserId, String userId) {
        userProjectRepo.findAllByUserProjectPkUserId(userId).forEach(userProjectEntity -> deleteUserProject(actionUserId, userProjectEntity));
    }

}
