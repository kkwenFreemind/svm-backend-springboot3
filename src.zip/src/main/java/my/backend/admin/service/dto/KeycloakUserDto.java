package my.backend.admin.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;

@Schema(description = "KeyCloak用戶信息")
@Data
@ToString
public class KeycloakUserDto {

    @Schema(description = "email")
    private String email;

    @Schema(description = "emailVerified")
    private Boolean emailVerified;

    @Schema(description = "enabled")
    private Boolean enabled;

    @Schema(description = "firstName")
    private String firstName;

    @Schema(description = "groups")
    private String[] groups;

    @Schema(description = "id")
    private String id;

    @Schema(description = "lastName")
    private String lastName;

    @Schema(description = "realmRoles")
    private String[] realmRoles;

    @Schema(description = "username")
    private String username;


}
