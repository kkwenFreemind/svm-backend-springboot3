package my.backend.admin.service;

import my.backend.admin.controller.dto.ProjectDto;
import my.backend.persistence.model.ProjectInfoEntity;

import java.util.List;

public interface ProjectService {

    ProjectDto createProject(String actionUserId, ProjectDto projectDto);

    String deleteProject(String actionUserId, String projectId);

    List<ProjectDto> getProjectList(String actionUserId, String userRoleGroupName);

    ProjectDto updateProject(String actionUserId, ProjectDto projectDto);

    ProjectInfoEntity getProjectInfo(String projectId);

    List<ProjectInfoEntity> getAllProjectList();
}
