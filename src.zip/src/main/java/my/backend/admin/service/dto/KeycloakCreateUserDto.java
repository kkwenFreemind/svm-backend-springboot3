package my.backend.admin.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Schema(description = "KeyCloak創建用戶信息")
@Data
public class KeycloakCreateUserDto {


    private String username;
    private boolean enabled;
    private boolean emailVerified;
    private String firstName;
    private String lastName;
    private String email;
    private List<CredentialDTO> credentials;

    // 默認構造函數
    public void UserCreationDTO() {
    }

    // 全參數構造函數
    public void UserCreationDTO(String username, boolean enabled, boolean emailVerified,
                                String firstName, String lastName, String email,
                                List<CredentialDTO> credentials) {
        this.username = username;
        this.enabled = enabled;
        this.emailVerified = emailVerified;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.credentials = credentials;
    }

    // toString 方法用於調試
    @Override
    public String toString() {
        return "UserCreationDTO{" +
                "username='" + username + '\'' +
                ", enabled=" + enabled +
                ", emailVerified=" + emailVerified +
                ", firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", email='" + email + '\'' +
                ", credentials=" + credentials +
                '}';
    }

    // CredentialDTO 內部類
    @Data
    @Getter
    @Setter
    public static class CredentialDTO {
        private String type;

        private String value;

        private boolean temporary;

        // 默認構造函數
        public CredentialDTO() {
        }

        // 全參數構造函數
        public CredentialDTO(String type, String value, boolean temporary) {
            this.type = type;
            this.value = value;
            this.temporary = temporary;
        }

        // toString 方法用於調試
        @Override
        public String toString() {
            return "CredentialDTO{" +
                    "type='" + type + '\'' +
                    ", value='" + value + '\'' +
                    ", temporary=" + temporary +
                    '}';
        }
    }
}



