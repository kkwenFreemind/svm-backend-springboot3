package my.backend.admin.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;

@Schema
@Data
@ToString
public class ClientDto {
    @Schema(description = "客戶端ID")
    private String clientId;
    @Schema(description = "客戶端名稱")
    private String clientLabel;
    @Schema(description = "客戶端角色群組名稱")
    private String clientRoleGroupName;
    @Schema(description = "建立時間")
    private Long createTime;
    @Schema(description = "專案ID")
    private String projectId;
    @Schema(description = "更新時間")
    private Long updateTime;
}
