package my.backend.admin.service.impl;

import jakarta.annotation.Resource;
import lombok.extern.slf4j.Slf4j;
import my.backend.admin.service.dto.KeycloakAuthTokenDto;
import my.backend.admin.service.dto.RoleGroupDto;
import my.backend.common.cache.BmsCacheManager;
import my.backend.common.code.RoleGroupEnum;
import my.backend.common.error.ErrorCode;
import my.backend.common.exception.ActionRuntimeException;
import my.backend.iot.client.dto.ClientLoginDto;
import my.backend.admin.controller.dto.UserLoginDto;
import my.backend.admin.service.AdminService;
import my.backend.admin.service.KeycloakAdapterService;
import my.backend.persistence.model.ClientInfoEntity;
import my.backend.persistence.model.ClientLoginLogEntity;
import my.backend.persistence.model.UserInfoEntity;
import my.backend.persistence.model.UserLoginLogEntity;
import my.backend.persistence.repository.ClientInfoRepo;
import my.backend.persistence.repository.ClientLoginLogRepo;
import my.backend.persistence.repository.UserInfoRepo;
import my.backend.persistence.repository.UserLoginLogRepo;
import org.springframework.stereotype.Service;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Service
@Slf4j
public class AdminServiceImpl  implements AdminService {

    @Resource
    private BmsCacheManager bmsCacheManager;

    @Resource
    private ClientLoginLogRepo clientLoginLogRepo;

    @Resource
    private UserInfoRepo userInfoRepo;

    @Resource
    private ClientInfoRepo clientInfoRepo;

    @Resource
    private KeycloakAdapterService keycloakAdapterService;

    @Resource
    private UserLoginLogRepo userLoginLogRepo;


    @Override
    public KeycloakAuthTokenDto getAuthToken(UserLoginDto userLoginDto) throws NoSuchAlgorithmException, InvalidKeyException {
        UserLoginLogEntity userLoginLogEntity = new UserLoginLogEntity();
        UserInfoEntity userInfoEntity = userInfoRepo.findByEmail(userLoginDto.getEmail());

        try {
            if (userInfoEntity == null) {
                userLoginLogEntity.setErrorCode(ErrorCode.USER_NOT_FOUND.getCode());
            } else {
                userLoginLogEntity.setUserId(userInfoEntity.getUserId());
                log.info("userInfoEntity.getUserId()==>{}", userInfoEntity.getUserId());
            }
            return keycloakAdapterService.getKeycloakToken(userLoginDto.getEmail(), userLoginDto.getSecret(), "");
        } catch (ActionRuntimeException e) {
            userLoginLogEntity.setErrorCode(e.getErrorCode().getCode());
            throw e;
        } finally {
            userLoginLogEntity.setIpAddress(userLoginDto.getClientIp());
            userLoginLogEntity.setEmail(userLoginDto.getEmail());
            userLoginLogRepo.save(userLoginLogEntity);
        }
    }

    @Override
    public KeycloakAuthTokenDto getClientAccessToken(ClientLoginDto clientLoginDto) {
        ClientLoginLogEntity clientLoginLogEntity = new ClientLoginLogEntity();
        try {
            ClientInfoEntity clientInfoEntity = clientInfoRepo.findByClientId(clientLoginDto.getClientId());
            if (clientInfoEntity == null) {
                throw new ActionRuntimeException(ErrorCode.CLIENT_NOT_FOUND);
            }
            clientLoginLogEntity.setClientId(clientInfoEntity.getClientId());
            return keycloakAdapterService.getKeycloakToken(clientInfoEntity.getClientName(), clientLoginDto.getClientSecret(), null);
        } catch (ActionRuntimeException e) {
            clientLoginLogEntity.setErrorCode(e.getErrorCode().getCode());
            throw e;
        } finally {
            clientLoginLogEntity.setIpAddress(clientLoginDto.getClientIp());
            clientLoginLogRepo.save(clientLoginLogEntity);
        }
    }

    @Override
    public List<RoleGroupDto> getRoleGroupList(String authToken) {
        RoleGroupEnum[] roleGroupEnums = RoleGroupEnum.values();
        Map<String, String> roleGroupMap = bmsCacheManager.getRoleGroupMap(authToken);
        List<RoleGroupDto> roleGroupList = new ArrayList<>();
        for (RoleGroupEnum roleGroupEnum : roleGroupEnums) {
            RoleGroupDto roleGroupDto = new RoleGroupDto();
            roleGroupDto.setRoleGroupId(roleGroupMap.get(roleGroupEnum.getRoleGroupName()));
            roleGroupDto.setRoleGroupName(roleGroupEnum.getRoleGroupName());
            roleGroupDto.setRoleGroupDesc(roleGroupEnum.getRoleGroupDesc());
            roleGroupList.add(roleGroupDto);
        }
        return roleGroupList;
    }
}
