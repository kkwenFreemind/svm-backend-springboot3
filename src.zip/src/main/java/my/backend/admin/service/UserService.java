package my.backend.admin.service;

import my.backend.iot.client.dto.UpdateStDto;
import my.backend.admin.controller.dto.UserDto;

import java.net.MalformedURLException;
import java.util.List;

public interface UserService {

    void applyUpdateUserSecret(String actionUserId) throws MalformedURLException;

    UserDto createUser(String authToken, String actionUserId, UserDto userDto);

    String deleteUser(String authToken, String actionUserId, String userId);

    String updateUserSecret(UpdateStDto updateStDto);

    List<UserDto> getProjectUserList(String actionUserId);


}

