package my.backend.admin.service.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import lombok.NoArgsConstructor;


@Schema
@Data
@NoArgsConstructor

//Lombok 會自動生成如下的構造函數：
public class UserLoginLogDto {

    @Schema(description = "userId")
    private String userId;
    @Schema(description = "email")
    @NotEmpty
    private String email;
    @Schema(description = "連線IP")
    private String clientIp;
    @Schema(description = "紀錄時間")
    private Long createTime;
    @Schema(description = "錯誤代碼")
    private String errorCode;
    @Schema(description = "錯誤訊息")
    private String errorMessage;

//    public UserLoginLogDto(UserLoginLogEntity entity) {
//        this.userId = entity.getUserId();
//        this.email = entity.getEmail();
//        this.clientIp = entity.getIpAddress();
//        this.createTime = BmsUtils.toEpochMilli(entity.getCreateTime());
//        if (entity.getErrorCode() != null) {
//            this.errorCode = entity.getErrorCode();
//            this.errorMessage = ErrorCode.valueOf(Integer.parseInt(entity.getErrorCode())).getMessage();
//        }
//    }

}
