package my.backend.admin.controller.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Schema
@Data
@ToString
public class UpdateProjectUserRequest {

    @Schema(description = "默認專案ID")
    @NotEmpty
    private String defaultProjectId;
    @Schema(description = "專案ID清單")
    @Size(min = 1)
    private List<String> projectIdList;
    @Schema(description = "使用者ID")
    @NotEmpty
    @Size(max = 50)
    private String userId;
    @Schema(description = "使用者名稱")
    @NotEmpty
    @Size(max = 30)
    private String userLabel;
    @Schema(description = "使用者角色群組名稱")
    @NotEmpty
    @Size(max = 50)
    private String userRoleGroupName;
}
