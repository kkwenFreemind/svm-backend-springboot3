package my.backend.admin.controller;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.annotation.Resource;
import jakarta.mail.MessagingException;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotEmpty;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import my.backend.admin.controller.dto.CreateProjectUserRequest;
import my.backend.admin.controller.dto.ProjectDto;
import my.backend.admin.controller.dto.UpdateProjectRequest;
import my.backend.admin.controller.dto.UserDto;
import my.backend.admin.service.UserService;
import my.backend.persistence.model.ProjectInfoEntity;
import my.backend.admin.service.dto.CreateProjectRequest;
import my.backend.admin.service.ProjectService;
import org.springframework.web.bind.annotation.*;

import java.net.MalformedURLException;
import java.util.List;

@RestController
@RequestMapping("${server.api-base-path}")
@RequiredArgsConstructor
@Slf4j
public class ProjectController extends BaseController {

    @Resource
    private ProjectService projectService;

    @Resource
    private UserService userService;

    @Operation(summary = "創建Project", description = "創建專案")
    @PostMapping(value = "/v1/auth/project")
    public ProjectDto createProject(@Valid @RequestBody CreateProjectRequest createProjectRequest) {
        validateCreateProjectRequest(createProjectRequest);
        return projectService.createProject(getActionUserId(), new ProjectDto(createProjectRequest));
    }

    @Operation(summary = "獲得Project資料", description = "獲得專案資料")
    @GetMapping(value = "/v1/auth/project/list")
    public List<ProjectDto> getProjectList() {
        return projectService.getProjectList(getActionUserId(), getUserRoleByToken());
    }

    @Operation(summary = "獲得單一Project資料", description = "獲得單一專案資料")
    @GetMapping(value = "/v1/auth/project/{projectId}")
    public ProjectInfoEntity getProjectById(@Valid String projectId){
        return projectService.getProjectInfo(projectId);
    }

    @Operation(summary = "獲得Project資料", description = "獲得專案資料")
    @GetMapping(value = "/v1/auth/project/")
    public List<ProjectInfoEntity> getAllProjectList() {
        return projectService.getAllProjectList();
    }

    @Operation(summary = "專案管理創建用戶", description = "專案管理創建用戶")
    @PostMapping(value = "/v1/auth/project/user")
    public UserDto createProjectUser(@Valid @RequestBody CreateProjectUserRequest createProjectUserRequest) throws MalformedURLException, MessagingException {
        validRoleGroupName(createProjectUserRequest.getUserRoleGroupName());
        validateProjectIdList(createProjectUserRequest.getProjectIdList());
        UserDto userDto = new UserDto(createProjectUserRequest);
        return userService.createUser(getAuthToken(), getActionUserId(), userDto);
    }

    @Operation(summary = "專案管理刪除用戶", description = "專案管理刪除用戶")
    @DeleteMapping(value = "/v1/auth/project/user")
    public String deleteProjectUser(@RequestParam @NotEmpty String userId) {
        return userService.deleteUser(getAuthToken(), getActionUserId(), userId);
    }

    @Operation(summary = "專案管理獲得用戶清單資料", description = "專案管理獲得用戶清單資料")
    @GetMapping(value = "/v1/auth/project/user/list")
    public List<UserDto> getProjectUserList() {
        return userService.getProjectUserList(getActionUserId());
    }

    @Operation(summary = "更新Project", description = "更新專案")
    @PutMapping(value = "/v1/auth/project")
    public ProjectDto updateProject(@Valid @RequestBody UpdateProjectRequest updateProjectRequest) {
        validUserIdList(updateProjectRequest.getUserIdList());
        return projectService.updateProject(getActionUserId(), new ProjectDto(updateProjectRequest));
    }
}
