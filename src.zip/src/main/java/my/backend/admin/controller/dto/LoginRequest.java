package my.backend.admin.controller.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;
import org.hibernate.validator.constraints.Length;

@Schema
@Data
public class LoginRequest {

    @Schema(description = "email")
    @NotEmpty
    private String email;
    @Schema(description = "secret")
    @NotEmpty
    private String secret;
    @Schema(description = "totp")
    private String totp;
    @Schema(description = "captcha")
    @NotEmpty
    @Length(max = 4)
    private String captcha;

    @Override
    public String toString() {
        return "LoginRequest(" +
                "email=" + email +
                ", secret=*****" +
                ", totp=" + totp +
                ", captcha=" + captcha +
                ")";
    }

}
