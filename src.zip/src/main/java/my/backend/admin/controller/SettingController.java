package my.backend.admin.controller;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.annotation.Resource;
import lombok.RequiredArgsConstructor;
import my.backend.admin.service.AdminService;
import my.backend.admin.service.dto.RoleGroupDto;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("${server.api-base-path}")
@RequiredArgsConstructor
@Validated
public class SettingController extends BaseController {

    @Resource
    private AdminService adminService;

    @Operation(summary = "獲得角色群組清單", description = "獲得角色群組清單")
    @GetMapping("/v1/auth/setting/role/group/list")
    public List<RoleGroupDto> getRoleGroupList() {
        return adminService.getRoleGroupList(getAuthToken());
    }

}
