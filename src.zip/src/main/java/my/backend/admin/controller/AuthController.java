package my.backend.admin.controller;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import my.backend.iot.client.dto.ClientAccessTokenRequest;
import my.backend.iot.client.dto.ClientLoginDto;
import my.backend.admin.controller.dto.LoginRequest;
import my.backend.admin.controller.dto.UserLoginDto;
import my.backend.common.aop.LoggingHelper;
import my.backend.admin.service.dto.KeycloakAuthTokenDto;
import my.backend.admin.service.AdminService;
import my.backend.admin.service.KeycloakAdapterService;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

@RestController
@RequestMapping("${server.api-base-path}")
@RequiredArgsConstructor
@Validated
public class AuthController extends BaseController {

    @Resource
    private AdminService adminService;

    @Resource
    private KeycloakAdapterService keycloakAdapterService;

    private static HttpHeaders getHttpHeaders(String refreshToken, String encryptValidateText) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("Set-Cookie", "refresh_token=" + refreshToken + ";Path=/;Secure;HttpOnly;SameSite=Strict;");
        headers.add("Set-Cookie", "validate_text=" + encryptValidateText + ";Path=/;Secure;HttpOnly;SameSite=Strict;");
        return headers;
    }

    @Operation(summary = "獲取用戶 AuthToken", description = "獲取 AuthToken")
    @PostMapping("/v1/noauth/token")
    public ResponseEntity<String> getAuthToken(@Valid @RequestBody LoginRequest loginRequest) throws NoSuchAlgorithmException, InvalidKeyException {
        UserLoginDto userLoginDto = new UserLoginDto(loginRequest.getEmail(), loginRequest.getSecret(), loginRequest.getTotp(), LoggingHelper.getClientIp(getHttpServletRequest()));
        KeycloakAuthTokenDto keycloakAuthTokenDto = adminService.getAuthToken(userLoginDto);
        return ResponseEntity.ok().headers(getHttpHeaders(keycloakAuthTokenDto.getRefreshToken(), "")).body("Bearer " + keycloakAuthTokenDto.getAccessToken());
    }

    @Operation(summary = "獲取 Client Access Token", description = "獲取 Client Access Token")
    @PostMapping("/v1/noauth/token/client")
    public ResponseEntity<String> getClientAccessToken(@Valid @RequestBody ClientAccessTokenRequest clientAccessTokenRequest) {
        ClientLoginDto clientLoginDto = new ClientLoginDto(clientAccessTokenRequest.getClientId(), clientAccessTokenRequest.getClientSecret(), LoggingHelper.getClientIp(getHttpServletRequest()));
        KeycloakAuthTokenDto keycloakAuthTokenDto = adminService.getClientAccessToken(clientLoginDto);
        return ResponseEntity.ok().headers(getHttpHeaders(keycloakAuthTokenDto.getRefreshToken(), "")).body("Bearer " + keycloakAuthTokenDto.getAccessToken());
    }

    @Operation(summary = "更新 AuthToken", description = "更新 AuthToken")
    @PostMapping("/v1/noauth/token/refresh")
    public ResponseEntity<String> refreshAuthToken() {
        KeycloakAuthTokenDto keycloakAuthTokenDto = keycloakAdapterService.refreshToken(getCookieValue("refresh_token"));
        return ResponseEntity.ok().headers(getHttpHeaders(keycloakAuthTokenDto.getRefreshToken(), "")).body("Bearer " + keycloakAuthTokenDto.getAccessToken());
    }

}
