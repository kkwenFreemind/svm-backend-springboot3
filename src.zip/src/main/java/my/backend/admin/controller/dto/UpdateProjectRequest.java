package my.backend.admin.controller.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.ToString;

import java.util.List;

@Schema
@Data
@ToString
public class UpdateProjectRequest {
    @Schema(description = "電池廠商群組")
    @NotEmpty
    private String batteryVendorGroup;
    @Schema(description = "啟用")
    @NotNull
    private Boolean enabled;
    @Schema(description = "閘道器廠商群組")
    @NotEmpty
    private String gatewayVendorGroup;
    @Schema(description = "路口群組")
    @NotEmpty
    private String intersectionGroup;
    @Schema(description = "地圖初始緯度")
    @NotEmpty
    private String mapInitLatitude;
    @Schema(description = "地圖初始經度")
    @NotEmpty
    private String mapInitLongitude;
    @Schema(description = "地圖初始縮放比例")
    @NotEmpty
    private String mapInitZoom;
    @Schema(description = "專案ID")
    @NotEmpty
    @Size(max = 50)
    private String projectId;
    @Schema(description = "專案標籤")
    @NotEmpty
    @Size(max = 30)
    private String projectLabel;
    @Schema(description = "UPS廠商群組")
    @NotEmpty
    private String upsVendorGroup;
    @Schema(description = "專案使用者ID清單")
    private List<String> userIdList;
}
