package my.backend.admin.controller;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.annotation.Resource;
import my.backend.common.cache.BmsCacheManager;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;


public class AdminController extends BaseController {

    @Resource
    private BmsCacheManager bmsCacheManager;

    @Operation(summary = "清除Cache", description = "清除Cache")
    @GetMapping("/v1/noauth/admin/cache/refresh")
    public ResponseEntity<String> refreshCache(@RequestParam String authToken) {
        if (!"c5cbb68f-f230-4ade-80ca-17690fa5fefc".equals(authToken)) {
            return ResponseEntity.status(401).body("AuthToken Error !!");
        }
        ////
        bmsCacheManager.refreshCache();
        return ResponseEntity.ok("REFRESH SUCCESS !!");
    }
}
