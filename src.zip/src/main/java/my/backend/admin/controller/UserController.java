package my.backend.admin.controller;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import my.backend.admin.service.UserService;
import my.backend.admin.controller.dto.UpdateSecretRequest;
import my.backend.iot.client.dto.UpdateStDto;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("${server.api-base-path}")
@RequiredArgsConstructor
@Validated
public class UserController extends BaseController {

    @Resource
    private UserService userService;

    @Operation(summary = "更新用戶密碼", description = "更新用戶密碼")
    @PutMapping(value = "/v1/auth/user/update-secretc")
    public String updateUserSecret(@Valid @RequestBody UpdateSecretRequest updateSecretRequest) {

        UpdateStDto updateStDto = new UpdateStDto(updateSecretRequest.getAccount(), updateSecretRequest.getValue());
        return userService.updateUserSecret(updateStDto);
    }



}
