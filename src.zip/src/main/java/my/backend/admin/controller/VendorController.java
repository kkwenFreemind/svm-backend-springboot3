package my.backend.admin.controller;

import io.swagger.v3.oas.annotations.Operation;
import jakarta.annotation.Resource;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import my.backend.admin.controller.dto.CreateVendorRequest;
import my.backend.admin.service.VendorService;
import my.backend.admin.service.dto.VendorDto;
import org.springframework.beans.BeanUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("${server.api-base-path}")
@RequiredArgsConstructor
@Validated
public class VendorController  extends BaseController {

    @Resource
    private VendorService vendorService;

    @Operation(summary = "創建Vendor", description = "創建Vendor (Create Vendor)")
    @PostMapping(value = "/v1/auth/vendor")
    public VendorDto createVendor(@Valid @RequestBody CreateVendorRequest createVendorRequest) {

        VendorDto vendorDto = new VendorDto();
        BeanUtils.copyProperties(createVendorRequest, vendorDto);
        return vendorService.createVendor(vendorDto);
    }

}
