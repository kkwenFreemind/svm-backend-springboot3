package my.backend.admin.controller.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

@Schema
@Data
public class UserLoginDto {

    @Schema(description = "clientIp")
    private String clientIp;
    @Schema(description = "email")
    @NotEmpty
    private String email;
    @Schema(description = "secret")
    @NotEmpty
    private String secret;
    @Schema(description = "totp")
    private String totp;

    public UserLoginDto(String email, String secret, String totp, String clientIp) {
        this.email = email;
        this.secret = secret;
        this.totp = totp;
        this.clientIp = clientIp;
    }

    @Override
    public String toString() {
        return "LoginDto(" +
                "clientIp=" + clientIp +
                ", email=" + email +
                ", secret=*****" +
                ", totp=" + totp +
                ")";
    }

}
