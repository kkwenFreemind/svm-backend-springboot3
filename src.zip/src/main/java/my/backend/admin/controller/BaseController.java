package my.backend.admin.controller;

import com.google.common.html.HtmlEscapers;
import jakarta.annotation.Resource;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.Getter;
import my.backend.admin.service.dto.CreateProjectRequest;
import my.backend.common.cache.BmsCacheManager;
import my.backend.common.code.ClientRoleGroupEnum;
import my.backend.common.code.RoleGroupEnum;
import my.backend.common.error.ErrorCode;
import my.backend.common.exception.ActionRuntimeException;
import my.backend.common.exception.UnauthorizedException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;

import java.util.*;

@Component
public abstract class BaseController {

    @Resource
    private BmsCacheManager bmsCacheManager;

    @Getter
    private ApplicationContext context;
    
    private HttpServletRequest httpServletRequest;
    private HttpServletResponse httpServletResponse;

    protected String getActionUserId() {
        JwtAuthenticationToken authentication = getAuthentication();
        String name = authentication.getName();
        if (name == null || name.isEmpty()) {
            throw new ActionRuntimeException(ErrorCode.ACCESS_TOKEN_GET_INFO_FAILED, "AccessToken 對應 User Id 不合法");
        }
        String tmp = HtmlEscapers.htmlEscaper().escape(name);
        if (!tmp.equals(name)) {
            throw new ActionRuntimeException(ErrorCode.ACCESS_TOKEN_GET_INFO_FAILED, "AccessToken 對應 User Id 不合法");
        }
        return tmp;
    }

    protected String getAuthToken() {
        return getAuthentication().getToken().getTokenValue();
    }

    protected JwtAuthenticationToken getAuthentication() {
        if (SecurityContextHolder.getContext() == null) {
            return null;
        }
        return (JwtAuthenticationToken) SecurityContextHolder.getContext().getAuthentication();
    }

    protected String getCookieValue(String cookieName) {
        Cookie[] cookies = getHttpServletRequest().getCookies();
        if (cookies != null) {
            for (Cookie cookie : cookies) {
                if (cookieName.equals(cookie.getName())) {
                    return cookie.getValue();
                }
            }
        }
        return null;
    }

    protected HttpServletRequest getHttpServletRequest() {
        return this.httpServletRequest;
    }

    @Autowired
    protected void setHttpServletRequest(HttpServletRequest httpServletRequest) {
        this.httpServletRequest = httpServletRequest;
    }

    protected HttpServletResponse getHttpServletResponse() {
        return this.httpServletResponse;
    }

    @Autowired
    protected void setHttpServletResponse(HttpServletResponse httpServletResponse) {
        this.httpServletResponse = httpServletResponse;
    }

    protected String getRefreshToken() {
        Cookie[] cookies = getHttpServletRequest().getCookies();
        for (Cookie cookie : cookies) {
            if ("refresh_token".equals(cookie.getName())) {
                return cookie.getValue();
            }
        }
        return null;
    }

    protected String getUserRoleByToken() {
        if (getAuthentication() == null) {
            throw new UnauthorizedException(ErrorCode.ACCESS_TOKEN_GET_INFO_FAILED, "Get Role Error");
        }
        Collection<GrantedAuthority> roles = getAuthentication().getAuthorities();
        for (GrantedAuthority role : roles) {
            System.out.println("role.getAuthority()==>"+role.getAuthority());
            if (role.getAuthority().contains("ROLE_")) {
                return role.getAuthority().replace("ROLE_", "");
            }
        }
        throw new UnauthorizedException(ErrorCode.ACCESS_TOKEN_GET_INFO_FAILED, "Get Role Error");
    }

    @Autowired
    protected void setContext(ApplicationContext context) {
        this.context = context;
    }

    protected void validClientRoleGroupName(String clientRoleGroupName) {
        ClientRoleGroupEnum.getByRoleGroup(clientRoleGroupName);
    }

    protected void validUserIdList(List<String> userIdList) {
        if (userIdList == null || userIdList.isEmpty()) {
            return;
        }
        Set<String> userIdSet = bmsCacheManager.getUserInfoMapById().keySet();
        userIdList.forEach(userId -> {
            if (!userIdSet.contains(userId)) {
                throw new ActionRuntimeException(ErrorCode.USER_NOT_FOUND);
            }
        });
    }

//    protected void validPermissionByIntersectionId(String userId, String intersectionId) {
//        Set<String> projectIdSet = bmsCacheManager.getUserProjectMapByUserId().get(userId);
//        if (projectIdSet == null) {
//            throw new ForbiddenException(ErrorCode.ROLE_PERMISSION_DENIED, "使用者無權限存取此路口");
//        }
//        IntersectionInfoEntity intersectionInfoEntity = bmsCacheManager.getIntersectionInfoMap().get(intersectionId);
//        if (intersectionInfoEntity == null) {
//            throw new ForbiddenException(ErrorCode.INTERSECTION_NOT_FOUND);
//        }
//        if (!projectIdSet.contains(intersectionInfoEntity.getProjectId())) {
//            throw new ForbiddenException(ErrorCode.ROLE_PERMISSION_DENIED, "使用者無權限存取此路口");
//        }
//    }

//    protected void validPermissionByProjectId(String userId, String projectId) {
//        Set<String> projectIdSet = bmsCacheManager.getUserProjectMapByUserId().get(userId);
//        if (projectIdSet == null) {
//            throw new ForbiddenException(ErrorCode.ROLE_PERMISSION_DENIED, "使用者無權限存取此專案");
//        }
//        if (!projectIdSet.contains(projectId)) {
//            throw new ForbiddenException(ErrorCode.ROLE_PERMISSION_DENIED, "使用者無權限存取此專案");
//        }
//    }

//    protected String validProjectId(String projectId) {
//        //// Fix projectId 的 Reflected XSS All Clients 風險
//        ProjectInfoEntity projectInfoEntity = bmsCacheManager.getProjectInfoMap().get(projectId);
//        if (projectInfoEntity == null) {
//            throw new ActionRuntimeException(ErrorCode.PROJECT_NOT_FOUND);
//        }
//        return projectInfoEntity.getProjectId();
//    }

    protected void validRoleGroupName(String userRoleGroupName) {
        RoleGroupEnum.getByRoleGroup(userRoleGroupName);
    }

//    protected void validUserIdList(List<String> userIdList) {
//        if (userIdList == null || userIdList.isEmpty()) {
//            return;
//        }
//        Set<String> userIdSet = bmsCacheManager.getUserInfoMapById().keySet();
//        userIdList.forEach(userId -> {
//            if (!userIdSet.contains(userId)) {
//                throw new ActionRuntimeException(ErrorCode.USER_NOT_FOUND);
//            }
//        });
//    }

//    protected void validUsersContainProject(String projectId, List<String> userIdList) {
//        if (userIdList == null || userIdList.isEmpty()) {
//            return;
//        }
//        Map<String, Set<String>> userProjectMap = bmsCacheManager.getUserProjectMapByUserId();
//        userIdList.forEach(userId -> {
//            Set<String> projectIdSet = userProjectMap.get(userId);
//            if (projectIdSet == null || !projectIdSet.contains(projectId)) {
//                //使用者不存在於此專案中
//                throw new ActionRuntimeException(ErrorCode.USER_NOT_EXIST_IN_PROJECT, "userId = " + userId + ", 使用者不存在於此專案中");
//            }
//        });
//    }

    protected void validateCreateProjectRequest(CreateProjectRequest createProjectRequest) {
        bmsCacheManager.getProjectInfoMap().values().forEach(projectInfoEntity -> {
            if (projectInfoEntity.getProjectLabel().equals(createProjectRequest.getProjectLabel())) {
                throw new ActionRuntimeException(ErrorCode.PROJECT_LABEL_CONFLICT);
            }
        });
    }

//    protected void validateEventType(String eventType) {
//        ////
//        Set<String> eventTypeSet = Arrays.stream(EventTypeEnum.values()).map(EventTypeEnum::getEventType).collect(Collectors.toSet());
//        if (!eventTypeSet.contains(eventType)) {
//            throw new ActionRuntimeException(ErrorCode.EVENT_TYPE_NOT_FOUND);
//        }
//    }

    protected void validateProjectIdList(List<String> projectIdList) {
        if (projectIdList == null || projectIdList.isEmpty()) {
            return;
        }
        Set<String> projectIdSet = bmsCacheManager.getProjectInfoMap().keySet();
        projectIdList.forEach(projectId -> {
            if (!projectIdSet.contains(projectId)) {
                throw new ActionRuntimeException(ErrorCode.PROJECT_NOT_FOUND);
            }
        });
    }

//    protected void validateTimeSeriesParams(Long startTime, Long endTime, int maxDays) {
//        long difference = endTime - startTime;
//        long dayInMilliseconds = 24 * 60 * 60 * 1000;
//        if (startTime < 0 || endTime < 0) {
//            throw new ActionRuntimeException(ErrorCode.TIME_NOT_NEGATIVE);
//        }
//        if( difference < 0){
//            throw new ActionRuntimeException(ErrorCode.TIME_RANGE_ERROR);
//        }
////        if (difference > maxDays * dayInMilliseconds) {
////            throw new ActionRuntimeException(ErrorCode.NOT_OVER_31_DAYS_BETWEEN_STARTTIME_AND_ENDTIME);
////        }
//    }

//    protected static void validIntersection(String intersectionType, String latitude, String longitude, String groupId) {
//        if(IntersectionTypeEnum.FIXED.name().equals(intersectionType)) {
//            ////則經緯度不能為空
//            if(latitude == null || latitude.isEmpty()
//                    || longitude == null || longitude.isEmpty()) {
//                throw new ActionRuntimeException(ErrorCode.INVALID_PARAMETER, "IntersectionType為固定式時，則經緯度不能為空");
//            }
//            ////路口群組ID不能為空
//            if (groupId == null || groupId.isEmpty()) {
//                throw new ActionRuntimeException(ErrorCode.INVALID_PARAMETER, "IntersectionType為固定式時，路口群組ID不能為空");
//            }
//        }
//    }

//    protected void validIntersectionDotList(String projectId, List<IntersectionDto> intersectionDtoList, Boolean isCreate) throws JsonProcessingException {
//        ////
//        List<IntersectionInfoEntity> intersectionInfoEntityList = bmsCacheManager.getIntersectionInfoListMap().get(projectId);
//        Set<String> intersectionLabelSet = intersectionInfoEntityList.stream().map(IntersectionInfoEntity::getIntersectionLabel).collect(Collectors.toSet());
//        Map<String, IntersectionInfoEntity> intersectionInfoMap = bmsCacheManager.getIntersectionInfoMap();
//        ////
//        Map<String, String> intersectionGroup = BmsUtils.projectParamToMap(bmsCacheManager.getProjectParamMapMap().get(projectId).get(ProjectParamsEnum.INTERSECTION_GROUP.getParamNo()));
//        for (int i = 0; i < intersectionDtoList.size(); i++) {
//            int number = i + 1;
//            IntersectionDto intersectionDto = intersectionDtoList.get(i);
//            if (isCreate && intersectionLabelSet.contains(intersectionDto.getIntersectionLabel())) {
//                throw new ActionRuntimeException(ErrorCode.INTERSECTION_DUPLICATE, "第" + number + "筆路口已存在");
//            }
//            if (!isCreate && !intersectionInfoMap.containsKey(intersectionDto.getIntersectionId())) {
//                throw new ActionRuntimeException(ErrorCode.INTERSECTION_NOT_FOUND, "第" + number + "筆路口不存在");
//            }
//            if (IntersectionTypeEnum.FIXED.equals(intersectionDto.getIntersectionType()) && !intersectionGroup.containsKey(intersectionDto.getGroupId())) {
//                throw new ActionRuntimeException(ErrorCode.INTERSECTION_GROUP_NOT_EXIST, "第" + number + "筆路口群組不存在");
//            }
//        }
//    }
}
