package my.backend.admin.controller.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;
import my.backend.admin.service.dto.CreateProjectRequest;
import my.backend.persistence.model.ProjectInfoEntity;
import my.backend.admin.service.code.ProjectParamsEnum;
import java.util.List;
import java.util.Map;

@Schema
@Data
@ToString
public class ProjectDto {


//    @Schema(description = "電池廠商群組")
//    private String batteryVendorGroup;
    @Schema(description = "建立時間")
    private Long createTime;
    @Schema(description = "啟用")
    private Boolean enabled;
//    @Schema(description = "閘道器廠商群組")
//    private String gatewayVendorGroup;
//    @Schema(description = "路口群組")
//    private String intersectionGroup;
//    @Schema(description = "地圖初始緯度")
//    private String mapInitLatitude;
//    @Schema(description = "地圖初始經度")
//    private String mapInitLongitude;
//    @Schema(description = "地圖初始縮放比例")
//    private String mapInitZoom;
    @Schema(description = "專案ID")
    private String projectId;
    @Schema(description = "專案標籤")
    private String projectLabel;
    @Schema(description = "更新時間")
    private Long updateTime;
//    @Schema(description = "UPS廠商群組")
//    private String upsVendorGroup;
    @Schema(description = "專案使用者ID清單")
    private List<String> userIdList;

    public ProjectDto(ProjectInfoEntity projectInfoEntity, Map<String, String> projectParamMap) {
        this.projectId = projectInfoEntity.getProjectId();
        this.projectLabel = projectInfoEntity.getProjectLabel();
        this.enabled = projectInfoEntity.getEnabled();
        if (projectParamMap == null) {
            return;
        }
//        this.batteryVendorGroup = projectParamMap.get(ProjectParamsEnum.BATTERY_VENDOR_GROUP.getParamNo());
//        this.gatewayVendorGroup = projectParamMap.get(ProjectParamsEnum.GATEWAY_VENDOR_GROUP.getParamNo());
//        this.intersectionGroup = projectParamMap.get(ProjectParamsEnum.INTERSECTION_GROUP.getParamNo());
//        this.mapInitLatitude = projectParamMap.get(ProjectParamsEnum.MAP_INIT_LATITUDE.getParamNo());
//        this.mapInitLongitude = projectParamMap.get(ProjectParamsEnum.MAP_INIT_LONGITUDE.getParamNo());
//        this.mapInitZoom = projectParamMap.get(ProjectParamsEnum.MAP_INIT_ZOOM.getParamNo());
//        this.upsVendorGroup = projectParamMap.get(ProjectParamsEnum.UPS_VENDOR_GROUP.getParamNo());
    }

    public ProjectDto() {
    }

    public ProjectDto(UpdateProjectRequest updateProjectRequest) {
        this.projectId = updateProjectRequest.getProjectId();
        this.projectLabel = updateProjectRequest.getProjectLabel();
//        this.batteryVendorGroup = updateProjectRequest.getBatteryVendorGroup();
//        this.gatewayVendorGroup = updateProjectRequest.getGatewayVendorGroup();
//        this.intersectionGroup = updateProjectRequest.getIntersectionGroup();
//        this.mapInitLatitude = updateProjectRequest.getMapInitLatitude();
//        this.mapInitLongitude = updateProjectRequest.getMapInitLongitude();
//        this.mapInitZoom = updateProjectRequest.getMapInitZoom();
//        this.upsVendorGroup = updateProjectRequest.getUpsVendorGroup();
        this.enabled = updateProjectRequest.getEnabled();
        this.userIdList = updateProjectRequest.getUserIdList();
    }

    public ProjectDto(CreateProjectRequest createProjectRequest) {
        this.projectLabel = createProjectRequest.getProjectLabel();
        this.enabled = Boolean.TRUE;
        this.createTime = System.currentTimeMillis();
//        this.batteryVendorGroup = createProjectRequest.getBatteryVendorGroup();
//        this.gatewayVendorGroup = createProjectRequest.getGatewayVendorGroup();
//        this.intersectionGroup = createProjectRequest.getIntersectionGroup();
//        this.mapInitLatitude = createProjectRequest.getMapInitLatitude();
//        this.mapInitLongitude = createProjectRequest.getMapInitLongitude();
//        this.mapInitZoom = createProjectRequest.getMapInitZoom();
//        this.upsVendorGroup = createProjectRequest.getUpsVendorGroup();
    }
}
