package my.backend.admin.controller.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.Data;
import lombok.ToString;

@Schema
@Data
@ToString
public class CreateVendorRequest {

    @Schema(description = "協力廠商名稱")
    @NotEmpty(message = "協力廠商名稱不可為空")
    @Size(max = 100, message = "協力廠商名稱長度不可超過100")
    private String vendorLabel;

    @Schema(description = "專案ID")
    @NotEmpty(message = "專案ID不可為空")
    @Size(max = 50, message = "專案ID長度不可超過50")
    private String projectId;
}
