package my.backend.admin.controller.dto;

import io.swagger.v3.oas.annotations.media.Schema;
import lombok.Data;
import lombok.ToString;
import my.backend.common.utils.BmsUtils;
import my.backend.persistence.model.UserInfoEntity;

import java.util.List;

@Schema
@Data
@ToString
public class UserDto {

    @Schema(description = "建立時間")
    private Long createTime;
    @Schema(description = "默認專案ID")
    private String defaultProjectId;
    @Schema(description = "使用者Email")
    private String email;
    @Schema(description = "專案ID清單")
    private List<String> projectIdList;
    @Schema(description = "更新時間")
    private Long updateTime;
    @Schema(description = "使用者群組")
    private List<String> userGroupIdList;
    @Schema(description = "使用者ID")
    private String userId;
    @Schema(description = "使用者名稱")
    private String userLabel;
    @Schema(description = "使用者角色群組名稱")
    private String userRoleGroupName;

    public UserDto(CreateProjectUserRequest createProjectUserRequest) {
        this.defaultProjectId = createProjectUserRequest.getDefaultProjectId();
        this.email = createProjectUserRequest.getEmail();
        this.projectIdList = createProjectUserRequest.getProjectIdList();
        this.userLabel = createProjectUserRequest.getUserLabel();
        this.userRoleGroupName = createProjectUserRequest.getUserRoleGroupName();
    }

    public UserDto(UpdateProjectUserRequest updateProjectUserRequest) {
        this.defaultProjectId = updateProjectUserRequest.getDefaultProjectId();
        this.projectIdList = updateProjectUserRequest.getProjectIdList();
        this.userId = updateProjectUserRequest.getUserId();
        this.userLabel = updateProjectUserRequest.getUserLabel();
        this.userRoleGroupName = updateProjectUserRequest.getUserRoleGroupName();
    }

    public UserDto(UserInfoEntity entity) {
        this.createTime = BmsUtils.toEpochMilli(entity.getCreateTime());
        this.defaultProjectId = entity.getDefaultProjectId();
        this.email = entity.getEmail();
        this.updateTime = BmsUtils.toEpochMilli(entity.getUpdateTime());
        this.userId = entity.getUserId();
        this.userLabel = entity.getUserLabel();
        this.userRoleGroupName = entity.getUserRoleGroupName();

    }
}
